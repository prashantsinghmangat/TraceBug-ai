"use strict";
var TraceBugModule = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/index.ts
  var src_exports = {};
  __export(src_exports, {
    buildReport: () => buildReport,
    buildTimeline: () => buildTimeline,
    captureEnvironment: () => captureEnvironment,
    captureScreenshot: () => captureScreenshot,
    clearAllSessions: () => clearAllSessions,
    clearVoiceTranscripts: () => clearVoiceTranscripts,
    default: () => src_default,
    deleteSession: () => deleteSession,
    downloadAllScreenshots: () => downloadAllScreenshots,
    downloadPdfAsHtml: () => downloadPdfAsHtml,
    formatTimelineText: () => formatTimelineText,
    generateBugTitle: () => generateBugTitle,
    generateFlowSummary: () => generateFlowSummary,
    generateGitHubIssue: () => generateGitHubIssue,
    generateJiraTicket: () => generateJiraTicket,
    generatePdfReport: () => generatePdfReport,
    generateReproSteps: () => generateReproSteps,
    getAllSessions: () => getAllSessions,
    getScreenshots: () => getScreenshots,
    getVoiceTranscripts: () => getVoiceTranscripts,
    isVoiceRecording: () => isVoiceRecording,
    isVoiceSupported: () => isVoiceSupported,
    startVoiceRecording: () => startVoiceRecording,
    stopVoiceRecording: () => stopVoiceRecording
  });

  // src/storage.ts
  var SESSIONS_KEY = "tracebug_sessions";
  function getSessionId() {
    const id = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : "bt_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
    return id;
  }
  function getAllSessions() {
    try {
      const raw = localStorage.getItem(SESSIONS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e2) {
      return [];
    }
  }
  function saveSessions(sessions) {
    try {
      localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
    } catch (e2) {
      if (sessions.length > 1) {
        sessions.shift();
        try {
          localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
        } catch (e3) {
        }
      }
    }
  }
  var _cachedSessions = null;
  var _pendingFlush = null;
  var FLUSH_INTERVAL_MS = 1e3;
  function getCachedSessions() {
    if (!_cachedSessions) {
      _cachedSessions = getAllSessions();
    }
    return _cachedSessions;
  }
  function scheduleFlush() {
    if (_pendingFlush) return;
    _pendingFlush = setTimeout(() => {
      _pendingFlush = null;
      if (_cachedSessions) {
        saveSessions(_cachedSessions);
      }
    }, FLUSH_INTERVAL_MS);
  }
  function flushPendingEvents() {
    if (_pendingFlush) {
      clearTimeout(_pendingFlush);
      _pendingFlush = null;
    }
    if (_cachedSessions) {
      saveSessions(_cachedSessions);
    }
  }
  if (typeof window !== "undefined") {
    window.addEventListener("beforeunload", flushPendingEvents);
  }
  function appendEvent(sessionId, event, maxEvents, maxSessions) {
    let sessions = getCachedSessions();
    let session = sessions.find((s) => s.sessionId === sessionId);
    if (!session) {
      session = {
        sessionId,
        projectId: event.projectId,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        errorMessage: null,
        errorStack: null,
        reproSteps: null,
        errorSummary: null,
        events: [],
        annotations: [],
        environment: null
      };
      sessions.push(session);
    }
    session.events.push(event);
    session.updatedAt = Date.now();
    if (session.events.length > maxEvents) {
      session.events = session.events.slice(-maxEvents);
    }
    if (sessions.length > maxSessions) {
      sessions = sessions.slice(-maxSessions);
      _cachedSessions = sessions;
    }
    scheduleFlush();
  }
  function updateSessionError(sessionId, errorMessage, errorStack, reproSteps, errorSummary) {
    const sessions = getAllSessions();
    const session = sessions.find((s) => s.sessionId === sessionId);
    if (!session) return;
    session.errorMessage = errorMessage;
    session.errorStack = errorStack || null;
    session.reproSteps = reproSteps;
    session.errorSummary = errorSummary;
    session.updatedAt = Date.now();
    saveSessions(sessions);
  }
  function deleteSession(sessionId) {
    const sessions = getAllSessions().filter((s) => s.sessionId !== sessionId);
    saveSessions(sessions);
  }
  function addAnnotation(sessionId, annotation) {
    const sessions = getAllSessions();
    const session = sessions.find((s) => s.sessionId === sessionId);
    if (!session) return;
    if (!session.annotations) session.annotations = [];
    session.annotations.push(annotation);
    session.updatedAt = Date.now();
    saveSessions(sessions);
  }
  function saveEnvironment(sessionId, env) {
    const sessions = getAllSessions();
    const session = sessions.find((s) => s.sessionId === sessionId);
    if (!session) return;
    session.environment = env;
    saveSessions(sessions);
  }
  function clearAllSessions() {
    localStorage.removeItem(SESSIONS_KEY);
  }

  // src/repro-generator.ts
  function generateReproSteps(events, errorMessage, errorStack) {
    var _a, _b;
    const steps = [];
    let stepNum = 1;
    let currentPage = "";
    let lastStepText = "";
    for (const event of events) {
      switch (event.type) {
        case "route_change": {
          const to = event.data.to || event.page;
          const pageName = friendlyPageName(to);
          steps.push(`${stepNum++}. Navigate to ${pageName} (${to})`);
          currentPage = to;
          break;
        }
        case "click": {
          const el = event.data.element;
          const label = describeElement(el);
          const stepText = `Click ${label}`;
          if (stepText !== lastStepText) {
            steps.push(`${stepNum++}. ${stepText}`);
            lastStepText = stepText;
          }
          break;
        }
        case "input": {
          const inp = event.data.element;
          const fieldName = (inp == null ? void 0 : inp.name) || (inp == null ? void 0 : inp.id) || "field";
          const inputType = (inp == null ? void 0 : inp.type) || "text";
          if (inputType === "checkbox" || inputType === "radio") {
            steps.push(`${stepNum++}. ${(inp == null ? void 0 : inp.checked) ? "Check" : "Uncheck"} "${fieldName}"`);
          } else {
            const val = inp == null ? void 0 : inp.value;
            if (val && val !== "[REDACTED]" && val.length <= 60) {
              steps.push(`${stepNum++}. Type "${val}" in "${fieldName}" field`);
            } else {
              steps.push(
                `${stepNum++}. Type in "${fieldName}" field (${(inp == null ? void 0 : inp.valueLength) || 0} characters)`
              );
            }
          }
          break;
        }
        case "select_change": {
          const sel = event.data.element;
          const fieldName = (sel == null ? void 0 : sel.name) || (sel == null ? void 0 : sel.id) || "dropdown";
          const selectedText = (sel == null ? void 0 : sel.selectedText) || (sel == null ? void 0 : sel.value) || "unknown";
          steps.push(`${stepNum++}. Select "${selectedText}" from "${fieldName}" dropdown`);
          break;
        }
        case "form_submit": {
          const f2 = event.data.form;
          const formName = (f2 == null ? void 0 : f2.id) || (f2 == null ? void 0 : f2.action) || "form";
          const fieldCount = (f2 == null ? void 0 : f2.fieldCount) || 0;
          steps.push(`${stepNum++}. Submit ${formName} form (${fieldCount} fields)`);
          break;
        }
        case "api_request": {
          const req = event.data.request;
          if ((req == null ? void 0 : req.statusCode) >= 400 || (req == null ? void 0 : req.statusCode) === 0) {
            steps.push(
              `${stepNum++}. API call fails: ${req.method} ${shortenUrl(req.url)} \u2192 ${req.statusCode === 0 ? "Network Error" : `HTTP ${req.statusCode}`}`
            );
          }
          break;
        }
        case "error":
        case "unhandled_rejection": {
          const errMsg = ((_a = event.data.error) == null ? void 0 : _a.message) || errorMessage;
          const stepText = `\u274C Error: "${errMsg}"`;
          if (stepText !== lastStepText) {
            steps.push(`${stepNum++}. ${stepText}`);
            lastStepText = stepText;
          }
          break;
        }
        case "console_error": {
          const msg = ((_b = event.data.error) == null ? void 0 : _b.message) || "";
          if (msg.length > 0 && !msg.includes("Warning:") && !msg.includes("DevTools")) {
            const stepText = `Console error: "${msg.slice(0, 120)}"`;
            if (stepText !== lastStepText) {
              steps.push(`${stepNum++}. ${stepText}`);
              lastStepText = stepText;
            }
          }
          break;
        }
      }
    }
    if (steps.length === 0) {
      steps.push("1. (No user interactions recorded before the error)");
    }
    const summary = buildErrorSummary(errorMessage, errorStack, events);
    return {
      reproSteps: steps.join("\n"),
      errorSummary: summary
    };
  }
  function describeElement(el) {
    if (!el) return "an element";
    const tag = el.tag || "";
    const rawText = (el.text || "").trim();
    const text = rawText.includes("\n") ? rawText.split("\n")[0].trim() : rawText;
    const id = el.id || "";
    const ariaLabel = el.ariaLabel || "";
    if (ariaLabel && ariaLabel.length < 50) {
      return `"${ariaLabel}" ${tag}`;
    }
    if (text && text.length < 50) {
      return `"${text}" ${tag}`;
    }
    if (id) {
      return `#${id} ${tag}`;
    }
    return `a ${tag} element`;
  }
  function friendlyPageName(path) {
    if (path === "/") return "Home page";
    const parts = path.split("/").filter(Boolean).map((p) => p.charAt(0).toUpperCase() + p.slice(1));
    return parts.join(" ") + " page";
  }
  function shortenUrl(url) {
    try {
      const u2 = new URL(url, window.location.origin);
      return u2.pathname + (u2.search ? "..." : "");
    } catch (e2) {
      return url.slice(0, 60);
    }
  }
  function buildErrorSummary(errorMessage, errorStack, events) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const parts = [];
    parts.push(`Error: ${errorMessage}`);
    if (errorStack) {
      const match = errorStack.match(/at\s+(\S+)\s+\(([^)]+)\)/);
      if (match) {
        parts.push(`Thrown in: ${match[1]} at ${match[2]}`);
      }
    }
    const errorEvents = events.filter(
      (e2) => e2.type === "error" || e2.type === "unhandled_rejection"
    );
    if (errorEvents.length > 0) {
      parts.push(`Page: ${errorEvents[0].page}`);
    }
    const userActions = events.filter(
      (e2) => ["click", "input", "select_change", "form_submit", "route_change"].includes(e2.type)
    );
    if (userActions.length > 0) {
      const last = userActions[userActions.length - 1];
      if (last.type === "click") {
        parts.push(
          `Last action: clicked "${((_a = last.data.element) == null ? void 0 : _a.text) || ((_b = last.data.element) == null ? void 0 : _b.id) || "element"}"`
        );
      } else if (last.type === "input") {
        const val = (_c = last.data.element) == null ? void 0 : _c.value;
        if (val && val !== "[REDACTED]") {
          parts.push(`Last action: typed "${val}" in "${((_d = last.data.element) == null ? void 0 : _d.name) || "field"}"`);
        } else {
          parts.push(`Last action: typed in "${((_e = last.data.element) == null ? void 0 : _e.name) || "field"}"`);
        }
      } else if (last.type === "select_change") {
        parts.push(`Last action: selected "${(_f = last.data.element) == null ? void 0 : _f.selectedText}" from "${((_g = last.data.element) == null ? void 0 : _g.name) || "dropdown"}"`);
      } else if (last.type === "form_submit") {
        parts.push(`Last action: submitted form "${((_h = last.data.form) == null ? void 0 : _h.id) || ""}"`);
      }
    }
    return parts.join("\n");
  }

  // node_modules/html2canvas/dist/html2canvas.esm.js
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }
  var __assign = function() {
    __assign = Object.assign || function __assign2(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return __assign.apply(this, arguments);
  };
  function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e2) {
          reject(e2);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e2) {
          reject(e2);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  }
  function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t[0] & 1) throw t[1];
      return t[1];
    }, trys: [], ops: [] }, f2, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n) {
      return function(v) {
        return step([n, v]);
      };
    }
    function step(op) {
      if (f2) throw new TypeError("Generator is already executing.");
      while (_) try {
        if (f2 = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e2) {
        op = [6, e2];
        y = 0;
      } finally {
        f2 = t = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  }
  function __spreadArray(to, from, pack2) {
    if (pack2 || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar) ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
    return to.concat(ar || from);
  }
  var Bounds = (
    /** @class */
    (function() {
      function Bounds2(left, top, width, height) {
        this.left = left;
        this.top = top;
        this.width = width;
        this.height = height;
      }
      Bounds2.prototype.add = function(x, y, w, h) {
        return new Bounds2(this.left + x, this.top + y, this.width + w, this.height + h);
      };
      Bounds2.fromClientRect = function(context, clientRect) {
        return new Bounds2(clientRect.left + context.windowBounds.left, clientRect.top + context.windowBounds.top, clientRect.width, clientRect.height);
      };
      Bounds2.fromDOMRectList = function(context, domRectList) {
        var domRect = Array.from(domRectList).find(function(rect) {
          return rect.width !== 0;
        });
        return domRect ? new Bounds2(domRect.left + context.windowBounds.left, domRect.top + context.windowBounds.top, domRect.width, domRect.height) : Bounds2.EMPTY;
      };
      Bounds2.EMPTY = new Bounds2(0, 0, 0, 0);
      return Bounds2;
    })()
  );
  var parseBounds = function(context, node) {
    return Bounds.fromClientRect(context, node.getBoundingClientRect());
  };
  var parseDocumentSize = function(document2) {
    var body = document2.body;
    var documentElement = document2.documentElement;
    if (!body || !documentElement) {
      throw new Error("Unable to get document size");
    }
    var width = Math.max(Math.max(body.scrollWidth, documentElement.scrollWidth), Math.max(body.offsetWidth, documentElement.offsetWidth), Math.max(body.clientWidth, documentElement.clientWidth));
    var height = Math.max(Math.max(body.scrollHeight, documentElement.scrollHeight), Math.max(body.offsetHeight, documentElement.offsetHeight), Math.max(body.clientHeight, documentElement.clientHeight));
    return new Bounds(0, 0, width, height);
  };
  var toCodePoints$1 = function(str) {
    var codePoints = [];
    var i = 0;
    var length = str.length;
    while (i < length) {
      var value = str.charCodeAt(i++);
      if (value >= 55296 && value <= 56319 && i < length) {
        var extra = str.charCodeAt(i++);
        if ((extra & 64512) === 56320) {
          codePoints.push(((value & 1023) << 10) + (extra & 1023) + 65536);
        } else {
          codePoints.push(value);
          i--;
        }
      } else {
        codePoints.push(value);
      }
    }
    return codePoints;
  };
  var fromCodePoint$1 = function() {
    var codePoints = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      codePoints[_i] = arguments[_i];
    }
    if (String.fromCodePoint) {
      return String.fromCodePoint.apply(String, codePoints);
    }
    var length = codePoints.length;
    if (!length) {
      return "";
    }
    var codeUnits = [];
    var index = -1;
    var result = "";
    while (++index < length) {
      var codePoint = codePoints[index];
      if (codePoint <= 65535) {
        codeUnits.push(codePoint);
      } else {
        codePoint -= 65536;
        codeUnits.push((codePoint >> 10) + 55296, codePoint % 1024 + 56320);
      }
      if (index + 1 === length || codeUnits.length > 16384) {
        result += String.fromCharCode.apply(String, codeUnits);
        codeUnits.length = 0;
      }
    }
    return result;
  };
  var chars$2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var lookup$2 = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
  for (i$2 = 0; i$2 < chars$2.length; i$2++) {
    lookup$2[chars$2.charCodeAt(i$2)] = i$2;
  }
  var i$2;
  var chars$1$1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var lookup$1$1 = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
  for (i$1$1 = 0; i$1$1 < chars$1$1.length; i$1$1++) {
    lookup$1$1[chars$1$1.charCodeAt(i$1$1)] = i$1$1;
  }
  var i$1$1;
  var decode$1 = function(base642) {
    var bufferLength = base642.length * 0.75, len = base642.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
    if (base642[base642.length - 1] === "=") {
      bufferLength--;
      if (base642[base642.length - 2] === "=") {
        bufferLength--;
      }
    }
    var buffer = typeof ArrayBuffer !== "undefined" && typeof Uint8Array !== "undefined" && typeof Uint8Array.prototype.slice !== "undefined" ? new ArrayBuffer(bufferLength) : new Array(bufferLength);
    var bytes = Array.isArray(buffer) ? buffer : new Uint8Array(buffer);
    for (i = 0; i < len; i += 4) {
      encoded1 = lookup$1$1[base642.charCodeAt(i)];
      encoded2 = lookup$1$1[base642.charCodeAt(i + 1)];
      encoded3 = lookup$1$1[base642.charCodeAt(i + 2)];
      encoded4 = lookup$1$1[base642.charCodeAt(i + 3)];
      bytes[p++] = encoded1 << 2 | encoded2 >> 4;
      bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
      bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
    }
    return buffer;
  };
  var polyUint16Array$1 = function(buffer) {
    var length = buffer.length;
    var bytes = [];
    for (var i = 0; i < length; i += 2) {
      bytes.push(buffer[i + 1] << 8 | buffer[i]);
    }
    return bytes;
  };
  var polyUint32Array$1 = function(buffer) {
    var length = buffer.length;
    var bytes = [];
    for (var i = 0; i < length; i += 4) {
      bytes.push(buffer[i + 3] << 24 | buffer[i + 2] << 16 | buffer[i + 1] << 8 | buffer[i]);
    }
    return bytes;
  };
  var UTRIE2_SHIFT_2$1 = 5;
  var UTRIE2_SHIFT_1$1 = 6 + 5;
  var UTRIE2_INDEX_SHIFT$1 = 2;
  var UTRIE2_SHIFT_1_2$1 = UTRIE2_SHIFT_1$1 - UTRIE2_SHIFT_2$1;
  var UTRIE2_LSCP_INDEX_2_OFFSET$1 = 65536 >> UTRIE2_SHIFT_2$1;
  var UTRIE2_DATA_BLOCK_LENGTH$1 = 1 << UTRIE2_SHIFT_2$1;
  var UTRIE2_DATA_MASK$1 = UTRIE2_DATA_BLOCK_LENGTH$1 - 1;
  var UTRIE2_LSCP_INDEX_2_LENGTH$1 = 1024 >> UTRIE2_SHIFT_2$1;
  var UTRIE2_INDEX_2_BMP_LENGTH$1 = UTRIE2_LSCP_INDEX_2_OFFSET$1 + UTRIE2_LSCP_INDEX_2_LENGTH$1;
  var UTRIE2_UTF8_2B_INDEX_2_OFFSET$1 = UTRIE2_INDEX_2_BMP_LENGTH$1;
  var UTRIE2_UTF8_2B_INDEX_2_LENGTH$1 = 2048 >> 6;
  var UTRIE2_INDEX_1_OFFSET$1 = UTRIE2_UTF8_2B_INDEX_2_OFFSET$1 + UTRIE2_UTF8_2B_INDEX_2_LENGTH$1;
  var UTRIE2_OMITTED_BMP_INDEX_1_LENGTH$1 = 65536 >> UTRIE2_SHIFT_1$1;
  var UTRIE2_INDEX_2_BLOCK_LENGTH$1 = 1 << UTRIE2_SHIFT_1_2$1;
  var UTRIE2_INDEX_2_MASK$1 = UTRIE2_INDEX_2_BLOCK_LENGTH$1 - 1;
  var slice16$1 = function(view, start, end) {
    if (view.slice) {
      return view.slice(start, end);
    }
    return new Uint16Array(Array.prototype.slice.call(view, start, end));
  };
  var slice32$1 = function(view, start, end) {
    if (view.slice) {
      return view.slice(start, end);
    }
    return new Uint32Array(Array.prototype.slice.call(view, start, end));
  };
  var createTrieFromBase64$1 = function(base642, _byteLength) {
    var buffer = decode$1(base642);
    var view32 = Array.isArray(buffer) ? polyUint32Array$1(buffer) : new Uint32Array(buffer);
    var view16 = Array.isArray(buffer) ? polyUint16Array$1(buffer) : new Uint16Array(buffer);
    var headerLength = 24;
    var index = slice16$1(view16, headerLength / 2, view32[4] / 2);
    var data = view32[5] === 2 ? slice16$1(view16, (headerLength + view32[4]) / 2) : slice32$1(view32, Math.ceil((headerLength + view32[4]) / 4));
    return new Trie$1(view32[0], view32[1], view32[2], view32[3], index, data);
  };
  var Trie$1 = (
    /** @class */
    (function() {
      function Trie2(initialValue, errorValue, highStart, highValueIndex, index, data) {
        this.initialValue = initialValue;
        this.errorValue = errorValue;
        this.highStart = highStart;
        this.highValueIndex = highValueIndex;
        this.index = index;
        this.data = data;
      }
      Trie2.prototype.get = function(codePoint) {
        var ix;
        if (codePoint >= 0) {
          if (codePoint < 55296 || codePoint > 56319 && codePoint <= 65535) {
            ix = this.index[codePoint >> UTRIE2_SHIFT_2$1];
            ix = (ix << UTRIE2_INDEX_SHIFT$1) + (codePoint & UTRIE2_DATA_MASK$1);
            return this.data[ix];
          }
          if (codePoint <= 65535) {
            ix = this.index[UTRIE2_LSCP_INDEX_2_OFFSET$1 + (codePoint - 55296 >> UTRIE2_SHIFT_2$1)];
            ix = (ix << UTRIE2_INDEX_SHIFT$1) + (codePoint & UTRIE2_DATA_MASK$1);
            return this.data[ix];
          }
          if (codePoint < this.highStart) {
            ix = UTRIE2_INDEX_1_OFFSET$1 - UTRIE2_OMITTED_BMP_INDEX_1_LENGTH$1 + (codePoint >> UTRIE2_SHIFT_1$1);
            ix = this.index[ix];
            ix += codePoint >> UTRIE2_SHIFT_2$1 & UTRIE2_INDEX_2_MASK$1;
            ix = this.index[ix];
            ix = (ix << UTRIE2_INDEX_SHIFT$1) + (codePoint & UTRIE2_DATA_MASK$1);
            return this.data[ix];
          }
          if (codePoint <= 1114111) {
            return this.data[this.highValueIndex];
          }
        }
        return this.errorValue;
      };
      return Trie2;
    })()
  );
  var chars$3 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var lookup$3 = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
  for (i$3 = 0; i$3 < chars$3.length; i$3++) {
    lookup$3[chars$3.charCodeAt(i$3)] = i$3;
  }
  var i$3;
  var base64$1 = "KwAAAAAAAAAACA4AUD0AADAgAAACAAAAAAAIABAAGABAAEgAUABYAGAAaABgAGgAYgBqAF8AZwBgAGgAcQB5AHUAfQCFAI0AlQCdAKIAqgCyALoAYABoAGAAaABgAGgAwgDKAGAAaADGAM4A0wDbAOEA6QDxAPkAAQEJAQ8BFwF1AH0AHAEkASwBNAE6AUIBQQFJAVEBWQFhAWgBcAF4ATAAgAGGAY4BlQGXAZ8BpwGvAbUBvQHFAc0B0wHbAeMB6wHxAfkBAQIJAvEBEQIZAiECKQIxAjgCQAJGAk4CVgJeAmQCbAJ0AnwCgQKJApECmQKgAqgCsAK4ArwCxAIwAMwC0wLbAjAA4wLrAvMC+AIAAwcDDwMwABcDHQMlAy0DNQN1AD0DQQNJA0kDSQNRA1EDVwNZA1kDdQB1AGEDdQBpA20DdQN1AHsDdQCBA4kDkQN1AHUAmQOhA3UAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AKYDrgN1AHUAtgO+A8YDzgPWAxcD3gPjA+sD8wN1AHUA+wMDBAkEdQANBBUEHQQlBCoEFwMyBDgEYABABBcDSARQBFgEYARoBDAAcAQzAXgEgASIBJAEdQCXBHUAnwSnBK4EtgS6BMIEyAR1AHUAdQB1AHUAdQCVANAEYABgAGAAYABgAGAAYABgANgEYADcBOQEYADsBPQE/AQEBQwFFAUcBSQFLAU0BWQEPAVEBUsFUwVbBWAAYgVgAGoFcgV6BYIFigWRBWAAmQWfBaYFYABgAGAAYABgAKoFYACxBbAFuQW6BcEFwQXHBcEFwQXPBdMF2wXjBeoF8gX6BQIGCgYSBhoGIgYqBjIGOgZgAD4GRgZMBmAAUwZaBmAAYABgAGAAYABgAGAAYABgAGAAYABgAGIGYABpBnAGYABgAGAAYABgAGAAYABgAGAAYAB4Bn8GhQZgAGAAYAB1AHcDFQSLBmAAYABgAJMGdQA9A3UAmwajBqsGqwaVALMGuwbDBjAAywbSBtIG1QbSBtIG0gbSBtIG0gbdBuMG6wbzBvsGAwcLBxMHAwcbByMHJwcsBywHMQcsB9IGOAdAB0gHTgfSBkgHVgfSBtIG0gbSBtIG0gbSBtIG0gbSBiwHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAdgAGAALAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAdbB2MHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsB2kH0gZwB64EdQB1AHUAdQB1AHUAdQB1AHUHfQdgAIUHjQd1AHUAlQedB2AAYAClB6sHYACzB7YHvgfGB3UAzgfWBzMB3gfmB1EB7gf1B/0HlQENAQUIDQh1ABUIHQglCBcDLQg1CD0IRQhNCEEDUwh1AHUAdQBbCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIcAh3CHoIMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIgggwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAALAcsBywHLAcsBywHLAcsBywHLAcsB4oILAcsB44I0gaWCJ4Ipgh1AHUAqgiyCHUAdQB1AHUAdQB1AHUAdQB1AHUAtwh8AXUAvwh1AMUIyQjRCNkI4AjoCHUAdQB1AO4I9gj+CAYJDgkTCS0HGwkjCYIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiAAIAAAAFAAYABgAGIAXwBgAHEAdQBFAJUAogCyAKAAYABgAEIA4ABGANMA4QDxAMEBDwE1AFwBLAE6AQEBUQF4QkhCmEKoQrhCgAHIQsAB0MLAAcABwAHAAeDC6ABoAHDCwMMAAcABwAHAAdDDGMMAAcAB6MM4wwjDWMNow3jDaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAEjDqABWw6bDqABpg6gAaABoAHcDvwOPA+gAaABfA/8DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DpcPAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcAB9cPKwkyCToJMAB1AHUAdQBCCUoJTQl1AFUJXAljCWcJawkwADAAMAAwAHMJdQB2CX4JdQCECYoJjgmWCXUAngkwAGAAYABxAHUApgn3A64JtAl1ALkJdQDACTAAMAAwADAAdQB1AHUAdQB1AHUAdQB1AHUAowYNBMUIMAAwADAAMADICcsJ0wnZCRUE4QkwAOkJ8An4CTAAMAB1AAAKvwh1AAgKDwoXCh8KdQAwACcKLgp1ADYKqAmICT4KRgowADAAdQB1AE4KMAB1AFYKdQBeCnUAZQowADAAMAAwADAAMAAwADAAMAAVBHUAbQowADAAdQC5CXUKMAAwAHwBxAijBogEMgF9CoQKiASMCpQKmgqIBKIKqgquCogEDQG2Cr4KxgrLCjAAMADTCtsKCgHjCusK8Qr5CgELMAAwADAAMAB1AIsECQsRC3UANAEZCzAAMAAwADAAMAB1ACELKQswAHUANAExCzkLdQBBC0kLMABRC1kLMAAwADAAMAAwADAAdQBhCzAAMAAwAGAAYABpC3ELdwt/CzAAMACHC4sLkwubC58Lpwt1AK4Ltgt1APsDMAAwADAAMAAwADAAMAAwAL4LwwvLC9IL1wvdCzAAMADlC+kL8Qv5C/8LSQswADAAMAAwADAAMAAwADAAMAAHDDAAMAAwADAAMAAODBYMHgx1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1ACYMMAAwADAAdQB1AHUALgx1AHUAdQB1AHUAdQA2DDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AD4MdQBGDHUAdQB1AHUAdQB1AEkMdQB1AHUAdQB1AFAMMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQBYDHUAdQB1AF8MMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUA+wMVBGcMMAAwAHwBbwx1AHcMfwyHDI8MMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAYABgAJcMMAAwADAAdQB1AJ8MlQClDDAAMACtDCwHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsB7UMLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AA0EMAC9DDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAsBywHLAcsBywHLAcsBywHLQcwAMEMyAwsBywHLAcsBywHLAcsBywHLAcsBywHzAwwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1ANQM2QzhDDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMABgAGAAYABgAGAAYABgAOkMYADxDGAA+AwADQYNYABhCWAAYAAODTAAMAAwADAAFg1gAGAAHg37AzAAMAAwADAAYABgACYNYAAsDTQNPA1gAEMNPg1LDWAAYABgAGAAYABgAGAAYABgAGAAUg1aDYsGVglhDV0NcQBnDW0NdQ15DWAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAlQCBDZUAiA2PDZcNMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAnw2nDTAAMAAwADAAMAAwAHUArw23DTAAMAAwADAAMAAwADAAMAAwADAAMAB1AL8NMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAB1AHUAdQB1AHUAdQDHDTAAYABgAM8NMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAA1w11ANwNMAAwAD0B5A0wADAAMAAwADAAMADsDfQN/A0EDgwOFA4wABsOMAAwADAAMAAwADAAMAAwANIG0gbSBtIG0gbSBtIG0gYjDigOwQUuDsEFMw7SBjoO0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGQg5KDlIOVg7SBtIGXg5lDm0OdQ7SBtIGfQ6EDooOjQ6UDtIGmg6hDtIG0gaoDqwO0ga0DrwO0gZgAGAAYADEDmAAYAAkBtIGzA5gANIOYADaDokO0gbSBt8O5w7SBu8O0gb1DvwO0gZgAGAAxA7SBtIG0gbSBtIGYABgAGAAYAAED2AAsAUMD9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGFA8sBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAccD9IGLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHJA8sBywHLAcsBywHLAccDywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywPLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAc0D9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAccD9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGFA8sBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHPA/SBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gYUD0QPlQCVAJUAMAAwADAAMACVAJUAlQCVAJUAlQCVAEwPMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAA//8EAAQABAAEAAQABAAEAAQABAANAAMAAQABAAIABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQACgATABcAHgAbABoAHgAXABYAEgAeABsAGAAPABgAHABLAEsASwBLAEsASwBLAEsASwBLABgAGAAeAB4AHgATAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABYAGwASAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAWAA0AEQAeAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAFAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJABYAGgAbABsAGwAeAB0AHQAeAE8AFwAeAA0AHgAeABoAGwBPAE8ADgBQAB0AHQAdAE8ATwAXAE8ATwBPABYAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAFAATwBAAE8ATwBPAEAATwBQAFAATwBQAB4AHgAeAB4AHgAeAB0AHQAdAB0AHgAdAB4ADgBQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgBQAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAkACQAJAAkACQAJAAkABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAFAAHgAeAB4AKwArAFAAUABQAFAAGABQACsAKwArACsAHgAeAFAAHgBQAFAAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUAAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAYAA0AKwArAB4AHgAbACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAB4ABAAEAB4ABAAEABMABAArACsAKwArACsAKwArACsAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAKwArACsAKwBWAFYAVgBWAB4AHgArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AGgAaABoAGAAYAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQAEwAEACsAEwATAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABLAEsASwBLAEsASwBLAEsASwBLABoAGQAZAB4AUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABMAUAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABABQAFAABAAEAB4ABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUAAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAFAABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQAUABQAB4AHgAYABMAUAArACsABAAbABsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAFAABAAEAAQABAAEAFAABAAEAAQAUAAEAAQABAAEAAQAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArACsAHgArAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAUAAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEAA0ADQBLAEsASwBLAEsASwBLAEsASwBLAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUAArACsAKwBQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABABQACsAKwArACsAKwArACsAKwAEACsAKwArACsAUABQACsAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUAAaABoAUABQAFAAUABQAEwAHgAbAFAAHgAEACsAKwAEAAQABAArAFAAUABQAFAAUABQACsAKwArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQACsAUABQACsAKwAEACsABAAEAAQABAAEACsAKwArACsABAAEACsAKwAEAAQABAArACsAKwAEACsAKwArACsAKwArACsAUABQAFAAUAArAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLAAQABABQAFAAUAAEAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAArACsAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAB4AGwArACsAKwArACsAKwArAFAABAAEAAQABAAEAAQAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAKwArACsAKwArAAQABAAEACsAKwArACsAUABQACsAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAB4AUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAAQAUAArAFAAUABQAFAAUABQACsAKwArAFAAUABQACsAUABQAFAAUAArACsAKwBQAFAAKwBQACsAUABQACsAKwArAFAAUAArACsAKwBQAFAAUAArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArAAQABAAEAAQABAArACsAKwAEAAQABAArAAQABAAEAAQAKwArAFAAKwArACsAKwArACsABAArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAHgAeAB4AHgAeAB4AGwAeACsAKwArACsAKwAEAAQABAAEAAQAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAUAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAAEACsAKwArACsAKwArACsABAAEACsAUABQAFAAKwArACsAKwArAFAAUAAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwAOAFAAUABQAFAAUABQAFAAHgBQAAQABAAEAA4AUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAKwArAAQAUAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAAEACsAKwArACsAKwArACsABAAEACsAKwArACsAKwArACsAUAArAFAAUAAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwBQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAFAABAAEAAQABAAEAAQABAArAAQABAAEACsABAAEAAQABABQAB4AKwArACsAKwBQAFAAUAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQABoAUABQAFAAUABQAFAAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQACsAUAArACsAUABQAFAAUABQAFAAUAArACsAKwAEACsAKwArACsABAAEAAQABAAEAAQAKwAEACsABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArAAQABAAeACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAXAAqACoAKgAqACoAKgAqACsAKwArACsAGwBcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAeAEsASwBLAEsASwBLAEsASwBLAEsADQANACsAKwArACsAKwBcAFwAKwBcACsAXABcAFwAXABcACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAXAArAFwAXABcAFwAXABcAFwAXABcAFwAKgBcAFwAKgAqACoAKgAqACoAKgAqACoAXAArACsAXABcAFwAXABcACsAXAArACoAKgAqACoAKgAqACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwBcAFwAXABcAFAADgAOAA4ADgAeAA4ADgAJAA4ADgANAAkAEwATABMAEwATAAkAHgATAB4AHgAeAAQABAAeAB4AHgAeAB4AHgBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQAFAADQAEAB4ABAAeAAQAFgARABYAEQAEAAQAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAAQABAAEAAQADQAEAAQAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAA0ADQAeAB4AHgAeAB4AHgAEAB4AHgAeAB4AHgAeACsAHgAeAA4ADgANAA4AHgAeAB4AHgAeAAkACQArACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgBcAEsASwBLAEsASwBLAEsASwBLAEsADQANAB4AHgAeAB4AXABcAFwAXABcAFwAKgAqACoAKgBcAFwAXABcACoAKgAqAFwAKgAqACoAXABcACoAKgAqACoAKgAqACoAXABcAFwAKgAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKgAqAFwAKgBLAEsASwBLAEsASwBLAEsASwBLACoAKgAqACoAKgAqAFAAUABQAFAAUABQACsAUAArACsAKwArACsAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgBQAFAAUABQAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAKwBQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsABAAEAAQAHgANAB4AHgAeAB4AHgAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUAArACsADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAWABEAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAA0ADQANAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAANAA0AKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUAArAAQABAArACsAKwArACsAKwArACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqAA0ADQAVAFwADQAeAA0AGwBcACoAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwAeAB4AEwATAA0ADQAOAB4AEwATAB4ABAAEAAQACQArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUAAEAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAHgArACsAKwATABMASwBLAEsASwBLAEsASwBLAEsASwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAXABcAFwAXABcACsAKwArACsAKwArACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAXAArACsAKwAqACoAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsAHgAeAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKwAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKwArAAQASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACoAKgAqACoAKgAqACoAXAAqACoAKgAqACoAKgArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABABQAFAAUABQAFAAUABQACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwANAA0AHgANAA0ADQANAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQAHgAeAB4AHgAeAB4AHgAeAB4AKwArACsABAAEAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwAeAB4AHgAeAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArAA0ADQANAA0ADQBLAEsASwBLAEsASwBLAEsASwBLACsAKwArAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAA0ADQBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUAAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArAAQABAAEAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAAQAUABQAFAAUABQAFAABABQAFAABAAEAAQAUAArACsAKwArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAKwBQACsAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAFAAUABQACsAHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQACsAKwAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQACsAHgAeAB4AHgAeAB4AHgAOAB4AKwANAA0ADQANAA0ADQANAAkADQANAA0ACAAEAAsABAAEAA0ACQANAA0ADAAdAB0AHgAXABcAFgAXABcAFwAWABcAHQAdAB4AHgAUABQAFAANAAEAAQAEAAQABAAEAAQACQAaABoAGgAaABoAGgAaABoAHgAXABcAHQAVABUAHgAeAB4AHgAeAB4AGAAWABEAFQAVABUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ADQAeAA0ADQANAA0AHgANAA0ADQAHAB4AHgAeAB4AKwAEAAQABAAEAAQABAAEAAQABAAEAFAAUAArACsATwBQAFAAUABQAFAAHgAeAB4AFgARAE8AUABPAE8ATwBPAFAAUABQAFAAUAAeAB4AHgAWABEAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArABsAGwAbABsAGwAbABsAGgAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGgAbABsAGwAbABoAGwAbABoAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAHgAeAFAAGgAeAB0AHgBQAB4AGgAeAB4AHgAeAB4AHgAeAB4AHgBPAB4AUAAbAB4AHgBQAFAAUABQAFAAHgAeAB4AHQAdAB4AUAAeAFAAHgBQAB4AUABPAFAAUAAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAHgBQAFAAUABQAE8ATwBQAFAAUABQAFAATwBQAFAATwBQAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAFAAUABQAFAATwBPAE8ATwBPAE8ATwBPAE8ATwBQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABPAB4AHgArACsAKwArAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHQAdAB4AHgAeAB0AHQAeAB4AHQAeAB4AHgAdAB4AHQAbABsAHgAdAB4AHgAeAB4AHQAeAB4AHQAdAB0AHQAeAB4AHQAeAB0AHgAdAB0AHQAdAB0AHQAeAB0AHgAeAB4AHgAeAB0AHQAdAB0AHgAeAB4AHgAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHgAeAB0AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAeAB0AHQAdAB0AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAdAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAWABEAHgAeAB4AHgAeAB4AHQAeAB4AHgAeAB4AHgAeACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAWABEAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAFAAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeAB4AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AHQAdAB0AHgAeAB0AHgAeAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlAB4AHQAdAB4AHgAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AJQAlAB0AHQAlAB4AJQAlACUAIAAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAeAB4AHgAeAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAdAB0AHQAeAB0AJQAdAB0AHgAdAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAdAB0AHQAdACUAHgAlACUAJQAdACUAJQAdAB0AHQAlACUAHQAdACUAHQAdACUAJQAlAB4AHQAeAB4AHgAeAB0AHQAlAB0AHQAdAB0AHQAdACUAJQAlACUAJQAdACUAJQAgACUAHQAdACUAJQAlACUAJQAlACUAJQAeAB4AHgAlACUAIAAgACAAIAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AFwAXABcAFwAXABcAHgATABMAJQAeAB4AHgAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARABYAEQAWABEAFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAEAAQABAAeAB4AKwArACsAKwArABMADQANAA0AUAATAA0AUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUAANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAA0ADQANAA0ADQANAA0ADQAeAA0AFgANAB4AHgAXABcAHgAeABcAFwAWABEAFgARABYAEQAWABEADQANAA0ADQATAFAADQANAB4ADQANAB4AHgAeAB4AHgAMAAwADQANAA0AHgANAA0AFgANAA0ADQANAA0ADQANAA0AHgANAB4ADQANAB4AHgAeACsAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArAA0AEQARACUAJQBHAFcAVwAWABEAFgARABYAEQAWABEAFgARACUAJQAWABEAFgARABYAEQAWABEAFQAWABEAEQAlAFcAVwBXAFcAVwBXAFcAVwBXAAQABAAEAAQABAAEACUAVwBXAFcAVwA2ACUAJQBXAFcAVwBHAEcAJQAlACUAKwBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBRAFcAUQBXAFEAVwBXAFcAVwBXAFcAUQBXAFcAVwBXAFcAVwBRAFEAKwArAAQABAAVABUARwBHAFcAFQBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBRAFcAVwBXAFcAVwBXAFEAUQBXAFcAVwBXABUAUQBHAEcAVwArACsAKwArACsAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwAlACUAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACsAKwArACsAKwArACsAKwArACsAKwArAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBPAE8ATwBPAE8ATwBPAE8AJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADQATAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABLAEsASwBLAEsASwBLAEsASwBLAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAABAAEAAQABAAeAAQABAAEAAQABAAEAAQABAAEAAQAHgBQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAeAA0ADQANAA0ADQArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAAQAUABQAFAABABQAFAAUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAeAB4AHgAeAAQAKwArACsAUABQAFAAUABQAFAAHgAeABoAHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADgAOABMAEwArACsAKwArACsAKwArACsABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwANAA0ASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUAAeAB4AHgBQAA4AUABQAAQAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArAB4AWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYACsAKwArAAQAHgAeAB4AHgAeAB4ADQANAA0AHgAeAB4AHgArAFAASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArAB4AHgBcAFwAXABcAFwAKgBcAFwAXABcAFwAXABcAFwAXABcAEsASwBLAEsASwBLAEsASwBLAEsAXABcAFwAXABcACsAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAFAAUABQAAQAUABQAFAAUABQAFAAUABQAAQABAArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAHgANAA0ADQBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAXAAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAKgAqACoAXABcACoAKgBcAFwAXABcAFwAKgAqAFwAKgBcACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcACoAKgBQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAA0ADQBQAFAAUAAEAAQAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQADQAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAVABVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBUAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVACsAKwArACsAKwArACsAKwArACsAKwArAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAKwArACsAKwBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAKwArACsAKwAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAKwArACsAKwArAFYABABWAFYAVgBWAFYAVgBWAFYAVgBWAB4AVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgArAFYAVgBWAFYAVgArAFYAKwBWAFYAKwBWAFYAKwBWAFYAVgBWAFYAVgBWAFYAVgBWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAEQAWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAaAB4AKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAGAARABEAGAAYABMAEwAWABEAFAArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACUAJQAlACUAJQAWABEAFgARABYAEQAWABEAFgARABYAEQAlACUAFgARACUAJQAlACUAJQAlACUAEQAlABEAKwAVABUAEwATACUAFgARABYAEQAWABEAJQAlACUAJQAlACUAJQAlACsAJQAbABoAJQArACsAKwArAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAcAKwATACUAJQAbABoAJQAlABYAEQAlACUAEQAlABEAJQBXAFcAVwBXAFcAVwBXAFcAVwBXABUAFQAlACUAJQATACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXABYAJQARACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAWACUAEQAlABYAEQARABYAEQARABUAVwBRAFEAUQBRAFEAUQBRAFEAUQBRAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcARwArACsAVwBXAFcAVwBXAFcAKwArAFcAVwBXAFcAVwBXACsAKwBXAFcAVwBXAFcAVwArACsAVwBXAFcAKwArACsAGgAbACUAJQAlABsAGwArAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAAQAB0AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsADQANAA0AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAAQAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAA0AUABQAFAAUAArACsAKwArAFAAUABQAFAAUABQAFAAUAANAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAKwArAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArACsAKwBQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAUABQAFAAUABQAAQABAAEACsABAAEACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAKwBQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAA0ADQANAA0ADQANAA0ADQAeACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAArACsAKwArAFAAUABQAFAAUAANAA0ADQANAA0ADQAUACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsADQANAA0ADQANAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAAQABAAEAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArAAQABAANACsAKwBQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAB4AHgAeAB4AHgArACsAKwArACsAKwAEAAQABAAEAAQABAAEAA0ADQAeAB4AHgAeAB4AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwAeACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsASwBLAEsASwBLAEsASwBLAEsASwANAA0ADQANAFAABAAEAFAAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAeAA4AUAArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAADQANAB4ADQAEAAQABAAEAB4ABAAEAEsASwBLAEsASwBLAEsASwBLAEsAUAAOAFAADQANAA0AKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAANAA0AHgANAA0AHgAEACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAA0AKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsABAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQACsABAAEAFAABAAEAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAUAArACsAKwArACsAKwAEACsAKwArACsAKwBQAFAAUABQAFAABAAEACsAKwAEAAQABAAEAAQABAAEACsAKwArAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAAQABABQAFAAUABQAA0ADQANAA0AHgBLAEsASwBLAEsASwBLAEsASwBLAA0ADQArAB4ABABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAFAAUAAeAFAAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABAAEAAQADgANAA0AEwATAB4AHgAeAA0ADQANAA0ADQANAA0ADQANAA0ADQANAA0ADQANAFAAUABQAFAABAAEACsAKwAEAA0ADQAeAFAAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKwArACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBcAFwADQANAA0AKgBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAKwArAFAAKwArAFAAUABQAFAAUABQAFAAUAArAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQAKwAEAAQAKwArAAQABAAEAAQAUAAEAFAABAAEAA0ADQANACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABABQAA4AUAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAFAABAAEAAQABAAOAB4ADQANAA0ADQAOAB4ABAArACsAKwArACsAKwArACsAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAA0ADQANAFAADgAOAA4ADQANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAAQABAAEAFAADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAOABMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAArACsAKwAEACsABAAEACsABAAEAAQABAAEAAQABABQAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQAKwAEAAQAKwAEAAQABAAEAAQAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAaABoAGgAaAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABIAEgAQwBDAEMAUABQAFAAUABDAFAAUABQAEgAQwBIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABDAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAJAAkACQAJAAkACQAJABYAEQArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwANAA0AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAANACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAA0ADQANAB4AHgAeAB4AHgAeAFAAUABQAFAADQAeACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAA0AHgAeACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAARwBHABUARwAJACsAKwArACsAKwArACsAKwArACsAKwAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUQBRAFEAKwArACsAKwArACsAKwArACsAKwArACsAKwBRAFEAUQBRACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArACsAHgAEAAQADQAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAAQABAAEAAQABAAeAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQAHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQAFAAKwArAFAAKwArAFAAUAArACsAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUAArAFAAUABQAFAAUABQAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAHgAeAFAAUABQAFAAUAArAFAAKwArACsAUABQAFAAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeACsAKwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4ABAAeAB4AHgAeAB4AHgAeAB4AHgAeAAQAHgAeAA0ADQANAA0AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAAQAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArAAQABAAEAAQABAAEAAQAKwAEAAQAKwAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwBQAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArABsAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAB4AHgAeAB4ABAAEAAQABAAEAAQABABQACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArABYAFgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAGgBQAFAAUAAaAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQACsAKwBQACsAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwBQACsAUAArACsAKwArACsAKwBQACsAKwArACsAUAArAFAAKwBQACsAUABQAFAAKwBQAFAAKwBQACsAKwBQACsAUAArAFAAKwBQACsAUAArAFAAUAArAFAAKwArAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUAArAFAAUABQAFAAKwBQACsAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAKwBQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8AJQAlACUAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB4AHgAeACUAJQAlAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAlACUAJQAlACUAHgAlACUAJQAlACUAIAAgACAAJQAlACAAJQAlACAAIAAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACEAIQAhACEAIQAlACUAIAAgACUAJQAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAIAAlACUAJQAlACAAIAAgACUAIAAgACAAJQAlACUAJQAlACUAJQAgACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAlAB4AJQAeACUAJQAlACUAJQAgACUAJQAlACUAHgAlAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACAAIAAgACUAJQAlACAAIAAgACAAIAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABcAFwAXABUAFQAVAB4AHgAeAB4AJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAgACUAJQAgACUAJQAlACUAJQAlACUAJQAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAgACAAIAAgACAAIAAgACAAIAAgACUAJQAgACAAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAlACAAIAAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAgACAAIAAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAVwBXACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAA==";
  var LETTER_NUMBER_MODIFIER = 50;
  var BK = 1;
  var CR$1 = 2;
  var LF$1 = 3;
  var CM = 4;
  var NL = 5;
  var WJ = 7;
  var ZW = 8;
  var GL = 9;
  var SP = 10;
  var ZWJ$1 = 11;
  var B2 = 12;
  var BA = 13;
  var BB = 14;
  var HY = 15;
  var CB = 16;
  var CL = 17;
  var CP = 18;
  var EX = 19;
  var IN = 20;
  var NS = 21;
  var OP = 22;
  var QU = 23;
  var IS = 24;
  var NU = 25;
  var PO = 26;
  var PR = 27;
  var SY = 28;
  var AI = 29;
  var AL = 30;
  var CJ = 31;
  var EB = 32;
  var EM = 33;
  var H2 = 34;
  var H3 = 35;
  var HL = 36;
  var ID = 37;
  var JL = 38;
  var JV = 39;
  var JT = 40;
  var RI$1 = 41;
  var SA = 42;
  var XX = 43;
  var ea_OP = [9001, 65288];
  var BREAK_MANDATORY = "!";
  var BREAK_NOT_ALLOWED$1 = "\xD7";
  var BREAK_ALLOWED$1 = "\xF7";
  var UnicodeTrie$1 = createTrieFromBase64$1(base64$1);
  var ALPHABETICS = [AL, HL];
  var HARD_LINE_BREAKS = [BK, CR$1, LF$1, NL];
  var SPACE$1 = [SP, ZW];
  var PREFIX_POSTFIX = [PR, PO];
  var LINE_BREAKS = HARD_LINE_BREAKS.concat(SPACE$1);
  var KOREAN_SYLLABLE_BLOCK = [JL, JV, JT, H2, H3];
  var HYPHEN = [HY, BA];
  var codePointsToCharacterClasses = function(codePoints, lineBreak2) {
    if (lineBreak2 === void 0) {
      lineBreak2 = "strict";
    }
    var types = [];
    var indices = [];
    var categories = [];
    codePoints.forEach(function(codePoint, index) {
      var classType = UnicodeTrie$1.get(codePoint);
      if (classType > LETTER_NUMBER_MODIFIER) {
        categories.push(true);
        classType -= LETTER_NUMBER_MODIFIER;
      } else {
        categories.push(false);
      }
      if (["normal", "auto", "loose"].indexOf(lineBreak2) !== -1) {
        if ([8208, 8211, 12316, 12448].indexOf(codePoint) !== -1) {
          indices.push(index);
          return types.push(CB);
        }
      }
      if (classType === CM || classType === ZWJ$1) {
        if (index === 0) {
          indices.push(index);
          return types.push(AL);
        }
        var prev = types[index - 1];
        if (LINE_BREAKS.indexOf(prev) === -1) {
          indices.push(indices[index - 1]);
          return types.push(prev);
        }
        indices.push(index);
        return types.push(AL);
      }
      indices.push(index);
      if (classType === CJ) {
        return types.push(lineBreak2 === "strict" ? NS : ID);
      }
      if (classType === SA) {
        return types.push(AL);
      }
      if (classType === AI) {
        return types.push(AL);
      }
      if (classType === XX) {
        if (codePoint >= 131072 && codePoint <= 196605 || codePoint >= 196608 && codePoint <= 262141) {
          return types.push(ID);
        } else {
          return types.push(AL);
        }
      }
      types.push(classType);
    });
    return [indices, types, categories];
  };
  var isAdjacentWithSpaceIgnored = function(a2, b, currentIndex, classTypes) {
    var current = classTypes[currentIndex];
    if (Array.isArray(a2) ? a2.indexOf(current) !== -1 : a2 === current) {
      var i = currentIndex;
      while (i <= classTypes.length) {
        i++;
        var next = classTypes[i];
        if (next === b) {
          return true;
        }
        if (next !== SP) {
          break;
        }
      }
    }
    if (current === SP) {
      var i = currentIndex;
      while (i > 0) {
        i--;
        var prev = classTypes[i];
        if (Array.isArray(a2) ? a2.indexOf(prev) !== -1 : a2 === prev) {
          var n = currentIndex;
          while (n <= classTypes.length) {
            n++;
            var next = classTypes[n];
            if (next === b) {
              return true;
            }
            if (next !== SP) {
              break;
            }
          }
        }
        if (prev !== SP) {
          break;
        }
      }
    }
    return false;
  };
  var previousNonSpaceClassType = function(currentIndex, classTypes) {
    var i = currentIndex;
    while (i >= 0) {
      var type = classTypes[i];
      if (type === SP) {
        i--;
      } else {
        return type;
      }
    }
    return 0;
  };
  var _lineBreakAtIndex = function(codePoints, classTypes, indicies, index, forbiddenBreaks) {
    if (indicies[index] === 0) {
      return BREAK_NOT_ALLOWED$1;
    }
    var currentIndex = index - 1;
    if (Array.isArray(forbiddenBreaks) && forbiddenBreaks[currentIndex] === true) {
      return BREAK_NOT_ALLOWED$1;
    }
    var beforeIndex = currentIndex - 1;
    var afterIndex = currentIndex + 1;
    var current = classTypes[currentIndex];
    var before = beforeIndex >= 0 ? classTypes[beforeIndex] : 0;
    var next = classTypes[afterIndex];
    if (current === CR$1 && next === LF$1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (HARD_LINE_BREAKS.indexOf(current) !== -1) {
      return BREAK_MANDATORY;
    }
    if (HARD_LINE_BREAKS.indexOf(next) !== -1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (SPACE$1.indexOf(next) !== -1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (previousNonSpaceClassType(currentIndex, classTypes) === ZW) {
      return BREAK_ALLOWED$1;
    }
    if (UnicodeTrie$1.get(codePoints[currentIndex]) === ZWJ$1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if ((current === EB || current === EM) && UnicodeTrie$1.get(codePoints[afterIndex]) === ZWJ$1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (current === WJ || next === WJ) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (current === GL) {
      return BREAK_NOT_ALLOWED$1;
    }
    if ([SP, BA, HY].indexOf(current) === -1 && next === GL) {
      return BREAK_NOT_ALLOWED$1;
    }
    if ([CL, CP, EX, IS, SY].indexOf(next) !== -1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (previousNonSpaceClassType(currentIndex, classTypes) === OP) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (isAdjacentWithSpaceIgnored(QU, OP, currentIndex, classTypes)) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (isAdjacentWithSpaceIgnored([CL, CP], NS, currentIndex, classTypes)) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (isAdjacentWithSpaceIgnored(B2, B2, currentIndex, classTypes)) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (current === SP) {
      return BREAK_ALLOWED$1;
    }
    if (current === QU || next === QU) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (next === CB || current === CB) {
      return BREAK_ALLOWED$1;
    }
    if ([BA, HY, NS].indexOf(next) !== -1 || current === BB) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (before === HL && HYPHEN.indexOf(current) !== -1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (current === SY && next === HL) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (next === IN) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (ALPHABETICS.indexOf(next) !== -1 && current === NU || ALPHABETICS.indexOf(current) !== -1 && next === NU) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (current === PR && [ID, EB, EM].indexOf(next) !== -1 || [ID, EB, EM].indexOf(current) !== -1 && next === PO) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (ALPHABETICS.indexOf(current) !== -1 && PREFIX_POSTFIX.indexOf(next) !== -1 || PREFIX_POSTFIX.indexOf(current) !== -1 && ALPHABETICS.indexOf(next) !== -1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (
      // (PR | PO) × ( OP | HY )? NU
      [PR, PO].indexOf(current) !== -1 && (next === NU || [OP, HY].indexOf(next) !== -1 && classTypes[afterIndex + 1] === NU) || // ( OP | HY ) × NU
      [OP, HY].indexOf(current) !== -1 && next === NU || // NU ×	(NU | SY | IS)
      current === NU && [NU, SY, IS].indexOf(next) !== -1
    ) {
      return BREAK_NOT_ALLOWED$1;
    }
    if ([NU, SY, IS, CL, CP].indexOf(next) !== -1) {
      var prevIndex = currentIndex;
      while (prevIndex >= 0) {
        var type = classTypes[prevIndex];
        if (type === NU) {
          return BREAK_NOT_ALLOWED$1;
        } else if ([SY, IS].indexOf(type) !== -1) {
          prevIndex--;
        } else {
          break;
        }
      }
    }
    if ([PR, PO].indexOf(next) !== -1) {
      var prevIndex = [CL, CP].indexOf(current) !== -1 ? beforeIndex : currentIndex;
      while (prevIndex >= 0) {
        var type = classTypes[prevIndex];
        if (type === NU) {
          return BREAK_NOT_ALLOWED$1;
        } else if ([SY, IS].indexOf(type) !== -1) {
          prevIndex--;
        } else {
          break;
        }
      }
    }
    if (JL === current && [JL, JV, H2, H3].indexOf(next) !== -1 || [JV, H2].indexOf(current) !== -1 && [JV, JT].indexOf(next) !== -1 || [JT, H3].indexOf(current) !== -1 && next === JT) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (KOREAN_SYLLABLE_BLOCK.indexOf(current) !== -1 && [IN, PO].indexOf(next) !== -1 || KOREAN_SYLLABLE_BLOCK.indexOf(next) !== -1 && current === PR) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (ALPHABETICS.indexOf(current) !== -1 && ALPHABETICS.indexOf(next) !== -1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (current === IS && ALPHABETICS.indexOf(next) !== -1) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (ALPHABETICS.concat(NU).indexOf(current) !== -1 && next === OP && ea_OP.indexOf(codePoints[afterIndex]) === -1 || ALPHABETICS.concat(NU).indexOf(next) !== -1 && current === CP) {
      return BREAK_NOT_ALLOWED$1;
    }
    if (current === RI$1 && next === RI$1) {
      var i = indicies[currentIndex];
      var count = 1;
      while (i > 0) {
        i--;
        if (classTypes[i] === RI$1) {
          count++;
        } else {
          break;
        }
      }
      if (count % 2 !== 0) {
        return BREAK_NOT_ALLOWED$1;
      }
    }
    if (current === EB && next === EM) {
      return BREAK_NOT_ALLOWED$1;
    }
    return BREAK_ALLOWED$1;
  };
  var cssFormattedClasses = function(codePoints, options) {
    if (!options) {
      options = { lineBreak: "normal", wordBreak: "normal" };
    }
    var _a = codePointsToCharacterClasses(codePoints, options.lineBreak), indicies = _a[0], classTypes = _a[1], isLetterNumber = _a[2];
    if (options.wordBreak === "break-all" || options.wordBreak === "break-word") {
      classTypes = classTypes.map(function(type) {
        return [NU, AL, SA].indexOf(type) !== -1 ? ID : type;
      });
    }
    var forbiddenBreakpoints = options.wordBreak === "keep-all" ? isLetterNumber.map(function(letterNumber, i) {
      return letterNumber && codePoints[i] >= 19968 && codePoints[i] <= 40959;
    }) : void 0;
    return [indicies, classTypes, forbiddenBreakpoints];
  };
  var Break = (
    /** @class */
    (function() {
      function Break2(codePoints, lineBreak2, start, end) {
        this.codePoints = codePoints;
        this.required = lineBreak2 === BREAK_MANDATORY;
        this.start = start;
        this.end = end;
      }
      Break2.prototype.slice = function() {
        return fromCodePoint$1.apply(void 0, this.codePoints.slice(this.start, this.end));
      };
      return Break2;
    })()
  );
  var LineBreaker = function(str, options) {
    var codePoints = toCodePoints$1(str);
    var _a = cssFormattedClasses(codePoints, options), indicies = _a[0], classTypes = _a[1], forbiddenBreakpoints = _a[2];
    var length = codePoints.length;
    var lastEnd = 0;
    var nextIndex = 0;
    return {
      next: function() {
        if (nextIndex >= length) {
          return { done: true, value: null };
        }
        var lineBreak2 = BREAK_NOT_ALLOWED$1;
        while (nextIndex < length && (lineBreak2 = _lineBreakAtIndex(codePoints, classTypes, indicies, ++nextIndex, forbiddenBreakpoints)) === BREAK_NOT_ALLOWED$1) {
        }
        if (lineBreak2 !== BREAK_NOT_ALLOWED$1 || nextIndex === length) {
          var value = new Break(codePoints, lineBreak2, lastEnd, nextIndex);
          lastEnd = nextIndex;
          return { value, done: false };
        }
        return { done: true, value: null };
      }
    };
  };
  var FLAG_UNRESTRICTED = 1 << 0;
  var FLAG_ID = 1 << 1;
  var FLAG_INTEGER = 1 << 2;
  var FLAG_NUMBER = 1 << 3;
  var LINE_FEED = 10;
  var SOLIDUS = 47;
  var REVERSE_SOLIDUS = 92;
  var CHARACTER_TABULATION = 9;
  var SPACE = 32;
  var QUOTATION_MARK = 34;
  var EQUALS_SIGN = 61;
  var NUMBER_SIGN = 35;
  var DOLLAR_SIGN = 36;
  var PERCENTAGE_SIGN = 37;
  var APOSTROPHE = 39;
  var LEFT_PARENTHESIS = 40;
  var RIGHT_PARENTHESIS = 41;
  var LOW_LINE = 95;
  var HYPHEN_MINUS = 45;
  var EXCLAMATION_MARK = 33;
  var LESS_THAN_SIGN = 60;
  var GREATER_THAN_SIGN = 62;
  var COMMERCIAL_AT = 64;
  var LEFT_SQUARE_BRACKET = 91;
  var RIGHT_SQUARE_BRACKET = 93;
  var CIRCUMFLEX_ACCENT = 61;
  var LEFT_CURLY_BRACKET = 123;
  var QUESTION_MARK = 63;
  var RIGHT_CURLY_BRACKET = 125;
  var VERTICAL_LINE = 124;
  var TILDE = 126;
  var CONTROL = 128;
  var REPLACEMENT_CHARACTER = 65533;
  var ASTERISK = 42;
  var PLUS_SIGN = 43;
  var COMMA = 44;
  var COLON = 58;
  var SEMICOLON = 59;
  var FULL_STOP = 46;
  var NULL = 0;
  var BACKSPACE = 8;
  var LINE_TABULATION = 11;
  var SHIFT_OUT = 14;
  var INFORMATION_SEPARATOR_ONE = 31;
  var DELETE = 127;
  var EOF = -1;
  var ZERO = 48;
  var a = 97;
  var e = 101;
  var f = 102;
  var u = 117;
  var z = 122;
  var A = 65;
  var E = 69;
  var F = 70;
  var U = 85;
  var Z = 90;
  var isDigit = function(codePoint) {
    return codePoint >= ZERO && codePoint <= 57;
  };
  var isSurrogateCodePoint = function(codePoint) {
    return codePoint >= 55296 && codePoint <= 57343;
  };
  var isHex = function(codePoint) {
    return isDigit(codePoint) || codePoint >= A && codePoint <= F || codePoint >= a && codePoint <= f;
  };
  var isLowerCaseLetter = function(codePoint) {
    return codePoint >= a && codePoint <= z;
  };
  var isUpperCaseLetter = function(codePoint) {
    return codePoint >= A && codePoint <= Z;
  };
  var isLetter = function(codePoint) {
    return isLowerCaseLetter(codePoint) || isUpperCaseLetter(codePoint);
  };
  var isNonASCIICodePoint = function(codePoint) {
    return codePoint >= CONTROL;
  };
  var isWhiteSpace = function(codePoint) {
    return codePoint === LINE_FEED || codePoint === CHARACTER_TABULATION || codePoint === SPACE;
  };
  var isNameStartCodePoint = function(codePoint) {
    return isLetter(codePoint) || isNonASCIICodePoint(codePoint) || codePoint === LOW_LINE;
  };
  var isNameCodePoint = function(codePoint) {
    return isNameStartCodePoint(codePoint) || isDigit(codePoint) || codePoint === HYPHEN_MINUS;
  };
  var isNonPrintableCodePoint = function(codePoint) {
    return codePoint >= NULL && codePoint <= BACKSPACE || codePoint === LINE_TABULATION || codePoint >= SHIFT_OUT && codePoint <= INFORMATION_SEPARATOR_ONE || codePoint === DELETE;
  };
  var isValidEscape = function(c1, c2) {
    if (c1 !== REVERSE_SOLIDUS) {
      return false;
    }
    return c2 !== LINE_FEED;
  };
  var isIdentifierStart = function(c1, c2, c3) {
    if (c1 === HYPHEN_MINUS) {
      return isNameStartCodePoint(c2) || isValidEscape(c2, c3);
    } else if (isNameStartCodePoint(c1)) {
      return true;
    } else if (c1 === REVERSE_SOLIDUS && isValidEscape(c1, c2)) {
      return true;
    }
    return false;
  };
  var isNumberStart = function(c1, c2, c3) {
    if (c1 === PLUS_SIGN || c1 === HYPHEN_MINUS) {
      if (isDigit(c2)) {
        return true;
      }
      return c2 === FULL_STOP && isDigit(c3);
    }
    if (c1 === FULL_STOP) {
      return isDigit(c2);
    }
    return isDigit(c1);
  };
  var stringToNumber = function(codePoints) {
    var c = 0;
    var sign = 1;
    if (codePoints[c] === PLUS_SIGN || codePoints[c] === HYPHEN_MINUS) {
      if (codePoints[c] === HYPHEN_MINUS) {
        sign = -1;
      }
      c++;
    }
    var integers = [];
    while (isDigit(codePoints[c])) {
      integers.push(codePoints[c++]);
    }
    var int = integers.length ? parseInt(fromCodePoint$1.apply(void 0, integers), 10) : 0;
    if (codePoints[c] === FULL_STOP) {
      c++;
    }
    var fraction = [];
    while (isDigit(codePoints[c])) {
      fraction.push(codePoints[c++]);
    }
    var fracd = fraction.length;
    var frac = fracd ? parseInt(fromCodePoint$1.apply(void 0, fraction), 10) : 0;
    if (codePoints[c] === E || codePoints[c] === e) {
      c++;
    }
    var expsign = 1;
    if (codePoints[c] === PLUS_SIGN || codePoints[c] === HYPHEN_MINUS) {
      if (codePoints[c] === HYPHEN_MINUS) {
        expsign = -1;
      }
      c++;
    }
    var exponent = [];
    while (isDigit(codePoints[c])) {
      exponent.push(codePoints[c++]);
    }
    var exp = exponent.length ? parseInt(fromCodePoint$1.apply(void 0, exponent), 10) : 0;
    return sign * (int + frac * Math.pow(10, -fracd)) * Math.pow(10, expsign * exp);
  };
  var LEFT_PARENTHESIS_TOKEN = {
    type: 2
    /* LEFT_PARENTHESIS_TOKEN */
  };
  var RIGHT_PARENTHESIS_TOKEN = {
    type: 3
    /* RIGHT_PARENTHESIS_TOKEN */
  };
  var COMMA_TOKEN = {
    type: 4
    /* COMMA_TOKEN */
  };
  var SUFFIX_MATCH_TOKEN = {
    type: 13
    /* SUFFIX_MATCH_TOKEN */
  };
  var PREFIX_MATCH_TOKEN = {
    type: 8
    /* PREFIX_MATCH_TOKEN */
  };
  var COLUMN_TOKEN = {
    type: 21
    /* COLUMN_TOKEN */
  };
  var DASH_MATCH_TOKEN = {
    type: 9
    /* DASH_MATCH_TOKEN */
  };
  var INCLUDE_MATCH_TOKEN = {
    type: 10
    /* INCLUDE_MATCH_TOKEN */
  };
  var LEFT_CURLY_BRACKET_TOKEN = {
    type: 11
    /* LEFT_CURLY_BRACKET_TOKEN */
  };
  var RIGHT_CURLY_BRACKET_TOKEN = {
    type: 12
    /* RIGHT_CURLY_BRACKET_TOKEN */
  };
  var SUBSTRING_MATCH_TOKEN = {
    type: 14
    /* SUBSTRING_MATCH_TOKEN */
  };
  var BAD_URL_TOKEN = {
    type: 23
    /* BAD_URL_TOKEN */
  };
  var BAD_STRING_TOKEN = {
    type: 1
    /* BAD_STRING_TOKEN */
  };
  var CDO_TOKEN = {
    type: 25
    /* CDO_TOKEN */
  };
  var CDC_TOKEN = {
    type: 24
    /* CDC_TOKEN */
  };
  var COLON_TOKEN = {
    type: 26
    /* COLON_TOKEN */
  };
  var SEMICOLON_TOKEN = {
    type: 27
    /* SEMICOLON_TOKEN */
  };
  var LEFT_SQUARE_BRACKET_TOKEN = {
    type: 28
    /* LEFT_SQUARE_BRACKET_TOKEN */
  };
  var RIGHT_SQUARE_BRACKET_TOKEN = {
    type: 29
    /* RIGHT_SQUARE_BRACKET_TOKEN */
  };
  var WHITESPACE_TOKEN = {
    type: 31
    /* WHITESPACE_TOKEN */
  };
  var EOF_TOKEN = {
    type: 32
    /* EOF_TOKEN */
  };
  var Tokenizer = (
    /** @class */
    (function() {
      function Tokenizer2() {
        this._value = [];
      }
      Tokenizer2.prototype.write = function(chunk) {
        this._value = this._value.concat(toCodePoints$1(chunk));
      };
      Tokenizer2.prototype.read = function() {
        var tokens = [];
        var token = this.consumeToken();
        while (token !== EOF_TOKEN) {
          tokens.push(token);
          token = this.consumeToken();
        }
        return tokens;
      };
      Tokenizer2.prototype.consumeToken = function() {
        var codePoint = this.consumeCodePoint();
        switch (codePoint) {
          case QUOTATION_MARK:
            return this.consumeStringToken(QUOTATION_MARK);
          case NUMBER_SIGN:
            var c1 = this.peekCodePoint(0);
            var c2 = this.peekCodePoint(1);
            var c3 = this.peekCodePoint(2);
            if (isNameCodePoint(c1) || isValidEscape(c2, c3)) {
              var flags = isIdentifierStart(c1, c2, c3) ? FLAG_ID : FLAG_UNRESTRICTED;
              var value = this.consumeName();
              return { type: 5, value, flags };
            }
            break;
          case DOLLAR_SIGN:
            if (this.peekCodePoint(0) === EQUALS_SIGN) {
              this.consumeCodePoint();
              return SUFFIX_MATCH_TOKEN;
            }
            break;
          case APOSTROPHE:
            return this.consumeStringToken(APOSTROPHE);
          case LEFT_PARENTHESIS:
            return LEFT_PARENTHESIS_TOKEN;
          case RIGHT_PARENTHESIS:
            return RIGHT_PARENTHESIS_TOKEN;
          case ASTERISK:
            if (this.peekCodePoint(0) === EQUALS_SIGN) {
              this.consumeCodePoint();
              return SUBSTRING_MATCH_TOKEN;
            }
            break;
          case PLUS_SIGN:
            if (isNumberStart(codePoint, this.peekCodePoint(0), this.peekCodePoint(1))) {
              this.reconsumeCodePoint(codePoint);
              return this.consumeNumericToken();
            }
            break;
          case COMMA:
            return COMMA_TOKEN;
          case HYPHEN_MINUS:
            var e1 = codePoint;
            var e2 = this.peekCodePoint(0);
            var e3 = this.peekCodePoint(1);
            if (isNumberStart(e1, e2, e3)) {
              this.reconsumeCodePoint(codePoint);
              return this.consumeNumericToken();
            }
            if (isIdentifierStart(e1, e2, e3)) {
              this.reconsumeCodePoint(codePoint);
              return this.consumeIdentLikeToken();
            }
            if (e2 === HYPHEN_MINUS && e3 === GREATER_THAN_SIGN) {
              this.consumeCodePoint();
              this.consumeCodePoint();
              return CDC_TOKEN;
            }
            break;
          case FULL_STOP:
            if (isNumberStart(codePoint, this.peekCodePoint(0), this.peekCodePoint(1))) {
              this.reconsumeCodePoint(codePoint);
              return this.consumeNumericToken();
            }
            break;
          case SOLIDUS:
            if (this.peekCodePoint(0) === ASTERISK) {
              this.consumeCodePoint();
              while (true) {
                var c = this.consumeCodePoint();
                if (c === ASTERISK) {
                  c = this.consumeCodePoint();
                  if (c === SOLIDUS) {
                    return this.consumeToken();
                  }
                }
                if (c === EOF) {
                  return this.consumeToken();
                }
              }
            }
            break;
          case COLON:
            return COLON_TOKEN;
          case SEMICOLON:
            return SEMICOLON_TOKEN;
          case LESS_THAN_SIGN:
            if (this.peekCodePoint(0) === EXCLAMATION_MARK && this.peekCodePoint(1) === HYPHEN_MINUS && this.peekCodePoint(2) === HYPHEN_MINUS) {
              this.consumeCodePoint();
              this.consumeCodePoint();
              return CDO_TOKEN;
            }
            break;
          case COMMERCIAL_AT:
            var a1 = this.peekCodePoint(0);
            var a2 = this.peekCodePoint(1);
            var a3 = this.peekCodePoint(2);
            if (isIdentifierStart(a1, a2, a3)) {
              var value = this.consumeName();
              return { type: 7, value };
            }
            break;
          case LEFT_SQUARE_BRACKET:
            return LEFT_SQUARE_BRACKET_TOKEN;
          case REVERSE_SOLIDUS:
            if (isValidEscape(codePoint, this.peekCodePoint(0))) {
              this.reconsumeCodePoint(codePoint);
              return this.consumeIdentLikeToken();
            }
            break;
          case RIGHT_SQUARE_BRACKET:
            return RIGHT_SQUARE_BRACKET_TOKEN;
          case CIRCUMFLEX_ACCENT:
            if (this.peekCodePoint(0) === EQUALS_SIGN) {
              this.consumeCodePoint();
              return PREFIX_MATCH_TOKEN;
            }
            break;
          case LEFT_CURLY_BRACKET:
            return LEFT_CURLY_BRACKET_TOKEN;
          case RIGHT_CURLY_BRACKET:
            return RIGHT_CURLY_BRACKET_TOKEN;
          case u:
          case U:
            var u1 = this.peekCodePoint(0);
            var u2 = this.peekCodePoint(1);
            if (u1 === PLUS_SIGN && (isHex(u2) || u2 === QUESTION_MARK)) {
              this.consumeCodePoint();
              this.consumeUnicodeRangeToken();
            }
            this.reconsumeCodePoint(codePoint);
            return this.consumeIdentLikeToken();
          case VERTICAL_LINE:
            if (this.peekCodePoint(0) === EQUALS_SIGN) {
              this.consumeCodePoint();
              return DASH_MATCH_TOKEN;
            }
            if (this.peekCodePoint(0) === VERTICAL_LINE) {
              this.consumeCodePoint();
              return COLUMN_TOKEN;
            }
            break;
          case TILDE:
            if (this.peekCodePoint(0) === EQUALS_SIGN) {
              this.consumeCodePoint();
              return INCLUDE_MATCH_TOKEN;
            }
            break;
          case EOF:
            return EOF_TOKEN;
        }
        if (isWhiteSpace(codePoint)) {
          this.consumeWhiteSpace();
          return WHITESPACE_TOKEN;
        }
        if (isDigit(codePoint)) {
          this.reconsumeCodePoint(codePoint);
          return this.consumeNumericToken();
        }
        if (isNameStartCodePoint(codePoint)) {
          this.reconsumeCodePoint(codePoint);
          return this.consumeIdentLikeToken();
        }
        return { type: 6, value: fromCodePoint$1(codePoint) };
      };
      Tokenizer2.prototype.consumeCodePoint = function() {
        var value = this._value.shift();
        return typeof value === "undefined" ? -1 : value;
      };
      Tokenizer2.prototype.reconsumeCodePoint = function(codePoint) {
        this._value.unshift(codePoint);
      };
      Tokenizer2.prototype.peekCodePoint = function(delta) {
        if (delta >= this._value.length) {
          return -1;
        }
        return this._value[delta];
      };
      Tokenizer2.prototype.consumeUnicodeRangeToken = function() {
        var digits = [];
        var codePoint = this.consumeCodePoint();
        while (isHex(codePoint) && digits.length < 6) {
          digits.push(codePoint);
          codePoint = this.consumeCodePoint();
        }
        var questionMarks = false;
        while (codePoint === QUESTION_MARK && digits.length < 6) {
          digits.push(codePoint);
          codePoint = this.consumeCodePoint();
          questionMarks = true;
        }
        if (questionMarks) {
          var start_1 = parseInt(fromCodePoint$1.apply(void 0, digits.map(function(digit) {
            return digit === QUESTION_MARK ? ZERO : digit;
          })), 16);
          var end = parseInt(fromCodePoint$1.apply(void 0, digits.map(function(digit) {
            return digit === QUESTION_MARK ? F : digit;
          })), 16);
          return { type: 30, start: start_1, end };
        }
        var start = parseInt(fromCodePoint$1.apply(void 0, digits), 16);
        if (this.peekCodePoint(0) === HYPHEN_MINUS && isHex(this.peekCodePoint(1))) {
          this.consumeCodePoint();
          codePoint = this.consumeCodePoint();
          var endDigits = [];
          while (isHex(codePoint) && endDigits.length < 6) {
            endDigits.push(codePoint);
            codePoint = this.consumeCodePoint();
          }
          var end = parseInt(fromCodePoint$1.apply(void 0, endDigits), 16);
          return { type: 30, start, end };
        } else {
          return { type: 30, start, end: start };
        }
      };
      Tokenizer2.prototype.consumeIdentLikeToken = function() {
        var value = this.consumeName();
        if (value.toLowerCase() === "url" && this.peekCodePoint(0) === LEFT_PARENTHESIS) {
          this.consumeCodePoint();
          return this.consumeUrlToken();
        } else if (this.peekCodePoint(0) === LEFT_PARENTHESIS) {
          this.consumeCodePoint();
          return { type: 19, value };
        }
        return { type: 20, value };
      };
      Tokenizer2.prototype.consumeUrlToken = function() {
        var value = [];
        this.consumeWhiteSpace();
        if (this.peekCodePoint(0) === EOF) {
          return { type: 22, value: "" };
        }
        var next = this.peekCodePoint(0);
        if (next === APOSTROPHE || next === QUOTATION_MARK) {
          var stringToken = this.consumeStringToken(this.consumeCodePoint());
          if (stringToken.type === 0) {
            this.consumeWhiteSpace();
            if (this.peekCodePoint(0) === EOF || this.peekCodePoint(0) === RIGHT_PARENTHESIS) {
              this.consumeCodePoint();
              return { type: 22, value: stringToken.value };
            }
          }
          this.consumeBadUrlRemnants();
          return BAD_URL_TOKEN;
        }
        while (true) {
          var codePoint = this.consumeCodePoint();
          if (codePoint === EOF || codePoint === RIGHT_PARENTHESIS) {
            return { type: 22, value: fromCodePoint$1.apply(void 0, value) };
          } else if (isWhiteSpace(codePoint)) {
            this.consumeWhiteSpace();
            if (this.peekCodePoint(0) === EOF || this.peekCodePoint(0) === RIGHT_PARENTHESIS) {
              this.consumeCodePoint();
              return { type: 22, value: fromCodePoint$1.apply(void 0, value) };
            }
            this.consumeBadUrlRemnants();
            return BAD_URL_TOKEN;
          } else if (codePoint === QUOTATION_MARK || codePoint === APOSTROPHE || codePoint === LEFT_PARENTHESIS || isNonPrintableCodePoint(codePoint)) {
            this.consumeBadUrlRemnants();
            return BAD_URL_TOKEN;
          } else if (codePoint === REVERSE_SOLIDUS) {
            if (isValidEscape(codePoint, this.peekCodePoint(0))) {
              value.push(this.consumeEscapedCodePoint());
            } else {
              this.consumeBadUrlRemnants();
              return BAD_URL_TOKEN;
            }
          } else {
            value.push(codePoint);
          }
        }
      };
      Tokenizer2.prototype.consumeWhiteSpace = function() {
        while (isWhiteSpace(this.peekCodePoint(0))) {
          this.consumeCodePoint();
        }
      };
      Tokenizer2.prototype.consumeBadUrlRemnants = function() {
        while (true) {
          var codePoint = this.consumeCodePoint();
          if (codePoint === RIGHT_PARENTHESIS || codePoint === EOF) {
            return;
          }
          if (isValidEscape(codePoint, this.peekCodePoint(0))) {
            this.consumeEscapedCodePoint();
          }
        }
      };
      Tokenizer2.prototype.consumeStringSlice = function(count) {
        var SLICE_STACK_SIZE = 5e4;
        var value = "";
        while (count > 0) {
          var amount = Math.min(SLICE_STACK_SIZE, count);
          value += fromCodePoint$1.apply(void 0, this._value.splice(0, amount));
          count -= amount;
        }
        this._value.shift();
        return value;
      };
      Tokenizer2.prototype.consumeStringToken = function(endingCodePoint) {
        var value = "";
        var i = 0;
        do {
          var codePoint = this._value[i];
          if (codePoint === EOF || codePoint === void 0 || codePoint === endingCodePoint) {
            value += this.consumeStringSlice(i);
            return { type: 0, value };
          }
          if (codePoint === LINE_FEED) {
            this._value.splice(0, i);
            return BAD_STRING_TOKEN;
          }
          if (codePoint === REVERSE_SOLIDUS) {
            var next = this._value[i + 1];
            if (next !== EOF && next !== void 0) {
              if (next === LINE_FEED) {
                value += this.consumeStringSlice(i);
                i = -1;
                this._value.shift();
              } else if (isValidEscape(codePoint, next)) {
                value += this.consumeStringSlice(i);
                value += fromCodePoint$1(this.consumeEscapedCodePoint());
                i = -1;
              }
            }
          }
          i++;
        } while (true);
      };
      Tokenizer2.prototype.consumeNumber = function() {
        var repr = [];
        var type = FLAG_INTEGER;
        var c1 = this.peekCodePoint(0);
        if (c1 === PLUS_SIGN || c1 === HYPHEN_MINUS) {
          repr.push(this.consumeCodePoint());
        }
        while (isDigit(this.peekCodePoint(0))) {
          repr.push(this.consumeCodePoint());
        }
        c1 = this.peekCodePoint(0);
        var c2 = this.peekCodePoint(1);
        if (c1 === FULL_STOP && isDigit(c2)) {
          repr.push(this.consumeCodePoint(), this.consumeCodePoint());
          type = FLAG_NUMBER;
          while (isDigit(this.peekCodePoint(0))) {
            repr.push(this.consumeCodePoint());
          }
        }
        c1 = this.peekCodePoint(0);
        c2 = this.peekCodePoint(1);
        var c3 = this.peekCodePoint(2);
        if ((c1 === E || c1 === e) && ((c2 === PLUS_SIGN || c2 === HYPHEN_MINUS) && isDigit(c3) || isDigit(c2))) {
          repr.push(this.consumeCodePoint(), this.consumeCodePoint());
          type = FLAG_NUMBER;
          while (isDigit(this.peekCodePoint(0))) {
            repr.push(this.consumeCodePoint());
          }
        }
        return [stringToNumber(repr), type];
      };
      Tokenizer2.prototype.consumeNumericToken = function() {
        var _a = this.consumeNumber(), number = _a[0], flags = _a[1];
        var c1 = this.peekCodePoint(0);
        var c2 = this.peekCodePoint(1);
        var c3 = this.peekCodePoint(2);
        if (isIdentifierStart(c1, c2, c3)) {
          var unit = this.consumeName();
          return { type: 15, number, flags, unit };
        }
        if (c1 === PERCENTAGE_SIGN) {
          this.consumeCodePoint();
          return { type: 16, number, flags };
        }
        return { type: 17, number, flags };
      };
      Tokenizer2.prototype.consumeEscapedCodePoint = function() {
        var codePoint = this.consumeCodePoint();
        if (isHex(codePoint)) {
          var hex = fromCodePoint$1(codePoint);
          while (isHex(this.peekCodePoint(0)) && hex.length < 6) {
            hex += fromCodePoint$1(this.consumeCodePoint());
          }
          if (isWhiteSpace(this.peekCodePoint(0))) {
            this.consumeCodePoint();
          }
          var hexCodePoint = parseInt(hex, 16);
          if (hexCodePoint === 0 || isSurrogateCodePoint(hexCodePoint) || hexCodePoint > 1114111) {
            return REPLACEMENT_CHARACTER;
          }
          return hexCodePoint;
        }
        if (codePoint === EOF) {
          return REPLACEMENT_CHARACTER;
        }
        return codePoint;
      };
      Tokenizer2.prototype.consumeName = function() {
        var result = "";
        while (true) {
          var codePoint = this.consumeCodePoint();
          if (isNameCodePoint(codePoint)) {
            result += fromCodePoint$1(codePoint);
          } else if (isValidEscape(codePoint, this.peekCodePoint(0))) {
            result += fromCodePoint$1(this.consumeEscapedCodePoint());
          } else {
            this.reconsumeCodePoint(codePoint);
            return result;
          }
        }
      };
      return Tokenizer2;
    })()
  );
  var Parser = (
    /** @class */
    (function() {
      function Parser2(tokens) {
        this._tokens = tokens;
      }
      Parser2.create = function(value) {
        var tokenizer = new Tokenizer();
        tokenizer.write(value);
        return new Parser2(tokenizer.read());
      };
      Parser2.parseValue = function(value) {
        return Parser2.create(value).parseComponentValue();
      };
      Parser2.parseValues = function(value) {
        return Parser2.create(value).parseComponentValues();
      };
      Parser2.prototype.parseComponentValue = function() {
        var token = this.consumeToken();
        while (token.type === 31) {
          token = this.consumeToken();
        }
        if (token.type === 32) {
          throw new SyntaxError("Error parsing CSS component value, unexpected EOF");
        }
        this.reconsumeToken(token);
        var value = this.consumeComponentValue();
        do {
          token = this.consumeToken();
        } while (token.type === 31);
        if (token.type === 32) {
          return value;
        }
        throw new SyntaxError("Error parsing CSS component value, multiple values found when expecting only one");
      };
      Parser2.prototype.parseComponentValues = function() {
        var values = [];
        while (true) {
          var value = this.consumeComponentValue();
          if (value.type === 32) {
            return values;
          }
          values.push(value);
          values.push();
        }
      };
      Parser2.prototype.consumeComponentValue = function() {
        var token = this.consumeToken();
        switch (token.type) {
          case 11:
          case 28:
          case 2:
            return this.consumeSimpleBlock(token.type);
          case 19:
            return this.consumeFunction(token);
        }
        return token;
      };
      Parser2.prototype.consumeSimpleBlock = function(type) {
        var block = { type, values: [] };
        var token = this.consumeToken();
        while (true) {
          if (token.type === 32 || isEndingTokenFor(token, type)) {
            return block;
          }
          this.reconsumeToken(token);
          block.values.push(this.consumeComponentValue());
          token = this.consumeToken();
        }
      };
      Parser2.prototype.consumeFunction = function(functionToken) {
        var cssFunction = {
          name: functionToken.value,
          values: [],
          type: 18
          /* FUNCTION */
        };
        while (true) {
          var token = this.consumeToken();
          if (token.type === 32 || token.type === 3) {
            return cssFunction;
          }
          this.reconsumeToken(token);
          cssFunction.values.push(this.consumeComponentValue());
        }
      };
      Parser2.prototype.consumeToken = function() {
        var token = this._tokens.shift();
        return typeof token === "undefined" ? EOF_TOKEN : token;
      };
      Parser2.prototype.reconsumeToken = function(token) {
        this._tokens.unshift(token);
      };
      return Parser2;
    })()
  );
  var isDimensionToken = function(token) {
    return token.type === 15;
  };
  var isNumberToken = function(token) {
    return token.type === 17;
  };
  var isIdentToken = function(token) {
    return token.type === 20;
  };
  var isStringToken = function(token) {
    return token.type === 0;
  };
  var isIdentWithValue = function(token, value) {
    return isIdentToken(token) && token.value === value;
  };
  var nonWhiteSpace = function(token) {
    return token.type !== 31;
  };
  var nonFunctionArgSeparator = function(token) {
    return token.type !== 31 && token.type !== 4;
  };
  var parseFunctionArgs = function(tokens) {
    var args = [];
    var arg = [];
    tokens.forEach(function(token) {
      if (token.type === 4) {
        if (arg.length === 0) {
          throw new Error("Error parsing function args, zero tokens for arg");
        }
        args.push(arg);
        arg = [];
        return;
      }
      if (token.type !== 31) {
        arg.push(token);
      }
    });
    if (arg.length) {
      args.push(arg);
    }
    return args;
  };
  var isEndingTokenFor = function(token, type) {
    if (type === 11 && token.type === 12) {
      return true;
    }
    if (type === 28 && token.type === 29) {
      return true;
    }
    return type === 2 && token.type === 3;
  };
  var isLength = function(token) {
    return token.type === 17 || token.type === 15;
  };
  var isLengthPercentage = function(token) {
    return token.type === 16 || isLength(token);
  };
  var parseLengthPercentageTuple = function(tokens) {
    return tokens.length > 1 ? [tokens[0], tokens[1]] : [tokens[0]];
  };
  var ZERO_LENGTH = {
    type: 17,
    number: 0,
    flags: FLAG_INTEGER
  };
  var FIFTY_PERCENT = {
    type: 16,
    number: 50,
    flags: FLAG_INTEGER
  };
  var HUNDRED_PERCENT = {
    type: 16,
    number: 100,
    flags: FLAG_INTEGER
  };
  var getAbsoluteValueForTuple = function(tuple, width, height) {
    var x = tuple[0], y = tuple[1];
    return [getAbsoluteValue(x, width), getAbsoluteValue(typeof y !== "undefined" ? y : x, height)];
  };
  var getAbsoluteValue = function(token, parent) {
    if (token.type === 16) {
      return token.number / 100 * parent;
    }
    if (isDimensionToken(token)) {
      switch (token.unit) {
        case "rem":
        case "em":
          return 16 * token.number;
        // TODO use correct font-size
        case "px":
        default:
          return token.number;
      }
    }
    return token.number;
  };
  var DEG = "deg";
  var GRAD = "grad";
  var RAD = "rad";
  var TURN = "turn";
  var angle = {
    name: "angle",
    parse: function(_context, value) {
      if (value.type === 15) {
        switch (value.unit) {
          case DEG:
            return Math.PI * value.number / 180;
          case GRAD:
            return Math.PI / 200 * value.number;
          case RAD:
            return value.number;
          case TURN:
            return Math.PI * 2 * value.number;
        }
      }
      throw new Error("Unsupported angle type");
    }
  };
  var isAngle = function(value) {
    if (value.type === 15) {
      if (value.unit === DEG || value.unit === GRAD || value.unit === RAD || value.unit === TURN) {
        return true;
      }
    }
    return false;
  };
  var parseNamedSide = function(tokens) {
    var sideOrCorner = tokens.filter(isIdentToken).map(function(ident) {
      return ident.value;
    }).join(" ");
    switch (sideOrCorner) {
      case "to bottom right":
      case "to right bottom":
      case "left top":
      case "top left":
        return [ZERO_LENGTH, ZERO_LENGTH];
      case "to top":
      case "bottom":
        return deg(0);
      case "to bottom left":
      case "to left bottom":
      case "right top":
      case "top right":
        return [ZERO_LENGTH, HUNDRED_PERCENT];
      case "to right":
      case "left":
        return deg(90);
      case "to top left":
      case "to left top":
      case "right bottom":
      case "bottom right":
        return [HUNDRED_PERCENT, HUNDRED_PERCENT];
      case "to bottom":
      case "top":
        return deg(180);
      case "to top right":
      case "to right top":
      case "left bottom":
      case "bottom left":
        return [HUNDRED_PERCENT, ZERO_LENGTH];
      case "to left":
      case "right":
        return deg(270);
    }
    return 0;
  };
  var deg = function(deg2) {
    return Math.PI * deg2 / 180;
  };
  var color$1 = {
    name: "color",
    parse: function(context, value) {
      if (value.type === 18) {
        var colorFunction = SUPPORTED_COLOR_FUNCTIONS[value.name];
        if (typeof colorFunction === "undefined") {
          throw new Error('Attempting to parse an unsupported color function "' + value.name + '"');
        }
        return colorFunction(context, value.values);
      }
      if (value.type === 5) {
        if (value.value.length === 3) {
          var r = value.value.substring(0, 1);
          var g = value.value.substring(1, 2);
          var b = value.value.substring(2, 3);
          return pack(parseInt(r + r, 16), parseInt(g + g, 16), parseInt(b + b, 16), 1);
        }
        if (value.value.length === 4) {
          var r = value.value.substring(0, 1);
          var g = value.value.substring(1, 2);
          var b = value.value.substring(2, 3);
          var a2 = value.value.substring(3, 4);
          return pack(parseInt(r + r, 16), parseInt(g + g, 16), parseInt(b + b, 16), parseInt(a2 + a2, 16) / 255);
        }
        if (value.value.length === 6) {
          var r = value.value.substring(0, 2);
          var g = value.value.substring(2, 4);
          var b = value.value.substring(4, 6);
          return pack(parseInt(r, 16), parseInt(g, 16), parseInt(b, 16), 1);
        }
        if (value.value.length === 8) {
          var r = value.value.substring(0, 2);
          var g = value.value.substring(2, 4);
          var b = value.value.substring(4, 6);
          var a2 = value.value.substring(6, 8);
          return pack(parseInt(r, 16), parseInt(g, 16), parseInt(b, 16), parseInt(a2, 16) / 255);
        }
      }
      if (value.type === 20) {
        var namedColor = COLORS[value.value.toUpperCase()];
        if (typeof namedColor !== "undefined") {
          return namedColor;
        }
      }
      return COLORS.TRANSPARENT;
    }
  };
  var isTransparent = function(color2) {
    return (255 & color2) === 0;
  };
  var asString = function(color2) {
    var alpha = 255 & color2;
    var blue = 255 & color2 >> 8;
    var green = 255 & color2 >> 16;
    var red = 255 & color2 >> 24;
    return alpha < 255 ? "rgba(" + red + "," + green + "," + blue + "," + alpha / 255 + ")" : "rgb(" + red + "," + green + "," + blue + ")";
  };
  var pack = function(r, g, b, a2) {
    return (r << 24 | g << 16 | b << 8 | Math.round(a2 * 255) << 0) >>> 0;
  };
  var getTokenColorValue = function(token, i) {
    if (token.type === 17) {
      return token.number;
    }
    if (token.type === 16) {
      var max = i === 3 ? 1 : 255;
      return i === 3 ? token.number / 100 * max : Math.round(token.number / 100 * max);
    }
    return 0;
  };
  var rgb = function(_context, args) {
    var tokens = args.filter(nonFunctionArgSeparator);
    if (tokens.length === 3) {
      var _a = tokens.map(getTokenColorValue), r = _a[0], g = _a[1], b = _a[2];
      return pack(r, g, b, 1);
    }
    if (tokens.length === 4) {
      var _b = tokens.map(getTokenColorValue), r = _b[0], g = _b[1], b = _b[2], a2 = _b[3];
      return pack(r, g, b, a2);
    }
    return 0;
  };
  function hue2rgb(t1, t2, hue) {
    if (hue < 0) {
      hue += 1;
    }
    if (hue >= 1) {
      hue -= 1;
    }
    if (hue < 1 / 6) {
      return (t2 - t1) * hue * 6 + t1;
    } else if (hue < 1 / 2) {
      return t2;
    } else if (hue < 2 / 3) {
      return (t2 - t1) * 6 * (2 / 3 - hue) + t1;
    } else {
      return t1;
    }
  }
  var hsl = function(context, args) {
    var tokens = args.filter(nonFunctionArgSeparator);
    var hue = tokens[0], saturation = tokens[1], lightness = tokens[2], alpha = tokens[3];
    var h = (hue.type === 17 ? deg(hue.number) : angle.parse(context, hue)) / (Math.PI * 2);
    var s = isLengthPercentage(saturation) ? saturation.number / 100 : 0;
    var l = isLengthPercentage(lightness) ? lightness.number / 100 : 0;
    var a2 = typeof alpha !== "undefined" && isLengthPercentage(alpha) ? getAbsoluteValue(alpha, 1) : 1;
    if (s === 0) {
      return pack(l * 255, l * 255, l * 255, 1);
    }
    var t2 = l <= 0.5 ? l * (s + 1) : l + s - l * s;
    var t1 = l * 2 - t2;
    var r = hue2rgb(t1, t2, h + 1 / 3);
    var g = hue2rgb(t1, t2, h);
    var b = hue2rgb(t1, t2, h - 1 / 3);
    return pack(r * 255, g * 255, b * 255, a2);
  };
  var SUPPORTED_COLOR_FUNCTIONS = {
    hsl,
    hsla: hsl,
    rgb,
    rgba: rgb
  };
  var parseColor = function(context, value) {
    return color$1.parse(context, Parser.create(value).parseComponentValue());
  };
  var COLORS = {
    ALICEBLUE: 4042850303,
    ANTIQUEWHITE: 4209760255,
    AQUA: 16777215,
    AQUAMARINE: 2147472639,
    AZURE: 4043309055,
    BEIGE: 4126530815,
    BISQUE: 4293182719,
    BLACK: 255,
    BLANCHEDALMOND: 4293643775,
    BLUE: 65535,
    BLUEVIOLET: 2318131967,
    BROWN: 2771004159,
    BURLYWOOD: 3736635391,
    CADETBLUE: 1604231423,
    CHARTREUSE: 2147418367,
    CHOCOLATE: 3530104575,
    CORAL: 4286533887,
    CORNFLOWERBLUE: 1687547391,
    CORNSILK: 4294499583,
    CRIMSON: 3692313855,
    CYAN: 16777215,
    DARKBLUE: 35839,
    DARKCYAN: 9145343,
    DARKGOLDENROD: 3095837695,
    DARKGRAY: 2846468607,
    DARKGREEN: 6553855,
    DARKGREY: 2846468607,
    DARKKHAKI: 3182914559,
    DARKMAGENTA: 2332068863,
    DARKOLIVEGREEN: 1433087999,
    DARKORANGE: 4287365375,
    DARKORCHID: 2570243327,
    DARKRED: 2332033279,
    DARKSALMON: 3918953215,
    DARKSEAGREEN: 2411499519,
    DARKSLATEBLUE: 1211993087,
    DARKSLATEGRAY: 793726975,
    DARKSLATEGREY: 793726975,
    DARKTURQUOISE: 13554175,
    DARKVIOLET: 2483082239,
    DEEPPINK: 4279538687,
    DEEPSKYBLUE: 12582911,
    DIMGRAY: 1768516095,
    DIMGREY: 1768516095,
    DODGERBLUE: 512819199,
    FIREBRICK: 2988581631,
    FLORALWHITE: 4294635775,
    FORESTGREEN: 579543807,
    FUCHSIA: 4278255615,
    GAINSBORO: 3705462015,
    GHOSTWHITE: 4177068031,
    GOLD: 4292280575,
    GOLDENROD: 3668254975,
    GRAY: 2155905279,
    GREEN: 8388863,
    GREENYELLOW: 2919182335,
    GREY: 2155905279,
    HONEYDEW: 4043305215,
    HOTPINK: 4285117695,
    INDIANRED: 3445382399,
    INDIGO: 1258324735,
    IVORY: 4294963455,
    KHAKI: 4041641215,
    LAVENDER: 3873897215,
    LAVENDERBLUSH: 4293981695,
    LAWNGREEN: 2096890111,
    LEMONCHIFFON: 4294626815,
    LIGHTBLUE: 2916673279,
    LIGHTCORAL: 4034953471,
    LIGHTCYAN: 3774873599,
    LIGHTGOLDENRODYELLOW: 4210742015,
    LIGHTGRAY: 3553874943,
    LIGHTGREEN: 2431553791,
    LIGHTGREY: 3553874943,
    LIGHTPINK: 4290167295,
    LIGHTSALMON: 4288707327,
    LIGHTSEAGREEN: 548580095,
    LIGHTSKYBLUE: 2278488831,
    LIGHTSLATEGRAY: 2005441023,
    LIGHTSLATEGREY: 2005441023,
    LIGHTSTEELBLUE: 2965692159,
    LIGHTYELLOW: 4294959359,
    LIME: 16711935,
    LIMEGREEN: 852308735,
    LINEN: 4210091775,
    MAGENTA: 4278255615,
    MAROON: 2147483903,
    MEDIUMAQUAMARINE: 1724754687,
    MEDIUMBLUE: 52735,
    MEDIUMORCHID: 3126187007,
    MEDIUMPURPLE: 2473647103,
    MEDIUMSEAGREEN: 1018393087,
    MEDIUMSLATEBLUE: 2070474495,
    MEDIUMSPRINGGREEN: 16423679,
    MEDIUMTURQUOISE: 1221709055,
    MEDIUMVIOLETRED: 3340076543,
    MIDNIGHTBLUE: 421097727,
    MINTCREAM: 4127193855,
    MISTYROSE: 4293190143,
    MOCCASIN: 4293178879,
    NAVAJOWHITE: 4292783615,
    NAVY: 33023,
    OLDLACE: 4260751103,
    OLIVE: 2155872511,
    OLIVEDRAB: 1804477439,
    ORANGE: 4289003775,
    ORANGERED: 4282712319,
    ORCHID: 3664828159,
    PALEGOLDENROD: 4008225535,
    PALEGREEN: 2566625535,
    PALETURQUOISE: 2951671551,
    PALEVIOLETRED: 3681588223,
    PAPAYAWHIP: 4293907967,
    PEACHPUFF: 4292524543,
    PERU: 3448061951,
    PINK: 4290825215,
    PLUM: 3718307327,
    POWDERBLUE: 2967529215,
    PURPLE: 2147516671,
    REBECCAPURPLE: 1714657791,
    RED: 4278190335,
    ROSYBROWN: 3163525119,
    ROYALBLUE: 1097458175,
    SADDLEBROWN: 2336560127,
    SALMON: 4202722047,
    SANDYBROWN: 4104413439,
    SEAGREEN: 780883967,
    SEASHELL: 4294307583,
    SIENNA: 2689740287,
    SILVER: 3233857791,
    SKYBLUE: 2278484991,
    SLATEBLUE: 1784335871,
    SLATEGRAY: 1887473919,
    SLATEGREY: 1887473919,
    SNOW: 4294638335,
    SPRINGGREEN: 16744447,
    STEELBLUE: 1182971135,
    TAN: 3535047935,
    TEAL: 8421631,
    THISTLE: 3636451583,
    TOMATO: 4284696575,
    TRANSPARENT: 0,
    TURQUOISE: 1088475391,
    VIOLET: 4001558271,
    WHEAT: 4125012991,
    WHITE: 4294967295,
    WHITESMOKE: 4126537215,
    YELLOW: 4294902015,
    YELLOWGREEN: 2597139199
  };
  var backgroundClip = {
    name: "background-clip",
    initialValue: "border-box",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      return tokens.map(function(token) {
        if (isIdentToken(token)) {
          switch (token.value) {
            case "padding-box":
              return 1;
            case "content-box":
              return 2;
          }
        }
        return 0;
      });
    }
  };
  var backgroundColor = {
    name: "background-color",
    initialValue: "transparent",
    prefix: false,
    type: 3,
    format: "color"
  };
  var parseColorStop = function(context, args) {
    var color2 = color$1.parse(context, args[0]);
    var stop = args[1];
    return stop && isLengthPercentage(stop) ? { color: color2, stop } : { color: color2, stop: null };
  };
  var processColorStops = function(stops, lineLength) {
    var first = stops[0];
    var last = stops[stops.length - 1];
    if (first.stop === null) {
      first.stop = ZERO_LENGTH;
    }
    if (last.stop === null) {
      last.stop = HUNDRED_PERCENT;
    }
    var processStops = [];
    var previous = 0;
    for (var i = 0; i < stops.length; i++) {
      var stop_1 = stops[i].stop;
      if (stop_1 !== null) {
        var absoluteValue = getAbsoluteValue(stop_1, lineLength);
        if (absoluteValue > previous) {
          processStops.push(absoluteValue);
        } else {
          processStops.push(previous);
        }
        previous = absoluteValue;
      } else {
        processStops.push(null);
      }
    }
    var gapBegin = null;
    for (var i = 0; i < processStops.length; i++) {
      var stop_2 = processStops[i];
      if (stop_2 === null) {
        if (gapBegin === null) {
          gapBegin = i;
        }
      } else if (gapBegin !== null) {
        var gapLength = i - gapBegin;
        var beforeGap = processStops[gapBegin - 1];
        var gapValue = (stop_2 - beforeGap) / (gapLength + 1);
        for (var g = 1; g <= gapLength; g++) {
          processStops[gapBegin + g - 1] = gapValue * g;
        }
        gapBegin = null;
      }
    }
    return stops.map(function(_a, i2) {
      var color2 = _a.color;
      return { color: color2, stop: Math.max(Math.min(1, processStops[i2] / lineLength), 0) };
    });
  };
  var getAngleFromCorner = function(corner, width, height) {
    var centerX = width / 2;
    var centerY = height / 2;
    var x = getAbsoluteValue(corner[0], width) - centerX;
    var y = centerY - getAbsoluteValue(corner[1], height);
    return (Math.atan2(y, x) + Math.PI * 2) % (Math.PI * 2);
  };
  var calculateGradientDirection = function(angle2, width, height) {
    var radian = typeof angle2 === "number" ? angle2 : getAngleFromCorner(angle2, width, height);
    var lineLength = Math.abs(width * Math.sin(radian)) + Math.abs(height * Math.cos(radian));
    var halfWidth = width / 2;
    var halfHeight = height / 2;
    var halfLineLength = lineLength / 2;
    var yDiff = Math.sin(radian - Math.PI / 2) * halfLineLength;
    var xDiff = Math.cos(radian - Math.PI / 2) * halfLineLength;
    return [lineLength, halfWidth - xDiff, halfWidth + xDiff, halfHeight - yDiff, halfHeight + yDiff];
  };
  var distance = function(a2, b) {
    return Math.sqrt(a2 * a2 + b * b);
  };
  var findCorner = function(width, height, x, y, closest) {
    var corners = [
      [0, 0],
      [0, height],
      [width, 0],
      [width, height]
    ];
    return corners.reduce(function(stat, corner) {
      var cx = corner[0], cy = corner[1];
      var d = distance(x - cx, y - cy);
      if (closest ? d < stat.optimumDistance : d > stat.optimumDistance) {
        return {
          optimumCorner: corner,
          optimumDistance: d
        };
      }
      return stat;
    }, {
      optimumDistance: closest ? Infinity : -Infinity,
      optimumCorner: null
    }).optimumCorner;
  };
  var calculateRadius = function(gradient, x, y, width, height) {
    var rx = 0;
    var ry = 0;
    switch (gradient.size) {
      case 0:
        if (gradient.shape === 0) {
          rx = ry = Math.min(Math.abs(x), Math.abs(x - width), Math.abs(y), Math.abs(y - height));
        } else if (gradient.shape === 1) {
          rx = Math.min(Math.abs(x), Math.abs(x - width));
          ry = Math.min(Math.abs(y), Math.abs(y - height));
        }
        break;
      case 2:
        if (gradient.shape === 0) {
          rx = ry = Math.min(distance(x, y), distance(x, y - height), distance(x - width, y), distance(x - width, y - height));
        } else if (gradient.shape === 1) {
          var c = Math.min(Math.abs(y), Math.abs(y - height)) / Math.min(Math.abs(x), Math.abs(x - width));
          var _a = findCorner(width, height, x, y, true), cx = _a[0], cy = _a[1];
          rx = distance(cx - x, (cy - y) / c);
          ry = c * rx;
        }
        break;
      case 1:
        if (gradient.shape === 0) {
          rx = ry = Math.max(Math.abs(x), Math.abs(x - width), Math.abs(y), Math.abs(y - height));
        } else if (gradient.shape === 1) {
          rx = Math.max(Math.abs(x), Math.abs(x - width));
          ry = Math.max(Math.abs(y), Math.abs(y - height));
        }
        break;
      case 3:
        if (gradient.shape === 0) {
          rx = ry = Math.max(distance(x, y), distance(x, y - height), distance(x - width, y), distance(x - width, y - height));
        } else if (gradient.shape === 1) {
          var c = Math.max(Math.abs(y), Math.abs(y - height)) / Math.max(Math.abs(x), Math.abs(x - width));
          var _b = findCorner(width, height, x, y, false), cx = _b[0], cy = _b[1];
          rx = distance(cx - x, (cy - y) / c);
          ry = c * rx;
        }
        break;
    }
    if (Array.isArray(gradient.size)) {
      rx = getAbsoluteValue(gradient.size[0], width);
      ry = gradient.size.length === 2 ? getAbsoluteValue(gradient.size[1], height) : rx;
    }
    return [rx, ry];
  };
  var linearGradient = function(context, tokens) {
    var angle$1 = deg(180);
    var stops = [];
    parseFunctionArgs(tokens).forEach(function(arg, i) {
      if (i === 0) {
        var firstToken = arg[0];
        if (firstToken.type === 20 && firstToken.value === "to") {
          angle$1 = parseNamedSide(arg);
          return;
        } else if (isAngle(firstToken)) {
          angle$1 = angle.parse(context, firstToken);
          return;
        }
      }
      var colorStop = parseColorStop(context, arg);
      stops.push(colorStop);
    });
    return {
      angle: angle$1,
      stops,
      type: 1
      /* LINEAR_GRADIENT */
    };
  };
  var prefixLinearGradient = function(context, tokens) {
    var angle$1 = deg(180);
    var stops = [];
    parseFunctionArgs(tokens).forEach(function(arg, i) {
      if (i === 0) {
        var firstToken = arg[0];
        if (firstToken.type === 20 && ["top", "left", "right", "bottom"].indexOf(firstToken.value) !== -1) {
          angle$1 = parseNamedSide(arg);
          return;
        } else if (isAngle(firstToken)) {
          angle$1 = (angle.parse(context, firstToken) + deg(270)) % deg(360);
          return;
        }
      }
      var colorStop = parseColorStop(context, arg);
      stops.push(colorStop);
    });
    return {
      angle: angle$1,
      stops,
      type: 1
      /* LINEAR_GRADIENT */
    };
  };
  var webkitGradient = function(context, tokens) {
    var angle2 = deg(180);
    var stops = [];
    var type = 1;
    var shape = 0;
    var size = 3;
    var position2 = [];
    parseFunctionArgs(tokens).forEach(function(arg, i) {
      var firstToken = arg[0];
      if (i === 0) {
        if (isIdentToken(firstToken) && firstToken.value === "linear") {
          type = 1;
          return;
        } else if (isIdentToken(firstToken) && firstToken.value === "radial") {
          type = 2;
          return;
        }
      }
      if (firstToken.type === 18) {
        if (firstToken.name === "from") {
          var color2 = color$1.parse(context, firstToken.values[0]);
          stops.push({ stop: ZERO_LENGTH, color: color2 });
        } else if (firstToken.name === "to") {
          var color2 = color$1.parse(context, firstToken.values[0]);
          stops.push({ stop: HUNDRED_PERCENT, color: color2 });
        } else if (firstToken.name === "color-stop") {
          var values = firstToken.values.filter(nonFunctionArgSeparator);
          if (values.length === 2) {
            var color2 = color$1.parse(context, values[1]);
            var stop_1 = values[0];
            if (isNumberToken(stop_1)) {
              stops.push({
                stop: { type: 16, number: stop_1.number * 100, flags: stop_1.flags },
                color: color2
              });
            }
          }
        }
      }
    });
    return type === 1 ? {
      angle: (angle2 + deg(180)) % deg(360),
      stops,
      type
    } : { size, shape, stops, position: position2, type };
  };
  var CLOSEST_SIDE = "closest-side";
  var FARTHEST_SIDE = "farthest-side";
  var CLOSEST_CORNER = "closest-corner";
  var FARTHEST_CORNER = "farthest-corner";
  var CIRCLE = "circle";
  var ELLIPSE = "ellipse";
  var COVER = "cover";
  var CONTAIN = "contain";
  var radialGradient = function(context, tokens) {
    var shape = 0;
    var size = 3;
    var stops = [];
    var position2 = [];
    parseFunctionArgs(tokens).forEach(function(arg, i) {
      var isColorStop = true;
      if (i === 0) {
        var isAtPosition_1 = false;
        isColorStop = arg.reduce(function(acc, token) {
          if (isAtPosition_1) {
            if (isIdentToken(token)) {
              switch (token.value) {
                case "center":
                  position2.push(FIFTY_PERCENT);
                  return acc;
                case "top":
                case "left":
                  position2.push(ZERO_LENGTH);
                  return acc;
                case "right":
                case "bottom":
                  position2.push(HUNDRED_PERCENT);
                  return acc;
              }
            } else if (isLengthPercentage(token) || isLength(token)) {
              position2.push(token);
            }
          } else if (isIdentToken(token)) {
            switch (token.value) {
              case CIRCLE:
                shape = 0;
                return false;
              case ELLIPSE:
                shape = 1;
                return false;
              case "at":
                isAtPosition_1 = true;
                return false;
              case CLOSEST_SIDE:
                size = 0;
                return false;
              case COVER:
              case FARTHEST_SIDE:
                size = 1;
                return false;
              case CONTAIN:
              case CLOSEST_CORNER:
                size = 2;
                return false;
              case FARTHEST_CORNER:
                size = 3;
                return false;
            }
          } else if (isLength(token) || isLengthPercentage(token)) {
            if (!Array.isArray(size)) {
              size = [];
            }
            size.push(token);
            return false;
          }
          return acc;
        }, isColorStop);
      }
      if (isColorStop) {
        var colorStop = parseColorStop(context, arg);
        stops.push(colorStop);
      }
    });
    return {
      size,
      shape,
      stops,
      position: position2,
      type: 2
      /* RADIAL_GRADIENT */
    };
  };
  var prefixRadialGradient = function(context, tokens) {
    var shape = 0;
    var size = 3;
    var stops = [];
    var position2 = [];
    parseFunctionArgs(tokens).forEach(function(arg, i) {
      var isColorStop = true;
      if (i === 0) {
        isColorStop = arg.reduce(function(acc, token) {
          if (isIdentToken(token)) {
            switch (token.value) {
              case "center":
                position2.push(FIFTY_PERCENT);
                return false;
              case "top":
              case "left":
                position2.push(ZERO_LENGTH);
                return false;
              case "right":
              case "bottom":
                position2.push(HUNDRED_PERCENT);
                return false;
            }
          } else if (isLengthPercentage(token) || isLength(token)) {
            position2.push(token);
            return false;
          }
          return acc;
        }, isColorStop);
      } else if (i === 1) {
        isColorStop = arg.reduce(function(acc, token) {
          if (isIdentToken(token)) {
            switch (token.value) {
              case CIRCLE:
                shape = 0;
                return false;
              case ELLIPSE:
                shape = 1;
                return false;
              case CONTAIN:
              case CLOSEST_SIDE:
                size = 0;
                return false;
              case FARTHEST_SIDE:
                size = 1;
                return false;
              case CLOSEST_CORNER:
                size = 2;
                return false;
              case COVER:
              case FARTHEST_CORNER:
                size = 3;
                return false;
            }
          } else if (isLength(token) || isLengthPercentage(token)) {
            if (!Array.isArray(size)) {
              size = [];
            }
            size.push(token);
            return false;
          }
          return acc;
        }, isColorStop);
      }
      if (isColorStop) {
        var colorStop = parseColorStop(context, arg);
        stops.push(colorStop);
      }
    });
    return {
      size,
      shape,
      stops,
      position: position2,
      type: 2
      /* RADIAL_GRADIENT */
    };
  };
  var isLinearGradient = function(background) {
    return background.type === 1;
  };
  var isRadialGradient = function(background) {
    return background.type === 2;
  };
  var image = {
    name: "image",
    parse: function(context, value) {
      if (value.type === 22) {
        var image_1 = {
          url: value.value,
          type: 0
          /* URL */
        };
        context.cache.addImage(value.value);
        return image_1;
      }
      if (value.type === 18) {
        var imageFunction = SUPPORTED_IMAGE_FUNCTIONS[value.name];
        if (typeof imageFunction === "undefined") {
          throw new Error('Attempting to parse an unsupported image function "' + value.name + '"');
        }
        return imageFunction(context, value.values);
      }
      throw new Error("Unsupported image type " + value.type);
    }
  };
  function isSupportedImage(value) {
    return !(value.type === 20 && value.value === "none") && (value.type !== 18 || !!SUPPORTED_IMAGE_FUNCTIONS[value.name]);
  }
  var SUPPORTED_IMAGE_FUNCTIONS = {
    "linear-gradient": linearGradient,
    "-moz-linear-gradient": prefixLinearGradient,
    "-ms-linear-gradient": prefixLinearGradient,
    "-o-linear-gradient": prefixLinearGradient,
    "-webkit-linear-gradient": prefixLinearGradient,
    "radial-gradient": radialGradient,
    "-moz-radial-gradient": prefixRadialGradient,
    "-ms-radial-gradient": prefixRadialGradient,
    "-o-radial-gradient": prefixRadialGradient,
    "-webkit-radial-gradient": prefixRadialGradient,
    "-webkit-gradient": webkitGradient
  };
  var backgroundImage = {
    name: "background-image",
    initialValue: "none",
    type: 1,
    prefix: false,
    parse: function(context, tokens) {
      if (tokens.length === 0) {
        return [];
      }
      var first = tokens[0];
      if (first.type === 20 && first.value === "none") {
        return [];
      }
      return tokens.filter(function(value) {
        return nonFunctionArgSeparator(value) && isSupportedImage(value);
      }).map(function(value) {
        return image.parse(context, value);
      });
    }
  };
  var backgroundOrigin = {
    name: "background-origin",
    initialValue: "border-box",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      return tokens.map(function(token) {
        if (isIdentToken(token)) {
          switch (token.value) {
            case "padding-box":
              return 1;
            case "content-box":
              return 2;
          }
        }
        return 0;
      });
    }
  };
  var backgroundPosition = {
    name: "background-position",
    initialValue: "0% 0%",
    type: 1,
    prefix: false,
    parse: function(_context, tokens) {
      return parseFunctionArgs(tokens).map(function(values) {
        return values.filter(isLengthPercentage);
      }).map(parseLengthPercentageTuple);
    }
  };
  var backgroundRepeat = {
    name: "background-repeat",
    initialValue: "repeat",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      return parseFunctionArgs(tokens).map(function(values) {
        return values.filter(isIdentToken).map(function(token) {
          return token.value;
        }).join(" ");
      }).map(parseBackgroundRepeat);
    }
  };
  var parseBackgroundRepeat = function(value) {
    switch (value) {
      case "no-repeat":
        return 1;
      case "repeat-x":
      case "repeat no-repeat":
        return 2;
      case "repeat-y":
      case "no-repeat repeat":
        return 3;
      case "repeat":
      default:
        return 0;
    }
  };
  var BACKGROUND_SIZE;
  (function(BACKGROUND_SIZE2) {
    BACKGROUND_SIZE2["AUTO"] = "auto";
    BACKGROUND_SIZE2["CONTAIN"] = "contain";
    BACKGROUND_SIZE2["COVER"] = "cover";
  })(BACKGROUND_SIZE || (BACKGROUND_SIZE = {}));
  var backgroundSize = {
    name: "background-size",
    initialValue: "0",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      return parseFunctionArgs(tokens).map(function(values) {
        return values.filter(isBackgroundSizeInfoToken);
      });
    }
  };
  var isBackgroundSizeInfoToken = function(value) {
    return isIdentToken(value) || isLengthPercentage(value);
  };
  var borderColorForSide = function(side) {
    return {
      name: "border-" + side + "-color",
      initialValue: "transparent",
      prefix: false,
      type: 3,
      format: "color"
    };
  };
  var borderTopColor = borderColorForSide("top");
  var borderRightColor = borderColorForSide("right");
  var borderBottomColor = borderColorForSide("bottom");
  var borderLeftColor = borderColorForSide("left");
  var borderRadiusForSide = function(side) {
    return {
      name: "border-radius-" + side,
      initialValue: "0 0",
      prefix: false,
      type: 1,
      parse: function(_context, tokens) {
        return parseLengthPercentageTuple(tokens.filter(isLengthPercentage));
      }
    };
  };
  var borderTopLeftRadius = borderRadiusForSide("top-left");
  var borderTopRightRadius = borderRadiusForSide("top-right");
  var borderBottomRightRadius = borderRadiusForSide("bottom-right");
  var borderBottomLeftRadius = borderRadiusForSide("bottom-left");
  var borderStyleForSide = function(side) {
    return {
      name: "border-" + side + "-style",
      initialValue: "solid",
      prefix: false,
      type: 2,
      parse: function(_context, style) {
        switch (style) {
          case "none":
            return 0;
          case "dashed":
            return 2;
          case "dotted":
            return 3;
          case "double":
            return 4;
        }
        return 1;
      }
    };
  };
  var borderTopStyle = borderStyleForSide("top");
  var borderRightStyle = borderStyleForSide("right");
  var borderBottomStyle = borderStyleForSide("bottom");
  var borderLeftStyle = borderStyleForSide("left");
  var borderWidthForSide = function(side) {
    return {
      name: "border-" + side + "-width",
      initialValue: "0",
      type: 0,
      prefix: false,
      parse: function(_context, token) {
        if (isDimensionToken(token)) {
          return token.number;
        }
        return 0;
      }
    };
  };
  var borderTopWidth = borderWidthForSide("top");
  var borderRightWidth = borderWidthForSide("right");
  var borderBottomWidth = borderWidthForSide("bottom");
  var borderLeftWidth = borderWidthForSide("left");
  var color = {
    name: "color",
    initialValue: "transparent",
    prefix: false,
    type: 3,
    format: "color"
  };
  var direction = {
    name: "direction",
    initialValue: "ltr",
    prefix: false,
    type: 2,
    parse: function(_context, direction2) {
      switch (direction2) {
        case "rtl":
          return 1;
        case "ltr":
        default:
          return 0;
      }
    }
  };
  var display = {
    name: "display",
    initialValue: "inline-block",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      return tokens.filter(isIdentToken).reduce(
        function(bit, token) {
          return bit | parseDisplayValue(token.value);
        },
        0
        /* NONE */
      );
    }
  };
  var parseDisplayValue = function(display2) {
    switch (display2) {
      case "block":
      case "-webkit-box":
        return 2;
      case "inline":
        return 4;
      case "run-in":
        return 8;
      case "flow":
        return 16;
      case "flow-root":
        return 32;
      case "table":
        return 64;
      case "flex":
      case "-webkit-flex":
        return 128;
      case "grid":
      case "-ms-grid":
        return 256;
      case "ruby":
        return 512;
      case "subgrid":
        return 1024;
      case "list-item":
        return 2048;
      case "table-row-group":
        return 4096;
      case "table-header-group":
        return 8192;
      case "table-footer-group":
        return 16384;
      case "table-row":
        return 32768;
      case "table-cell":
        return 65536;
      case "table-column-group":
        return 131072;
      case "table-column":
        return 262144;
      case "table-caption":
        return 524288;
      case "ruby-base":
        return 1048576;
      case "ruby-text":
        return 2097152;
      case "ruby-base-container":
        return 4194304;
      case "ruby-text-container":
        return 8388608;
      case "contents":
        return 16777216;
      case "inline-block":
        return 33554432;
      case "inline-list-item":
        return 67108864;
      case "inline-table":
        return 134217728;
      case "inline-flex":
        return 268435456;
      case "inline-grid":
        return 536870912;
    }
    return 0;
  };
  var float = {
    name: "float",
    initialValue: "none",
    prefix: false,
    type: 2,
    parse: function(_context, float2) {
      switch (float2) {
        case "left":
          return 1;
        case "right":
          return 2;
        case "inline-start":
          return 3;
        case "inline-end":
          return 4;
      }
      return 0;
    }
  };
  var letterSpacing = {
    name: "letter-spacing",
    initialValue: "0",
    prefix: false,
    type: 0,
    parse: function(_context, token) {
      if (token.type === 20 && token.value === "normal") {
        return 0;
      }
      if (token.type === 17) {
        return token.number;
      }
      if (token.type === 15) {
        return token.number;
      }
      return 0;
    }
  };
  var LINE_BREAK;
  (function(LINE_BREAK2) {
    LINE_BREAK2["NORMAL"] = "normal";
    LINE_BREAK2["STRICT"] = "strict";
  })(LINE_BREAK || (LINE_BREAK = {}));
  var lineBreak = {
    name: "line-break",
    initialValue: "normal",
    prefix: false,
    type: 2,
    parse: function(_context, lineBreak2) {
      switch (lineBreak2) {
        case "strict":
          return LINE_BREAK.STRICT;
        case "normal":
        default:
          return LINE_BREAK.NORMAL;
      }
    }
  };
  var lineHeight = {
    name: "line-height",
    initialValue: "normal",
    prefix: false,
    type: 4
    /* TOKEN_VALUE */
  };
  var computeLineHeight = function(token, fontSize2) {
    if (isIdentToken(token) && token.value === "normal") {
      return 1.2 * fontSize2;
    } else if (token.type === 17) {
      return fontSize2 * token.number;
    } else if (isLengthPercentage(token)) {
      return getAbsoluteValue(token, fontSize2);
    }
    return fontSize2;
  };
  var listStyleImage = {
    name: "list-style-image",
    initialValue: "none",
    type: 0,
    prefix: false,
    parse: function(context, token) {
      if (token.type === 20 && token.value === "none") {
        return null;
      }
      return image.parse(context, token);
    }
  };
  var listStylePosition = {
    name: "list-style-position",
    initialValue: "outside",
    prefix: false,
    type: 2,
    parse: function(_context, position2) {
      switch (position2) {
        case "inside":
          return 0;
        case "outside":
        default:
          return 1;
      }
    }
  };
  var listStyleType = {
    name: "list-style-type",
    initialValue: "none",
    prefix: false,
    type: 2,
    parse: function(_context, type) {
      switch (type) {
        case "disc":
          return 0;
        case "circle":
          return 1;
        case "square":
          return 2;
        case "decimal":
          return 3;
        case "cjk-decimal":
          return 4;
        case "decimal-leading-zero":
          return 5;
        case "lower-roman":
          return 6;
        case "upper-roman":
          return 7;
        case "lower-greek":
          return 8;
        case "lower-alpha":
          return 9;
        case "upper-alpha":
          return 10;
        case "arabic-indic":
          return 11;
        case "armenian":
          return 12;
        case "bengali":
          return 13;
        case "cambodian":
          return 14;
        case "cjk-earthly-branch":
          return 15;
        case "cjk-heavenly-stem":
          return 16;
        case "cjk-ideographic":
          return 17;
        case "devanagari":
          return 18;
        case "ethiopic-numeric":
          return 19;
        case "georgian":
          return 20;
        case "gujarati":
          return 21;
        case "gurmukhi":
          return 22;
        case "hebrew":
          return 22;
        case "hiragana":
          return 23;
        case "hiragana-iroha":
          return 24;
        case "japanese-formal":
          return 25;
        case "japanese-informal":
          return 26;
        case "kannada":
          return 27;
        case "katakana":
          return 28;
        case "katakana-iroha":
          return 29;
        case "khmer":
          return 30;
        case "korean-hangul-formal":
          return 31;
        case "korean-hanja-formal":
          return 32;
        case "korean-hanja-informal":
          return 33;
        case "lao":
          return 34;
        case "lower-armenian":
          return 35;
        case "malayalam":
          return 36;
        case "mongolian":
          return 37;
        case "myanmar":
          return 38;
        case "oriya":
          return 39;
        case "persian":
          return 40;
        case "simp-chinese-formal":
          return 41;
        case "simp-chinese-informal":
          return 42;
        case "tamil":
          return 43;
        case "telugu":
          return 44;
        case "thai":
          return 45;
        case "tibetan":
          return 46;
        case "trad-chinese-formal":
          return 47;
        case "trad-chinese-informal":
          return 48;
        case "upper-armenian":
          return 49;
        case "disclosure-open":
          return 50;
        case "disclosure-closed":
          return 51;
        case "none":
        default:
          return -1;
      }
    }
  };
  var marginForSide = function(side) {
    return {
      name: "margin-" + side,
      initialValue: "0",
      prefix: false,
      type: 4
      /* TOKEN_VALUE */
    };
  };
  var marginTop = marginForSide("top");
  var marginRight = marginForSide("right");
  var marginBottom = marginForSide("bottom");
  var marginLeft = marginForSide("left");
  var overflow = {
    name: "overflow",
    initialValue: "visible",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      return tokens.filter(isIdentToken).map(function(overflow2) {
        switch (overflow2.value) {
          case "hidden":
            return 1;
          case "scroll":
            return 2;
          case "clip":
            return 3;
          case "auto":
            return 4;
          case "visible":
          default:
            return 0;
        }
      });
    }
  };
  var overflowWrap = {
    name: "overflow-wrap",
    initialValue: "normal",
    prefix: false,
    type: 2,
    parse: function(_context, overflow2) {
      switch (overflow2) {
        case "break-word":
          return "break-word";
        case "normal":
        default:
          return "normal";
      }
    }
  };
  var paddingForSide = function(side) {
    return {
      name: "padding-" + side,
      initialValue: "0",
      prefix: false,
      type: 3,
      format: "length-percentage"
    };
  };
  var paddingTop = paddingForSide("top");
  var paddingRight = paddingForSide("right");
  var paddingBottom = paddingForSide("bottom");
  var paddingLeft = paddingForSide("left");
  var textAlign = {
    name: "text-align",
    initialValue: "left",
    prefix: false,
    type: 2,
    parse: function(_context, textAlign2) {
      switch (textAlign2) {
        case "right":
          return 2;
        case "center":
        case "justify":
          return 1;
        case "left":
        default:
          return 0;
      }
    }
  };
  var position = {
    name: "position",
    initialValue: "static",
    prefix: false,
    type: 2,
    parse: function(_context, position2) {
      switch (position2) {
        case "relative":
          return 1;
        case "absolute":
          return 2;
        case "fixed":
          return 3;
        case "sticky":
          return 4;
      }
      return 0;
    }
  };
  var textShadow = {
    name: "text-shadow",
    initialValue: "none",
    type: 1,
    prefix: false,
    parse: function(context, tokens) {
      if (tokens.length === 1 && isIdentWithValue(tokens[0], "none")) {
        return [];
      }
      return parseFunctionArgs(tokens).map(function(values) {
        var shadow = {
          color: COLORS.TRANSPARENT,
          offsetX: ZERO_LENGTH,
          offsetY: ZERO_LENGTH,
          blur: ZERO_LENGTH
        };
        var c = 0;
        for (var i = 0; i < values.length; i++) {
          var token = values[i];
          if (isLength(token)) {
            if (c === 0) {
              shadow.offsetX = token;
            } else if (c === 1) {
              shadow.offsetY = token;
            } else {
              shadow.blur = token;
            }
            c++;
          } else {
            shadow.color = color$1.parse(context, token);
          }
        }
        return shadow;
      });
    }
  };
  var textTransform = {
    name: "text-transform",
    initialValue: "none",
    prefix: false,
    type: 2,
    parse: function(_context, textTransform2) {
      switch (textTransform2) {
        case "uppercase":
          return 2;
        case "lowercase":
          return 1;
        case "capitalize":
          return 3;
      }
      return 0;
    }
  };
  var transform$1 = {
    name: "transform",
    initialValue: "none",
    prefix: true,
    type: 0,
    parse: function(_context, token) {
      if (token.type === 20 && token.value === "none") {
        return null;
      }
      if (token.type === 18) {
        var transformFunction = SUPPORTED_TRANSFORM_FUNCTIONS[token.name];
        if (typeof transformFunction === "undefined") {
          throw new Error('Attempting to parse an unsupported transform function "' + token.name + '"');
        }
        return transformFunction(token.values);
      }
      return null;
    }
  };
  var matrix = function(args) {
    var values = args.filter(function(arg) {
      return arg.type === 17;
    }).map(function(arg) {
      return arg.number;
    });
    return values.length === 6 ? values : null;
  };
  var matrix3d = function(args) {
    var values = args.filter(function(arg) {
      return arg.type === 17;
    }).map(function(arg) {
      return arg.number;
    });
    var a1 = values[0], b1 = values[1];
    values[2];
    values[3];
    var a2 = values[4], b2 = values[5];
    values[6];
    values[7];
    values[8];
    values[9];
    values[10];
    values[11];
    var a4 = values[12], b4 = values[13];
    values[14];
    values[15];
    return values.length === 16 ? [a1, b1, a2, b2, a4, b4] : null;
  };
  var SUPPORTED_TRANSFORM_FUNCTIONS = {
    matrix,
    matrix3d
  };
  var DEFAULT_VALUE = {
    type: 16,
    number: 50,
    flags: FLAG_INTEGER
  };
  var DEFAULT = [DEFAULT_VALUE, DEFAULT_VALUE];
  var transformOrigin = {
    name: "transform-origin",
    initialValue: "50% 50%",
    prefix: true,
    type: 1,
    parse: function(_context, tokens) {
      var origins = tokens.filter(isLengthPercentage);
      if (origins.length !== 2) {
        return DEFAULT;
      }
      return [origins[0], origins[1]];
    }
  };
  var visibility = {
    name: "visible",
    initialValue: "none",
    prefix: false,
    type: 2,
    parse: function(_context, visibility2) {
      switch (visibility2) {
        case "hidden":
          return 1;
        case "collapse":
          return 2;
        case "visible":
        default:
          return 0;
      }
    }
  };
  var WORD_BREAK;
  (function(WORD_BREAK2) {
    WORD_BREAK2["NORMAL"] = "normal";
    WORD_BREAK2["BREAK_ALL"] = "break-all";
    WORD_BREAK2["KEEP_ALL"] = "keep-all";
  })(WORD_BREAK || (WORD_BREAK = {}));
  var wordBreak = {
    name: "word-break",
    initialValue: "normal",
    prefix: false,
    type: 2,
    parse: function(_context, wordBreak2) {
      switch (wordBreak2) {
        case "break-all":
          return WORD_BREAK.BREAK_ALL;
        case "keep-all":
          return WORD_BREAK.KEEP_ALL;
        case "normal":
        default:
          return WORD_BREAK.NORMAL;
      }
    }
  };
  var zIndex = {
    name: "z-index",
    initialValue: "auto",
    prefix: false,
    type: 0,
    parse: function(_context, token) {
      if (token.type === 20) {
        return { auto: true, order: 0 };
      }
      if (isNumberToken(token)) {
        return { auto: false, order: token.number };
      }
      throw new Error("Invalid z-index number parsed");
    }
  };
  var time = {
    name: "time",
    parse: function(_context, value) {
      if (value.type === 15) {
        switch (value.unit.toLowerCase()) {
          case "s":
            return 1e3 * value.number;
          case "ms":
            return value.number;
        }
      }
      throw new Error("Unsupported time type");
    }
  };
  var opacity = {
    name: "opacity",
    initialValue: "1",
    type: 0,
    prefix: false,
    parse: function(_context, token) {
      if (isNumberToken(token)) {
        return token.number;
      }
      return 1;
    }
  };
  var textDecorationColor = {
    name: "text-decoration-color",
    initialValue: "transparent",
    prefix: false,
    type: 3,
    format: "color"
  };
  var textDecorationLine = {
    name: "text-decoration-line",
    initialValue: "none",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      return tokens.filter(isIdentToken).map(function(token) {
        switch (token.value) {
          case "underline":
            return 1;
          case "overline":
            return 2;
          case "line-through":
            return 3;
          case "none":
            return 4;
        }
        return 0;
      }).filter(function(line) {
        return line !== 0;
      });
    }
  };
  var fontFamily = {
    name: "font-family",
    initialValue: "",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      var accumulator = [];
      var results = [];
      tokens.forEach(function(token) {
        switch (token.type) {
          case 20:
          case 0:
            accumulator.push(token.value);
            break;
          case 17:
            accumulator.push(token.number.toString());
            break;
          case 4:
            results.push(accumulator.join(" "));
            accumulator.length = 0;
            break;
        }
      });
      if (accumulator.length) {
        results.push(accumulator.join(" "));
      }
      return results.map(function(result) {
        return result.indexOf(" ") === -1 ? result : "'" + result + "'";
      });
    }
  };
  var fontSize = {
    name: "font-size",
    initialValue: "0",
    prefix: false,
    type: 3,
    format: "length"
  };
  var fontWeight = {
    name: "font-weight",
    initialValue: "normal",
    type: 0,
    prefix: false,
    parse: function(_context, token) {
      if (isNumberToken(token)) {
        return token.number;
      }
      if (isIdentToken(token)) {
        switch (token.value) {
          case "bold":
            return 700;
          case "normal":
          default:
            return 400;
        }
      }
      return 400;
    }
  };
  var fontVariant = {
    name: "font-variant",
    initialValue: "none",
    type: 1,
    prefix: false,
    parse: function(_context, tokens) {
      return tokens.filter(isIdentToken).map(function(token) {
        return token.value;
      });
    }
  };
  var fontStyle = {
    name: "font-style",
    initialValue: "normal",
    prefix: false,
    type: 2,
    parse: function(_context, overflow2) {
      switch (overflow2) {
        case "oblique":
          return "oblique";
        case "italic":
          return "italic";
        case "normal":
        default:
          return "normal";
      }
    }
  };
  var contains = function(bit, value) {
    return (bit & value) !== 0;
  };
  var content = {
    name: "content",
    initialValue: "none",
    type: 1,
    prefix: false,
    parse: function(_context, tokens) {
      if (tokens.length === 0) {
        return [];
      }
      var first = tokens[0];
      if (first.type === 20 && first.value === "none") {
        return [];
      }
      return tokens;
    }
  };
  var counterIncrement = {
    name: "counter-increment",
    initialValue: "none",
    prefix: true,
    type: 1,
    parse: function(_context, tokens) {
      if (tokens.length === 0) {
        return null;
      }
      var first = tokens[0];
      if (first.type === 20 && first.value === "none") {
        return null;
      }
      var increments = [];
      var filtered = tokens.filter(nonWhiteSpace);
      for (var i = 0; i < filtered.length; i++) {
        var counter = filtered[i];
        var next = filtered[i + 1];
        if (counter.type === 20) {
          var increment = next && isNumberToken(next) ? next.number : 1;
          increments.push({ counter: counter.value, increment });
        }
      }
      return increments;
    }
  };
  var counterReset = {
    name: "counter-reset",
    initialValue: "none",
    prefix: true,
    type: 1,
    parse: function(_context, tokens) {
      if (tokens.length === 0) {
        return [];
      }
      var resets = [];
      var filtered = tokens.filter(nonWhiteSpace);
      for (var i = 0; i < filtered.length; i++) {
        var counter = filtered[i];
        var next = filtered[i + 1];
        if (isIdentToken(counter) && counter.value !== "none") {
          var reset = next && isNumberToken(next) ? next.number : 0;
          resets.push({ counter: counter.value, reset });
        }
      }
      return resets;
    }
  };
  var duration = {
    name: "duration",
    initialValue: "0s",
    prefix: false,
    type: 1,
    parse: function(context, tokens) {
      return tokens.filter(isDimensionToken).map(function(token) {
        return time.parse(context, token);
      });
    }
  };
  var quotes = {
    name: "quotes",
    initialValue: "none",
    prefix: true,
    type: 1,
    parse: function(_context, tokens) {
      if (tokens.length === 0) {
        return null;
      }
      var first = tokens[0];
      if (first.type === 20 && first.value === "none") {
        return null;
      }
      var quotes2 = [];
      var filtered = tokens.filter(isStringToken);
      if (filtered.length % 2 !== 0) {
        return null;
      }
      for (var i = 0; i < filtered.length; i += 2) {
        var open_1 = filtered[i].value;
        var close_1 = filtered[i + 1].value;
        quotes2.push({ open: open_1, close: close_1 });
      }
      return quotes2;
    }
  };
  var getQuote = function(quotes2, depth, open) {
    if (!quotes2) {
      return "";
    }
    var quote = quotes2[Math.min(depth, quotes2.length - 1)];
    if (!quote) {
      return "";
    }
    return open ? quote.open : quote.close;
  };
  var boxShadow = {
    name: "box-shadow",
    initialValue: "none",
    type: 1,
    prefix: false,
    parse: function(context, tokens) {
      if (tokens.length === 1 && isIdentWithValue(tokens[0], "none")) {
        return [];
      }
      return parseFunctionArgs(tokens).map(function(values) {
        var shadow = {
          color: 255,
          offsetX: ZERO_LENGTH,
          offsetY: ZERO_LENGTH,
          blur: ZERO_LENGTH,
          spread: ZERO_LENGTH,
          inset: false
        };
        var c = 0;
        for (var i = 0; i < values.length; i++) {
          var token = values[i];
          if (isIdentWithValue(token, "inset")) {
            shadow.inset = true;
          } else if (isLength(token)) {
            if (c === 0) {
              shadow.offsetX = token;
            } else if (c === 1) {
              shadow.offsetY = token;
            } else if (c === 2) {
              shadow.blur = token;
            } else {
              shadow.spread = token;
            }
            c++;
          } else {
            shadow.color = color$1.parse(context, token);
          }
        }
        return shadow;
      });
    }
  };
  var paintOrder = {
    name: "paint-order",
    initialValue: "normal",
    prefix: false,
    type: 1,
    parse: function(_context, tokens) {
      var DEFAULT_VALUE2 = [
        0,
        1,
        2
        /* MARKERS */
      ];
      var layers = [];
      tokens.filter(isIdentToken).forEach(function(token) {
        switch (token.value) {
          case "stroke":
            layers.push(
              1
              /* STROKE */
            );
            break;
          case "fill":
            layers.push(
              0
              /* FILL */
            );
            break;
          case "markers":
            layers.push(
              2
              /* MARKERS */
            );
            break;
        }
      });
      DEFAULT_VALUE2.forEach(function(value) {
        if (layers.indexOf(value) === -1) {
          layers.push(value);
        }
      });
      return layers;
    }
  };
  var webkitTextStrokeColor = {
    name: "-webkit-text-stroke-color",
    initialValue: "currentcolor",
    prefix: false,
    type: 3,
    format: "color"
  };
  var webkitTextStrokeWidth = {
    name: "-webkit-text-stroke-width",
    initialValue: "0",
    type: 0,
    prefix: false,
    parse: function(_context, token) {
      if (isDimensionToken(token)) {
        return token.number;
      }
      return 0;
    }
  };
  var CSSParsedDeclaration = (
    /** @class */
    (function() {
      function CSSParsedDeclaration2(context, declaration) {
        var _a, _b;
        this.animationDuration = parse(context, duration, declaration.animationDuration);
        this.backgroundClip = parse(context, backgroundClip, declaration.backgroundClip);
        this.backgroundColor = parse(context, backgroundColor, declaration.backgroundColor);
        this.backgroundImage = parse(context, backgroundImage, declaration.backgroundImage);
        this.backgroundOrigin = parse(context, backgroundOrigin, declaration.backgroundOrigin);
        this.backgroundPosition = parse(context, backgroundPosition, declaration.backgroundPosition);
        this.backgroundRepeat = parse(context, backgroundRepeat, declaration.backgroundRepeat);
        this.backgroundSize = parse(context, backgroundSize, declaration.backgroundSize);
        this.borderTopColor = parse(context, borderTopColor, declaration.borderTopColor);
        this.borderRightColor = parse(context, borderRightColor, declaration.borderRightColor);
        this.borderBottomColor = parse(context, borderBottomColor, declaration.borderBottomColor);
        this.borderLeftColor = parse(context, borderLeftColor, declaration.borderLeftColor);
        this.borderTopLeftRadius = parse(context, borderTopLeftRadius, declaration.borderTopLeftRadius);
        this.borderTopRightRadius = parse(context, borderTopRightRadius, declaration.borderTopRightRadius);
        this.borderBottomRightRadius = parse(context, borderBottomRightRadius, declaration.borderBottomRightRadius);
        this.borderBottomLeftRadius = parse(context, borderBottomLeftRadius, declaration.borderBottomLeftRadius);
        this.borderTopStyle = parse(context, borderTopStyle, declaration.borderTopStyle);
        this.borderRightStyle = parse(context, borderRightStyle, declaration.borderRightStyle);
        this.borderBottomStyle = parse(context, borderBottomStyle, declaration.borderBottomStyle);
        this.borderLeftStyle = parse(context, borderLeftStyle, declaration.borderLeftStyle);
        this.borderTopWidth = parse(context, borderTopWidth, declaration.borderTopWidth);
        this.borderRightWidth = parse(context, borderRightWidth, declaration.borderRightWidth);
        this.borderBottomWidth = parse(context, borderBottomWidth, declaration.borderBottomWidth);
        this.borderLeftWidth = parse(context, borderLeftWidth, declaration.borderLeftWidth);
        this.boxShadow = parse(context, boxShadow, declaration.boxShadow);
        this.color = parse(context, color, declaration.color);
        this.direction = parse(context, direction, declaration.direction);
        this.display = parse(context, display, declaration.display);
        this.float = parse(context, float, declaration.cssFloat);
        this.fontFamily = parse(context, fontFamily, declaration.fontFamily);
        this.fontSize = parse(context, fontSize, declaration.fontSize);
        this.fontStyle = parse(context, fontStyle, declaration.fontStyle);
        this.fontVariant = parse(context, fontVariant, declaration.fontVariant);
        this.fontWeight = parse(context, fontWeight, declaration.fontWeight);
        this.letterSpacing = parse(context, letterSpacing, declaration.letterSpacing);
        this.lineBreak = parse(context, lineBreak, declaration.lineBreak);
        this.lineHeight = parse(context, lineHeight, declaration.lineHeight);
        this.listStyleImage = parse(context, listStyleImage, declaration.listStyleImage);
        this.listStylePosition = parse(context, listStylePosition, declaration.listStylePosition);
        this.listStyleType = parse(context, listStyleType, declaration.listStyleType);
        this.marginTop = parse(context, marginTop, declaration.marginTop);
        this.marginRight = parse(context, marginRight, declaration.marginRight);
        this.marginBottom = parse(context, marginBottom, declaration.marginBottom);
        this.marginLeft = parse(context, marginLeft, declaration.marginLeft);
        this.opacity = parse(context, opacity, declaration.opacity);
        var overflowTuple = parse(context, overflow, declaration.overflow);
        this.overflowX = overflowTuple[0];
        this.overflowY = overflowTuple[overflowTuple.length > 1 ? 1 : 0];
        this.overflowWrap = parse(context, overflowWrap, declaration.overflowWrap);
        this.paddingTop = parse(context, paddingTop, declaration.paddingTop);
        this.paddingRight = parse(context, paddingRight, declaration.paddingRight);
        this.paddingBottom = parse(context, paddingBottom, declaration.paddingBottom);
        this.paddingLeft = parse(context, paddingLeft, declaration.paddingLeft);
        this.paintOrder = parse(context, paintOrder, declaration.paintOrder);
        this.position = parse(context, position, declaration.position);
        this.textAlign = parse(context, textAlign, declaration.textAlign);
        this.textDecorationColor = parse(context, textDecorationColor, (_a = declaration.textDecorationColor) !== null && _a !== void 0 ? _a : declaration.color);
        this.textDecorationLine = parse(context, textDecorationLine, (_b = declaration.textDecorationLine) !== null && _b !== void 0 ? _b : declaration.textDecoration);
        this.textShadow = parse(context, textShadow, declaration.textShadow);
        this.textTransform = parse(context, textTransform, declaration.textTransform);
        this.transform = parse(context, transform$1, declaration.transform);
        this.transformOrigin = parse(context, transformOrigin, declaration.transformOrigin);
        this.visibility = parse(context, visibility, declaration.visibility);
        this.webkitTextStrokeColor = parse(context, webkitTextStrokeColor, declaration.webkitTextStrokeColor);
        this.webkitTextStrokeWidth = parse(context, webkitTextStrokeWidth, declaration.webkitTextStrokeWidth);
        this.wordBreak = parse(context, wordBreak, declaration.wordBreak);
        this.zIndex = parse(context, zIndex, declaration.zIndex);
      }
      CSSParsedDeclaration2.prototype.isVisible = function() {
        return this.display > 0 && this.opacity > 0 && this.visibility === 0;
      };
      CSSParsedDeclaration2.prototype.isTransparent = function() {
        return isTransparent(this.backgroundColor);
      };
      CSSParsedDeclaration2.prototype.isTransformed = function() {
        return this.transform !== null;
      };
      CSSParsedDeclaration2.prototype.isPositioned = function() {
        return this.position !== 0;
      };
      CSSParsedDeclaration2.prototype.isPositionedWithZIndex = function() {
        return this.isPositioned() && !this.zIndex.auto;
      };
      CSSParsedDeclaration2.prototype.isFloating = function() {
        return this.float !== 0;
      };
      CSSParsedDeclaration2.prototype.isInlineLevel = function() {
        return contains(
          this.display,
          4
          /* INLINE */
        ) || contains(
          this.display,
          33554432
          /* INLINE_BLOCK */
        ) || contains(
          this.display,
          268435456
          /* INLINE_FLEX */
        ) || contains(
          this.display,
          536870912
          /* INLINE_GRID */
        ) || contains(
          this.display,
          67108864
          /* INLINE_LIST_ITEM */
        ) || contains(
          this.display,
          134217728
          /* INLINE_TABLE */
        );
      };
      return CSSParsedDeclaration2;
    })()
  );
  var CSSParsedPseudoDeclaration = (
    /** @class */
    /* @__PURE__ */ (function() {
      function CSSParsedPseudoDeclaration2(context, declaration) {
        this.content = parse(context, content, declaration.content);
        this.quotes = parse(context, quotes, declaration.quotes);
      }
      return CSSParsedPseudoDeclaration2;
    })()
  );
  var CSSParsedCounterDeclaration = (
    /** @class */
    /* @__PURE__ */ (function() {
      function CSSParsedCounterDeclaration2(context, declaration) {
        this.counterIncrement = parse(context, counterIncrement, declaration.counterIncrement);
        this.counterReset = parse(context, counterReset, declaration.counterReset);
      }
      return CSSParsedCounterDeclaration2;
    })()
  );
  var parse = function(context, descriptor, style) {
    var tokenizer = new Tokenizer();
    var value = style !== null && typeof style !== "undefined" ? style.toString() : descriptor.initialValue;
    tokenizer.write(value);
    var parser = new Parser(tokenizer.read());
    switch (descriptor.type) {
      case 2:
        var token = parser.parseComponentValue();
        return descriptor.parse(context, isIdentToken(token) ? token.value : descriptor.initialValue);
      case 0:
        return descriptor.parse(context, parser.parseComponentValue());
      case 1:
        return descriptor.parse(context, parser.parseComponentValues());
      case 4:
        return parser.parseComponentValue();
      case 3:
        switch (descriptor.format) {
          case "angle":
            return angle.parse(context, parser.parseComponentValue());
          case "color":
            return color$1.parse(context, parser.parseComponentValue());
          case "image":
            return image.parse(context, parser.parseComponentValue());
          case "length":
            var length_1 = parser.parseComponentValue();
            return isLength(length_1) ? length_1 : ZERO_LENGTH;
          case "length-percentage":
            var value_1 = parser.parseComponentValue();
            return isLengthPercentage(value_1) ? value_1 : ZERO_LENGTH;
          case "time":
            return time.parse(context, parser.parseComponentValue());
        }
        break;
    }
  };
  var elementDebuggerAttribute = "data-html2canvas-debug";
  var getElementDebugType = function(element) {
    var attribute = element.getAttribute(elementDebuggerAttribute);
    switch (attribute) {
      case "all":
        return 1;
      case "clone":
        return 2;
      case "parse":
        return 3;
      case "render":
        return 4;
      default:
        return 0;
    }
  };
  var isDebugging = function(element, type) {
    var elementType = getElementDebugType(element);
    return elementType === 1 || type === elementType;
  };
  var ElementContainer = (
    /** @class */
    /* @__PURE__ */ (function() {
      function ElementContainer2(context, element) {
        this.context = context;
        this.textNodes = [];
        this.elements = [];
        this.flags = 0;
        if (isDebugging(
          element,
          3
          /* PARSE */
        )) {
          debugger;
        }
        this.styles = new CSSParsedDeclaration(context, window.getComputedStyle(element, null));
        if (isHTMLElementNode(element)) {
          if (this.styles.animationDuration.some(function(duration2) {
            return duration2 > 0;
          })) {
            element.style.animationDuration = "0s";
          }
          if (this.styles.transform !== null) {
            element.style.transform = "none";
          }
        }
        this.bounds = parseBounds(this.context, element);
        if (isDebugging(
          element,
          4
          /* RENDER */
        )) {
          this.flags |= 16;
        }
      }
      return ElementContainer2;
    })()
  );
  var base64 = "AAAAAAAAAAAAEA4AGBkAAFAaAAACAAAAAAAIABAAGAAwADgACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAAQABIAEQATAAIABAACAAQAAgAEAAIABAAVABcAAgAEAAIABAACAAQAGAAaABwAHgAgACIAI4AlgAIABAAmwCjAKgAsAC2AL4AvQDFAMoA0gBPAVYBWgEIAAgACACMANoAYgFkAWwBdAF8AX0BhQGNAZUBlgGeAaMBlQGWAasBswF8AbsBwwF0AcsBYwHTAQgA2wG/AOMBdAF8AekB8QF0AfkB+wHiAHQBfAEIAAMC5gQIAAsCEgIIAAgAFgIeAggAIgIpAggAMQI5AkACygEIAAgASAJQAlgCYAIIAAgACAAKBQoFCgUTBRMFGQUrBSsFCAAIAAgACAAIAAgACAAIAAgACABdAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABoAmgCrwGvAQgAbgJ2AggAHgEIAAgACADnAXsCCAAIAAgAgwIIAAgACAAIAAgACACKAggAkQKZAggAPADJAAgAoQKkAqwCsgK6AsICCADJAggA0AIIAAgACAAIANYC3gIIAAgACAAIAAgACABAAOYCCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAkASoB+QIEAAgACAA8AEMCCABCBQgACABJBVAFCAAIAAgACAAIAAgACAAIAAgACABTBVoFCAAIAFoFCABfBWUFCAAIAAgACAAIAAgAbQUIAAgACAAIAAgACABzBXsFfQWFBYoFigWKBZEFigWKBYoFmAWfBaYFrgWxBbkFCAAIAAgACAAIAAgACAAIAAgACAAIAMEFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAMgFCADQBQgACAAIAAgACAAIAAgACAAIAAgACAAIAO4CCAAIAAgAiQAIAAgACABAAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAD0AggACAD8AggACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIANYFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAMDvwAIAAgAJAIIAAgACAAIAAgACAAIAAgACwMTAwgACAB9BOsEGwMjAwgAKwMyAwsFYgE3A/MEPwMIAEUDTQNRAwgAWQOsAGEDCAAIAAgACAAIAAgACABpAzQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFIQUoBSwFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABtAwgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABMAEwACAAIAAgACAAIABgACAAIAAgACAC/AAgACAAyAQgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACACAAIAAwAAgACAAIAAgACAAIAAgACAAIAAAARABIAAgACAAIABQASAAIAAgAIABwAEAAjgCIABsAqAC2AL0AigDQAtwC+IJIQqVAZUBWQqVAZUBlQGVAZUBlQGrC5UBlQGVAZUBlQGVAZUBlQGVAXsKlQGVAbAK6wsrDGUMpQzlDJUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAfAKAAuZA64AtwCJALoC6ADwAAgAuACgA/oEpgO6AqsD+AAIAAgAswMIAAgACAAIAIkAuwP5AfsBwwPLAwgACAAIAAgACADRA9kDCAAIAOED6QMIAAgACAAIAAgACADuA/YDCAAIAP4DyQAIAAgABgQIAAgAXQAOBAgACAAIAAgACAAIABMECAAIAAgACAAIAAgACAD8AAQBCAAIAAgAGgQiBCoECAExBAgAEAEIAAgACAAIAAgACAAIAAgACAAIAAgACAA4BAgACABABEYECAAIAAgATAQYAQgAVAQIAAgACAAIAAgACAAIAAgACAAIAFoECAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAOQEIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAB+BAcACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAEABhgSMBAgACAAIAAgAlAQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAwAEAAQABAADAAMAAwADAAQABAAEAAQABAAEAAQABHATAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAdQMIAAgACAAIAAgACAAIAMkACAAIAAgAfQMIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACACFA4kDCAAIAAgACAAIAOcBCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAIcDCAAIAAgACAAIAAgACAAIAAgACAAIAJEDCAAIAAgACADFAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABgBAgAZgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAbAQCBXIECAAIAHkECAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABAAJwEQACjBKoEsgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAC6BMIECAAIAAgACAAIAAgACABmBAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAxwQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAGYECAAIAAgAzgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAigWKBYoFigWKBYoFigWKBd0FXwUIAOIF6gXxBYoF3gT5BQAGCAaKBYoFigWKBYoFigWKBYoFigWKBYoFigXWBIoFigWKBYoFigWKBYoFigWKBYsFEAaKBYoFigWKBYoFigWKBRQGCACKBYoFigWKBQgACAAIANEECAAIABgGigUgBggAJgYIAC4GMwaKBYoF0wQ3Bj4GigWKBYoFigWKBYoFigWKBYoFigWKBYoFigUIAAgACAAIAAgACAAIAAgAigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWLBf///////wQABAAEAAQABAAEAAQABAAEAAQAAwAEAAQAAgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAQADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAUAAAAFAAUAAAAFAAUAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUAAQAAAAUABQAFAAUABQAFAAAAAAAFAAUAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAFAAUAAQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUABQAFAAAABwAHAAcAAAAHAAcABwAFAAEAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAcABwAFAAUAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAAAQABAAAAAAAAAAAAAAAFAAUABQAFAAAABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABwAHAAcAAAAHAAcAAAAAAAUABQAHAAUAAQAHAAEABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABwABAAUABQAFAAUAAAAAAAAAAAAAAAEAAQABAAEAAQABAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABQANAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEAAQABAAEAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAABQAHAAUABQAFAAAAAAAAAAcABQAFAAUABQAFAAQABAAEAAQABAAEAAQABAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUAAAAFAAUABQAFAAUAAAAFAAUABQAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAAAAAAAAAAAAUABQAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAUAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABwAHAAcABwAFAAcABwAAAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAUABwAHAAUABQAFAAUAAAAAAAcABwAAAAAABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAABQAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABwAHAAcABQAFAAAAAAAAAAAABQAFAAAAAAAFAAUABQAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAFAAUABQAFAAUAAAAFAAUABwAAAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAFAAUABwAFAAUABQAFAAAAAAAHAAcAAAAAAAcABwAFAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABwAAAAAAAAAHAAcABwAAAAcABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAABQAHAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAcABwAAAAUABQAFAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABQAHAAcABQAHAAcAAAAFAAcABwAAAAcABwAFAAUAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAFAAcABwAFAAUABQAAAAUAAAAHAAcABwAHAAcABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAHAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABwAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAUAAAAFAAAAAAAAAAAABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUABQAFAAUAAAAFAAUAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABwAFAAUABQAFAAUABQAAAAUABQAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABQAFAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABQAFAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAHAAUABQAFAAUABQAFAAUABwAHAAcABwAHAAcABwAHAAUABwAHAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABwAHAAcABwAFAAUABwAHAAcAAAAAAAAAAAAHAAcABQAHAAcABwAHAAcABwAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAHAAUABQAFAAUABQAFAAUAAAAFAAAABQAAAAAABQAFAAUABQAFAAUABQAFAAcABwAHAAcABwAHAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAUABQAFAAUABQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABwAFAAcABwAHAAcABwAFAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAUABQAFAAUABwAHAAUABQAHAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABQAFAAcABwAHAAUABwAFAAUABQAHAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAUABQAFAAUABQAFAAUABQAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAcABQAFAAUABQAFAAUABQAAAAAAAAAAAAUAAAAAAAAAAAAAAAAABQAAAAAABwAFAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUAAAAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAABQAAAAAAAAAFAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAUABQAHAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAHAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABwAFAAUABQAFAAcABwAFAAUABwAHAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAcABwAFAAUABwAHAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAFAAUABQAAAAAABQAFAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAFAAcABwAAAAAAAAAAAAAABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAFAAcABwAFAAcABwAAAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAFAAUABQAAAAUABQAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABwAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABQAFAAUABQAFAAUABQAFAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAHAAcABQAHAAUABQAAAAAAAAAAAAAAAAAFAAAABwAHAAcABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAcABwAAAAAABwAHAAAAAAAHAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABwAHAAUABQAFAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABQAFAAUABQAFAAUABwAFAAcABwAFAAcABQAFAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABQAFAAUABQAAAAAABwAHAAcABwAFAAUABwAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAHAAUABQAFAAUABQAFAAUABQAHAAcABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAFAAcABwAFAAUABQAFAAUABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAcABwAFAAUABQAFAAcABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABQAHAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAAAAAAFAAUABwAHAAcABwAFAAAAAAAAAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABwAHAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAHAAUABQAFAAUABQAFAAUABwAFAAUABwAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAAAAAAAABQAAAAUABQAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAHAAcAAAAFAAUAAAAHAAcABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAAAAAAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAUABQAFAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAABQAFAAUABQAFAAUABQAAAAUABQAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAFAAUABQAFAAUADgAOAA4ADgAOAA4ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAAAAAAAAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAMAAwADAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAAAAAAAAAAAAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAAAAAAAAAAAAsADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwACwAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAADgAOAA4AAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAAAA4ADgAOAA4ADgAOAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAA4AAAAOAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAADgAAAAAAAAAAAA4AAAAOAAAAAAAAAAAADgAOAA4AAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAA4ADgAOAA4ADgAOAA4ADgAOAAAADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4AAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAOAA4ADgAOAA4ADgAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAAAAAAA=";
  var chars$1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var lookup$1 = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
  for (i$1 = 0; i$1 < chars$1.length; i$1++) {
    lookup$1[chars$1.charCodeAt(i$1)] = i$1;
  }
  var i$1;
  var decode = function(base642) {
    var bufferLength = base642.length * 0.75, len = base642.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
    if (base642[base642.length - 1] === "=") {
      bufferLength--;
      if (base642[base642.length - 2] === "=") {
        bufferLength--;
      }
    }
    var buffer = typeof ArrayBuffer !== "undefined" && typeof Uint8Array !== "undefined" && typeof Uint8Array.prototype.slice !== "undefined" ? new ArrayBuffer(bufferLength) : new Array(bufferLength);
    var bytes = Array.isArray(buffer) ? buffer : new Uint8Array(buffer);
    for (i = 0; i < len; i += 4) {
      encoded1 = lookup$1[base642.charCodeAt(i)];
      encoded2 = lookup$1[base642.charCodeAt(i + 1)];
      encoded3 = lookup$1[base642.charCodeAt(i + 2)];
      encoded4 = lookup$1[base642.charCodeAt(i + 3)];
      bytes[p++] = encoded1 << 2 | encoded2 >> 4;
      bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
      bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
    }
    return buffer;
  };
  var polyUint16Array = function(buffer) {
    var length = buffer.length;
    var bytes = [];
    for (var i = 0; i < length; i += 2) {
      bytes.push(buffer[i + 1] << 8 | buffer[i]);
    }
    return bytes;
  };
  var polyUint32Array = function(buffer) {
    var length = buffer.length;
    var bytes = [];
    for (var i = 0; i < length; i += 4) {
      bytes.push(buffer[i + 3] << 24 | buffer[i + 2] << 16 | buffer[i + 1] << 8 | buffer[i]);
    }
    return bytes;
  };
  var UTRIE2_SHIFT_2 = 5;
  var UTRIE2_SHIFT_1 = 6 + 5;
  var UTRIE2_INDEX_SHIFT = 2;
  var UTRIE2_SHIFT_1_2 = UTRIE2_SHIFT_1 - UTRIE2_SHIFT_2;
  var UTRIE2_LSCP_INDEX_2_OFFSET = 65536 >> UTRIE2_SHIFT_2;
  var UTRIE2_DATA_BLOCK_LENGTH = 1 << UTRIE2_SHIFT_2;
  var UTRIE2_DATA_MASK = UTRIE2_DATA_BLOCK_LENGTH - 1;
  var UTRIE2_LSCP_INDEX_2_LENGTH = 1024 >> UTRIE2_SHIFT_2;
  var UTRIE2_INDEX_2_BMP_LENGTH = UTRIE2_LSCP_INDEX_2_OFFSET + UTRIE2_LSCP_INDEX_2_LENGTH;
  var UTRIE2_UTF8_2B_INDEX_2_OFFSET = UTRIE2_INDEX_2_BMP_LENGTH;
  var UTRIE2_UTF8_2B_INDEX_2_LENGTH = 2048 >> 6;
  var UTRIE2_INDEX_1_OFFSET = UTRIE2_UTF8_2B_INDEX_2_OFFSET + UTRIE2_UTF8_2B_INDEX_2_LENGTH;
  var UTRIE2_OMITTED_BMP_INDEX_1_LENGTH = 65536 >> UTRIE2_SHIFT_1;
  var UTRIE2_INDEX_2_BLOCK_LENGTH = 1 << UTRIE2_SHIFT_1_2;
  var UTRIE2_INDEX_2_MASK = UTRIE2_INDEX_2_BLOCK_LENGTH - 1;
  var slice16 = function(view, start, end) {
    if (view.slice) {
      return view.slice(start, end);
    }
    return new Uint16Array(Array.prototype.slice.call(view, start, end));
  };
  var slice32 = function(view, start, end) {
    if (view.slice) {
      return view.slice(start, end);
    }
    return new Uint32Array(Array.prototype.slice.call(view, start, end));
  };
  var createTrieFromBase64 = function(base642, _byteLength) {
    var buffer = decode(base642);
    var view32 = Array.isArray(buffer) ? polyUint32Array(buffer) : new Uint32Array(buffer);
    var view16 = Array.isArray(buffer) ? polyUint16Array(buffer) : new Uint16Array(buffer);
    var headerLength = 24;
    var index = slice16(view16, headerLength / 2, view32[4] / 2);
    var data = view32[5] === 2 ? slice16(view16, (headerLength + view32[4]) / 2) : slice32(view32, Math.ceil((headerLength + view32[4]) / 4));
    return new Trie(view32[0], view32[1], view32[2], view32[3], index, data);
  };
  var Trie = (
    /** @class */
    (function() {
      function Trie2(initialValue, errorValue, highStart, highValueIndex, index, data) {
        this.initialValue = initialValue;
        this.errorValue = errorValue;
        this.highStart = highStart;
        this.highValueIndex = highValueIndex;
        this.index = index;
        this.data = data;
      }
      Trie2.prototype.get = function(codePoint) {
        var ix;
        if (codePoint >= 0) {
          if (codePoint < 55296 || codePoint > 56319 && codePoint <= 65535) {
            ix = this.index[codePoint >> UTRIE2_SHIFT_2];
            ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
            return this.data[ix];
          }
          if (codePoint <= 65535) {
            ix = this.index[UTRIE2_LSCP_INDEX_2_OFFSET + (codePoint - 55296 >> UTRIE2_SHIFT_2)];
            ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
            return this.data[ix];
          }
          if (codePoint < this.highStart) {
            ix = UTRIE2_INDEX_1_OFFSET - UTRIE2_OMITTED_BMP_INDEX_1_LENGTH + (codePoint >> UTRIE2_SHIFT_1);
            ix = this.index[ix];
            ix += codePoint >> UTRIE2_SHIFT_2 & UTRIE2_INDEX_2_MASK;
            ix = this.index[ix];
            ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
            return this.data[ix];
          }
          if (codePoint <= 1114111) {
            return this.data[this.highValueIndex];
          }
        }
        return this.errorValue;
      };
      return Trie2;
    })()
  );
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var lookup = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
  for (i = 0; i < chars.length; i++) {
    lookup[chars.charCodeAt(i)] = i;
  }
  var i;
  var Prepend = 1;
  var CR = 2;
  var LF = 3;
  var Control = 4;
  var Extend = 5;
  var SpacingMark = 7;
  var L = 8;
  var V = 9;
  var T = 10;
  var LV = 11;
  var LVT = 12;
  var ZWJ = 13;
  var Extended_Pictographic = 14;
  var RI = 15;
  var toCodePoints = function(str) {
    var codePoints = [];
    var i = 0;
    var length = str.length;
    while (i < length) {
      var value = str.charCodeAt(i++);
      if (value >= 55296 && value <= 56319 && i < length) {
        var extra = str.charCodeAt(i++);
        if ((extra & 64512) === 56320) {
          codePoints.push(((value & 1023) << 10) + (extra & 1023) + 65536);
        } else {
          codePoints.push(value);
          i--;
        }
      } else {
        codePoints.push(value);
      }
    }
    return codePoints;
  };
  var fromCodePoint = function() {
    var codePoints = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      codePoints[_i] = arguments[_i];
    }
    if (String.fromCodePoint) {
      return String.fromCodePoint.apply(String, codePoints);
    }
    var length = codePoints.length;
    if (!length) {
      return "";
    }
    var codeUnits = [];
    var index = -1;
    var result = "";
    while (++index < length) {
      var codePoint = codePoints[index];
      if (codePoint <= 65535) {
        codeUnits.push(codePoint);
      } else {
        codePoint -= 65536;
        codeUnits.push((codePoint >> 10) + 55296, codePoint % 1024 + 56320);
      }
      if (index + 1 === length || codeUnits.length > 16384) {
        result += String.fromCharCode.apply(String, codeUnits);
        codeUnits.length = 0;
      }
    }
    return result;
  };
  var UnicodeTrie = createTrieFromBase64(base64);
  var BREAK_NOT_ALLOWED = "\xD7";
  var BREAK_ALLOWED = "\xF7";
  var codePointToClass = function(codePoint) {
    return UnicodeTrie.get(codePoint);
  };
  var _graphemeBreakAtIndex = function(_codePoints, classTypes, index) {
    var prevIndex = index - 2;
    var prev = classTypes[prevIndex];
    var current = classTypes[index - 1];
    var next = classTypes[index];
    if (current === CR && next === LF) {
      return BREAK_NOT_ALLOWED;
    }
    if (current === CR || current === LF || current === Control) {
      return BREAK_ALLOWED;
    }
    if (next === CR || next === LF || next === Control) {
      return BREAK_ALLOWED;
    }
    if (current === L && [L, V, LV, LVT].indexOf(next) !== -1) {
      return BREAK_NOT_ALLOWED;
    }
    if ((current === LV || current === V) && (next === V || next === T)) {
      return BREAK_NOT_ALLOWED;
    }
    if ((current === LVT || current === T) && next === T) {
      return BREAK_NOT_ALLOWED;
    }
    if (next === ZWJ || next === Extend) {
      return BREAK_NOT_ALLOWED;
    }
    if (next === SpacingMark) {
      return BREAK_NOT_ALLOWED;
    }
    if (current === Prepend) {
      return BREAK_NOT_ALLOWED;
    }
    if (current === ZWJ && next === Extended_Pictographic) {
      while (prev === Extend) {
        prev = classTypes[--prevIndex];
      }
      if (prev === Extended_Pictographic) {
        return BREAK_NOT_ALLOWED;
      }
    }
    if (current === RI && next === RI) {
      var countRI = 0;
      while (prev === RI) {
        countRI++;
        prev = classTypes[--prevIndex];
      }
      if (countRI % 2 === 0) {
        return BREAK_NOT_ALLOWED;
      }
    }
    return BREAK_ALLOWED;
  };
  var GraphemeBreaker = function(str) {
    var codePoints = toCodePoints(str);
    var length = codePoints.length;
    var index = 0;
    var lastEnd = 0;
    var classTypes = codePoints.map(codePointToClass);
    return {
      next: function() {
        if (index >= length) {
          return { done: true, value: null };
        }
        var graphemeBreak = BREAK_NOT_ALLOWED;
        while (index < length && (graphemeBreak = _graphemeBreakAtIndex(codePoints, classTypes, ++index)) === BREAK_NOT_ALLOWED) {
        }
        if (graphemeBreak !== BREAK_NOT_ALLOWED || index === length) {
          var value = fromCodePoint.apply(null, codePoints.slice(lastEnd, index));
          lastEnd = index;
          return { value, done: false };
        }
        return { done: true, value: null };
      }
    };
  };
  var splitGraphemes = function(str) {
    var breaker = GraphemeBreaker(str);
    var graphemes = [];
    var bk;
    while (!(bk = breaker.next()).done) {
      if (bk.value) {
        graphemes.push(bk.value.slice());
      }
    }
    return graphemes;
  };
  var testRangeBounds = function(document2) {
    var TEST_HEIGHT = 123;
    if (document2.createRange) {
      var range = document2.createRange();
      if (range.getBoundingClientRect) {
        var testElement = document2.createElement("boundtest");
        testElement.style.height = TEST_HEIGHT + "px";
        testElement.style.display = "block";
        document2.body.appendChild(testElement);
        range.selectNode(testElement);
        var rangeBounds = range.getBoundingClientRect();
        var rangeHeight = Math.round(rangeBounds.height);
        document2.body.removeChild(testElement);
        if (rangeHeight === TEST_HEIGHT) {
          return true;
        }
      }
    }
    return false;
  };
  var testIOSLineBreak = function(document2) {
    var testElement = document2.createElement("boundtest");
    testElement.style.width = "50px";
    testElement.style.display = "block";
    testElement.style.fontSize = "12px";
    testElement.style.letterSpacing = "0px";
    testElement.style.wordSpacing = "0px";
    document2.body.appendChild(testElement);
    var range = document2.createRange();
    testElement.innerHTML = typeof "".repeat === "function" ? "&#128104;".repeat(10) : "";
    var node = testElement.firstChild;
    var textList = toCodePoints$1(node.data).map(function(i) {
      return fromCodePoint$1(i);
    });
    var offset = 0;
    var prev = {};
    var supports = textList.every(function(text, i) {
      range.setStart(node, offset);
      range.setEnd(node, offset + text.length);
      var rect = range.getBoundingClientRect();
      offset += text.length;
      var boundAhead = rect.x > prev.x || rect.y > prev.y;
      prev = rect;
      if (i === 0) {
        return true;
      }
      return boundAhead;
    });
    document2.body.removeChild(testElement);
    return supports;
  };
  var testCORS = function() {
    return typeof new Image().crossOrigin !== "undefined";
  };
  var testResponseType = function() {
    return typeof new XMLHttpRequest().responseType === "string";
  };
  var testSVG = function(document2) {
    var img = new Image();
    var canvas = document2.createElement("canvas");
    var ctx = canvas.getContext("2d");
    if (!ctx) {
      return false;
    }
    img.src = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'></svg>";
    try {
      ctx.drawImage(img, 0, 0);
      canvas.toDataURL();
    } catch (e2) {
      return false;
    }
    return true;
  };
  var isGreenPixel = function(data) {
    return data[0] === 0 && data[1] === 255 && data[2] === 0 && data[3] === 255;
  };
  var testForeignObject = function(document2) {
    var canvas = document2.createElement("canvas");
    var size = 100;
    canvas.width = size;
    canvas.height = size;
    var ctx = canvas.getContext("2d");
    if (!ctx) {
      return Promise.reject(false);
    }
    ctx.fillStyle = "rgb(0, 255, 0)";
    ctx.fillRect(0, 0, size, size);
    var img = new Image();
    var greenImageSrc = canvas.toDataURL();
    img.src = greenImageSrc;
    var svg = createForeignObjectSVG(size, size, 0, 0, img);
    ctx.fillStyle = "red";
    ctx.fillRect(0, 0, size, size);
    return loadSerializedSVG$1(svg).then(function(img2) {
      ctx.drawImage(img2, 0, 0);
      var data = ctx.getImageData(0, 0, size, size).data;
      ctx.fillStyle = "red";
      ctx.fillRect(0, 0, size, size);
      var node = document2.createElement("div");
      node.style.backgroundImage = "url(" + greenImageSrc + ")";
      node.style.height = size + "px";
      return isGreenPixel(data) ? loadSerializedSVG$1(createForeignObjectSVG(size, size, 0, 0, node)) : Promise.reject(false);
    }).then(function(img2) {
      ctx.drawImage(img2, 0, 0);
      return isGreenPixel(ctx.getImageData(0, 0, size, size).data);
    }).catch(function() {
      return false;
    });
  };
  var createForeignObjectSVG = function(width, height, x, y, node) {
    var xmlns = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(xmlns, "svg");
    var foreignObject = document.createElementNS(xmlns, "foreignObject");
    svg.setAttributeNS(null, "width", width.toString());
    svg.setAttributeNS(null, "height", height.toString());
    foreignObject.setAttributeNS(null, "width", "100%");
    foreignObject.setAttributeNS(null, "height", "100%");
    foreignObject.setAttributeNS(null, "x", x.toString());
    foreignObject.setAttributeNS(null, "y", y.toString());
    foreignObject.setAttributeNS(null, "externalResourcesRequired", "true");
    svg.appendChild(foreignObject);
    foreignObject.appendChild(node);
    return svg;
  };
  var loadSerializedSVG$1 = function(svg) {
    return new Promise(function(resolve, reject) {
      var img = new Image();
      img.onload = function() {
        return resolve(img);
      };
      img.onerror = reject;
      img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(svg));
    });
  };
  var FEATURES = {
    get SUPPORT_RANGE_BOUNDS() {
      var value = testRangeBounds(document);
      Object.defineProperty(FEATURES, "SUPPORT_RANGE_BOUNDS", { value });
      return value;
    },
    get SUPPORT_WORD_BREAKING() {
      var value = FEATURES.SUPPORT_RANGE_BOUNDS && testIOSLineBreak(document);
      Object.defineProperty(FEATURES, "SUPPORT_WORD_BREAKING", { value });
      return value;
    },
    get SUPPORT_SVG_DRAWING() {
      var value = testSVG(document);
      Object.defineProperty(FEATURES, "SUPPORT_SVG_DRAWING", { value });
      return value;
    },
    get SUPPORT_FOREIGNOBJECT_DRAWING() {
      var value = typeof Array.from === "function" && typeof window.fetch === "function" ? testForeignObject(document) : Promise.resolve(false);
      Object.defineProperty(FEATURES, "SUPPORT_FOREIGNOBJECT_DRAWING", { value });
      return value;
    },
    get SUPPORT_CORS_IMAGES() {
      var value = testCORS();
      Object.defineProperty(FEATURES, "SUPPORT_CORS_IMAGES", { value });
      return value;
    },
    get SUPPORT_RESPONSE_TYPE() {
      var value = testResponseType();
      Object.defineProperty(FEATURES, "SUPPORT_RESPONSE_TYPE", { value });
      return value;
    },
    get SUPPORT_CORS_XHR() {
      var value = "withCredentials" in new XMLHttpRequest();
      Object.defineProperty(FEATURES, "SUPPORT_CORS_XHR", { value });
      return value;
    },
    get SUPPORT_NATIVE_TEXT_SEGMENTATION() {
      var value = !!(typeof Intl !== "undefined" && Intl.Segmenter);
      Object.defineProperty(FEATURES, "SUPPORT_NATIVE_TEXT_SEGMENTATION", { value });
      return value;
    }
  };
  var TextBounds = (
    /** @class */
    /* @__PURE__ */ (function() {
      function TextBounds2(text, bounds) {
        this.text = text;
        this.bounds = bounds;
      }
      return TextBounds2;
    })()
  );
  var parseTextBounds = function(context, value, styles, node) {
    var textList = breakText(value, styles);
    var textBounds = [];
    var offset = 0;
    textList.forEach(function(text) {
      if (styles.textDecorationLine.length || text.trim().length > 0) {
        if (FEATURES.SUPPORT_RANGE_BOUNDS) {
          var clientRects = createRange(node, offset, text.length).getClientRects();
          if (clientRects.length > 1) {
            var subSegments = segmentGraphemes(text);
            var subOffset_1 = 0;
            subSegments.forEach(function(subSegment) {
              textBounds.push(new TextBounds(subSegment, Bounds.fromDOMRectList(context, createRange(node, subOffset_1 + offset, subSegment.length).getClientRects())));
              subOffset_1 += subSegment.length;
            });
          } else {
            textBounds.push(new TextBounds(text, Bounds.fromDOMRectList(context, clientRects)));
          }
        } else {
          var replacementNode = node.splitText(text.length);
          textBounds.push(new TextBounds(text, getWrapperBounds(context, node)));
          node = replacementNode;
        }
      } else if (!FEATURES.SUPPORT_RANGE_BOUNDS) {
        node = node.splitText(text.length);
      }
      offset += text.length;
    });
    return textBounds;
  };
  var getWrapperBounds = function(context, node) {
    var ownerDocument = node.ownerDocument;
    if (ownerDocument) {
      var wrapper = ownerDocument.createElement("html2canvaswrapper");
      wrapper.appendChild(node.cloneNode(true));
      var parentNode = node.parentNode;
      if (parentNode) {
        parentNode.replaceChild(wrapper, node);
        var bounds = parseBounds(context, wrapper);
        if (wrapper.firstChild) {
          parentNode.replaceChild(wrapper.firstChild, wrapper);
        }
        return bounds;
      }
    }
    return Bounds.EMPTY;
  };
  var createRange = function(node, offset, length) {
    var ownerDocument = node.ownerDocument;
    if (!ownerDocument) {
      throw new Error("Node has no owner document");
    }
    var range = ownerDocument.createRange();
    range.setStart(node, offset);
    range.setEnd(node, offset + length);
    return range;
  };
  var segmentGraphemes = function(value) {
    if (FEATURES.SUPPORT_NATIVE_TEXT_SEGMENTATION) {
      var segmenter = new Intl.Segmenter(void 0, { granularity: "grapheme" });
      return Array.from(segmenter.segment(value)).map(function(segment) {
        return segment.segment;
      });
    }
    return splitGraphemes(value);
  };
  var segmentWords = function(value, styles) {
    if (FEATURES.SUPPORT_NATIVE_TEXT_SEGMENTATION) {
      var segmenter = new Intl.Segmenter(void 0, {
        granularity: "word"
      });
      return Array.from(segmenter.segment(value)).map(function(segment) {
        return segment.segment;
      });
    }
    return breakWords(value, styles);
  };
  var breakText = function(value, styles) {
    return styles.letterSpacing !== 0 ? segmentGraphemes(value) : segmentWords(value, styles);
  };
  var wordSeparators = [32, 160, 4961, 65792, 65793, 4153, 4241];
  var breakWords = function(str, styles) {
    var breaker = LineBreaker(str, {
      lineBreak: styles.lineBreak,
      wordBreak: styles.overflowWrap === "break-word" ? "break-word" : styles.wordBreak
    });
    var words = [];
    var bk;
    var _loop_1 = function() {
      if (bk.value) {
        var value = bk.value.slice();
        var codePoints = toCodePoints$1(value);
        var word_1 = "";
        codePoints.forEach(function(codePoint) {
          if (wordSeparators.indexOf(codePoint) === -1) {
            word_1 += fromCodePoint$1(codePoint);
          } else {
            if (word_1.length) {
              words.push(word_1);
            }
            words.push(fromCodePoint$1(codePoint));
            word_1 = "";
          }
        });
        if (word_1.length) {
          words.push(word_1);
        }
      }
    };
    while (!(bk = breaker.next()).done) {
      _loop_1();
    }
    return words;
  };
  var TextContainer = (
    /** @class */
    /* @__PURE__ */ (function() {
      function TextContainer2(context, node, styles) {
        this.text = transform(node.data, styles.textTransform);
        this.textBounds = parseTextBounds(context, this.text, styles, node);
      }
      return TextContainer2;
    })()
  );
  var transform = function(text, transform2) {
    switch (transform2) {
      case 1:
        return text.toLowerCase();
      case 3:
        return text.replace(CAPITALIZE, capitalize);
      case 2:
        return text.toUpperCase();
      default:
        return text;
    }
  };
  var CAPITALIZE = /(^|\s|:|-|\(|\))([a-z])/g;
  var capitalize = function(m, p1, p2) {
    if (m.length > 0) {
      return p1 + p2.toUpperCase();
    }
    return m;
  };
  var ImageElementContainer = (
    /** @class */
    (function(_super) {
      __extends(ImageElementContainer2, _super);
      function ImageElementContainer2(context, img) {
        var _this = _super.call(this, context, img) || this;
        _this.src = img.currentSrc || img.src;
        _this.intrinsicWidth = img.naturalWidth;
        _this.intrinsicHeight = img.naturalHeight;
        _this.context.cache.addImage(_this.src);
        return _this;
      }
      return ImageElementContainer2;
    })(ElementContainer)
  );
  var CanvasElementContainer = (
    /** @class */
    (function(_super) {
      __extends(CanvasElementContainer2, _super);
      function CanvasElementContainer2(context, canvas) {
        var _this = _super.call(this, context, canvas) || this;
        _this.canvas = canvas;
        _this.intrinsicWidth = canvas.width;
        _this.intrinsicHeight = canvas.height;
        return _this;
      }
      return CanvasElementContainer2;
    })(ElementContainer)
  );
  var SVGElementContainer = (
    /** @class */
    (function(_super) {
      __extends(SVGElementContainer2, _super);
      function SVGElementContainer2(context, img) {
        var _this = _super.call(this, context, img) || this;
        var s = new XMLSerializer();
        var bounds = parseBounds(context, img);
        img.setAttribute("width", bounds.width + "px");
        img.setAttribute("height", bounds.height + "px");
        _this.svg = "data:image/svg+xml," + encodeURIComponent(s.serializeToString(img));
        _this.intrinsicWidth = img.width.baseVal.value;
        _this.intrinsicHeight = img.height.baseVal.value;
        _this.context.cache.addImage(_this.svg);
        return _this;
      }
      return SVGElementContainer2;
    })(ElementContainer)
  );
  var LIElementContainer = (
    /** @class */
    (function(_super) {
      __extends(LIElementContainer2, _super);
      function LIElementContainer2(context, element) {
        var _this = _super.call(this, context, element) || this;
        _this.value = element.value;
        return _this;
      }
      return LIElementContainer2;
    })(ElementContainer)
  );
  var OLElementContainer = (
    /** @class */
    (function(_super) {
      __extends(OLElementContainer2, _super);
      function OLElementContainer2(context, element) {
        var _this = _super.call(this, context, element) || this;
        _this.start = element.start;
        _this.reversed = typeof element.reversed === "boolean" && element.reversed === true;
        return _this;
      }
      return OLElementContainer2;
    })(ElementContainer)
  );
  var CHECKBOX_BORDER_RADIUS = [
    {
      type: 15,
      flags: 0,
      unit: "px",
      number: 3
    }
  ];
  var RADIO_BORDER_RADIUS = [
    {
      type: 16,
      flags: 0,
      number: 50
    }
  ];
  var reformatInputBounds = function(bounds) {
    if (bounds.width > bounds.height) {
      return new Bounds(bounds.left + (bounds.width - bounds.height) / 2, bounds.top, bounds.height, bounds.height);
    } else if (bounds.width < bounds.height) {
      return new Bounds(bounds.left, bounds.top + (bounds.height - bounds.width) / 2, bounds.width, bounds.width);
    }
    return bounds;
  };
  var getInputValue = function(node) {
    var value = node.type === PASSWORD ? new Array(node.value.length + 1).join("\u2022") : node.value;
    return value.length === 0 ? node.placeholder || "" : value;
  };
  var CHECKBOX = "checkbox";
  var RADIO = "radio";
  var PASSWORD = "password";
  var INPUT_COLOR = 707406591;
  var InputElementContainer = (
    /** @class */
    (function(_super) {
      __extends(InputElementContainer2, _super);
      function InputElementContainer2(context, input) {
        var _this = _super.call(this, context, input) || this;
        _this.type = input.type.toLowerCase();
        _this.checked = input.checked;
        _this.value = getInputValue(input);
        if (_this.type === CHECKBOX || _this.type === RADIO) {
          _this.styles.backgroundColor = 3739148031;
          _this.styles.borderTopColor = _this.styles.borderRightColor = _this.styles.borderBottomColor = _this.styles.borderLeftColor = 2779096575;
          _this.styles.borderTopWidth = _this.styles.borderRightWidth = _this.styles.borderBottomWidth = _this.styles.borderLeftWidth = 1;
          _this.styles.borderTopStyle = _this.styles.borderRightStyle = _this.styles.borderBottomStyle = _this.styles.borderLeftStyle = 1;
          _this.styles.backgroundClip = [
            0
            /* BORDER_BOX */
          ];
          _this.styles.backgroundOrigin = [
            0
            /* BORDER_BOX */
          ];
          _this.bounds = reformatInputBounds(_this.bounds);
        }
        switch (_this.type) {
          case CHECKBOX:
            _this.styles.borderTopRightRadius = _this.styles.borderTopLeftRadius = _this.styles.borderBottomRightRadius = _this.styles.borderBottomLeftRadius = CHECKBOX_BORDER_RADIUS;
            break;
          case RADIO:
            _this.styles.borderTopRightRadius = _this.styles.borderTopLeftRadius = _this.styles.borderBottomRightRadius = _this.styles.borderBottomLeftRadius = RADIO_BORDER_RADIUS;
            break;
        }
        return _this;
      }
      return InputElementContainer2;
    })(ElementContainer)
  );
  var SelectElementContainer = (
    /** @class */
    (function(_super) {
      __extends(SelectElementContainer2, _super);
      function SelectElementContainer2(context, element) {
        var _this = _super.call(this, context, element) || this;
        var option = element.options[element.selectedIndex || 0];
        _this.value = option ? option.text || "" : "";
        return _this;
      }
      return SelectElementContainer2;
    })(ElementContainer)
  );
  var TextareaElementContainer = (
    /** @class */
    (function(_super) {
      __extends(TextareaElementContainer2, _super);
      function TextareaElementContainer2(context, element) {
        var _this = _super.call(this, context, element) || this;
        _this.value = element.value;
        return _this;
      }
      return TextareaElementContainer2;
    })(ElementContainer)
  );
  var IFrameElementContainer = (
    /** @class */
    (function(_super) {
      __extends(IFrameElementContainer2, _super);
      function IFrameElementContainer2(context, iframe) {
        var _this = _super.call(this, context, iframe) || this;
        _this.src = iframe.src;
        _this.width = parseInt(iframe.width, 10) || 0;
        _this.height = parseInt(iframe.height, 10) || 0;
        _this.backgroundColor = _this.styles.backgroundColor;
        try {
          if (iframe.contentWindow && iframe.contentWindow.document && iframe.contentWindow.document.documentElement) {
            _this.tree = parseTree(context, iframe.contentWindow.document.documentElement);
            var documentBackgroundColor = iframe.contentWindow.document.documentElement ? parseColor(context, getComputedStyle(iframe.contentWindow.document.documentElement).backgroundColor) : COLORS.TRANSPARENT;
            var bodyBackgroundColor = iframe.contentWindow.document.body ? parseColor(context, getComputedStyle(iframe.contentWindow.document.body).backgroundColor) : COLORS.TRANSPARENT;
            _this.backgroundColor = isTransparent(documentBackgroundColor) ? isTransparent(bodyBackgroundColor) ? _this.styles.backgroundColor : bodyBackgroundColor : documentBackgroundColor;
          }
        } catch (e2) {
        }
        return _this;
      }
      return IFrameElementContainer2;
    })(ElementContainer)
  );
  var LIST_OWNERS = ["OL", "UL", "MENU"];
  var parseNodeTree = function(context, node, parent, root) {
    for (var childNode = node.firstChild, nextNode = void 0; childNode; childNode = nextNode) {
      nextNode = childNode.nextSibling;
      if (isTextNode(childNode) && childNode.data.trim().length > 0) {
        parent.textNodes.push(new TextContainer(context, childNode, parent.styles));
      } else if (isElementNode(childNode)) {
        if (isSlotElement(childNode) && childNode.assignedNodes) {
          childNode.assignedNodes().forEach(function(childNode2) {
            return parseNodeTree(context, childNode2, parent, root);
          });
        } else {
          var container = createContainer(context, childNode);
          if (container.styles.isVisible()) {
            if (createsRealStackingContext(childNode, container, root)) {
              container.flags |= 4;
            } else if (createsStackingContext(container.styles)) {
              container.flags |= 2;
            }
            if (LIST_OWNERS.indexOf(childNode.tagName) !== -1) {
              container.flags |= 8;
            }
            parent.elements.push(container);
            childNode.slot;
            if (childNode.shadowRoot) {
              parseNodeTree(context, childNode.shadowRoot, container, root);
            } else if (!isTextareaElement(childNode) && !isSVGElement(childNode) && !isSelectElement(childNode)) {
              parseNodeTree(context, childNode, container, root);
            }
          }
        }
      }
    }
  };
  var createContainer = function(context, element) {
    if (isImageElement(element)) {
      return new ImageElementContainer(context, element);
    }
    if (isCanvasElement(element)) {
      return new CanvasElementContainer(context, element);
    }
    if (isSVGElement(element)) {
      return new SVGElementContainer(context, element);
    }
    if (isLIElement(element)) {
      return new LIElementContainer(context, element);
    }
    if (isOLElement(element)) {
      return new OLElementContainer(context, element);
    }
    if (isInputElement(element)) {
      return new InputElementContainer(context, element);
    }
    if (isSelectElement(element)) {
      return new SelectElementContainer(context, element);
    }
    if (isTextareaElement(element)) {
      return new TextareaElementContainer(context, element);
    }
    if (isIFrameElement(element)) {
      return new IFrameElementContainer(context, element);
    }
    return new ElementContainer(context, element);
  };
  var parseTree = function(context, element) {
    var container = createContainer(context, element);
    container.flags |= 4;
    parseNodeTree(context, element, container, container);
    return container;
  };
  var createsRealStackingContext = function(node, container, root) {
    return container.styles.isPositionedWithZIndex() || container.styles.opacity < 1 || container.styles.isTransformed() || isBodyElement(node) && root.styles.isTransparent();
  };
  var createsStackingContext = function(styles) {
    return styles.isPositioned() || styles.isFloating();
  };
  var isTextNode = function(node) {
    return node.nodeType === Node.TEXT_NODE;
  };
  var isElementNode = function(node) {
    return node.nodeType === Node.ELEMENT_NODE;
  };
  var isHTMLElementNode = function(node) {
    return isElementNode(node) && typeof node.style !== "undefined" && !isSVGElementNode(node);
  };
  var isSVGElementNode = function(element) {
    return typeof element.className === "object";
  };
  var isLIElement = function(node) {
    return node.tagName === "LI";
  };
  var isOLElement = function(node) {
    return node.tagName === "OL";
  };
  var isInputElement = function(node) {
    return node.tagName === "INPUT";
  };
  var isHTMLElement = function(node) {
    return node.tagName === "HTML";
  };
  var isSVGElement = function(node) {
    return node.tagName === "svg";
  };
  var isBodyElement = function(node) {
    return node.tagName === "BODY";
  };
  var isCanvasElement = function(node) {
    return node.tagName === "CANVAS";
  };
  var isVideoElement = function(node) {
    return node.tagName === "VIDEO";
  };
  var isImageElement = function(node) {
    return node.tagName === "IMG";
  };
  var isIFrameElement = function(node) {
    return node.tagName === "IFRAME";
  };
  var isStyleElement = function(node) {
    return node.tagName === "STYLE";
  };
  var isScriptElement = function(node) {
    return node.tagName === "SCRIPT";
  };
  var isTextareaElement = function(node) {
    return node.tagName === "TEXTAREA";
  };
  var isSelectElement = function(node) {
    return node.tagName === "SELECT";
  };
  var isSlotElement = function(node) {
    return node.tagName === "SLOT";
  };
  var isCustomElement = function(node) {
    return node.tagName.indexOf("-") > 0;
  };
  var CounterState = (
    /** @class */
    (function() {
      function CounterState2() {
        this.counters = {};
      }
      CounterState2.prototype.getCounterValue = function(name) {
        var counter = this.counters[name];
        if (counter && counter.length) {
          return counter[counter.length - 1];
        }
        return 1;
      };
      CounterState2.prototype.getCounterValues = function(name) {
        var counter = this.counters[name];
        return counter ? counter : [];
      };
      CounterState2.prototype.pop = function(counters) {
        var _this = this;
        counters.forEach(function(counter) {
          return _this.counters[counter].pop();
        });
      };
      CounterState2.prototype.parse = function(style) {
        var _this = this;
        var counterIncrement2 = style.counterIncrement;
        var counterReset2 = style.counterReset;
        var canReset = true;
        if (counterIncrement2 !== null) {
          counterIncrement2.forEach(function(entry) {
            var counter = _this.counters[entry.counter];
            if (counter && entry.increment !== 0) {
              canReset = false;
              if (!counter.length) {
                counter.push(1);
              }
              counter[Math.max(0, counter.length - 1)] += entry.increment;
            }
          });
        }
        var counterNames = [];
        if (canReset) {
          counterReset2.forEach(function(entry) {
            var counter = _this.counters[entry.counter];
            counterNames.push(entry.counter);
            if (!counter) {
              counter = _this.counters[entry.counter] = [];
            }
            counter.push(entry.reset);
          });
        }
        return counterNames;
      };
      return CounterState2;
    })()
  );
  var ROMAN_UPPER = {
    integers: [1e3, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1],
    values: ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
  };
  var ARMENIAN = {
    integers: [
      9e3,
      8e3,
      7e3,
      6e3,
      5e3,
      4e3,
      3e3,
      2e3,
      1e3,
      900,
      800,
      700,
      600,
      500,
      400,
      300,
      200,
      100,
      90,
      80,
      70,
      60,
      50,
      40,
      30,
      20,
      10,
      9,
      8,
      7,
      6,
      5,
      4,
      3,
      2,
      1
    ],
    values: [
      "\u0554",
      "\u0553",
      "\u0552",
      "\u0551",
      "\u0550",
      "\u054F",
      "\u054E",
      "\u054D",
      "\u054C",
      "\u054B",
      "\u054A",
      "\u0549",
      "\u0548",
      "\u0547",
      "\u0546",
      "\u0545",
      "\u0544",
      "\u0543",
      "\u0542",
      "\u0541",
      "\u0540",
      "\u053F",
      "\u053E",
      "\u053D",
      "\u053C",
      "\u053B",
      "\u053A",
      "\u0539",
      "\u0538",
      "\u0537",
      "\u0536",
      "\u0535",
      "\u0534",
      "\u0533",
      "\u0532",
      "\u0531"
    ]
  };
  var HEBREW = {
    integers: [
      1e4,
      9e3,
      8e3,
      7e3,
      6e3,
      5e3,
      4e3,
      3e3,
      2e3,
      1e3,
      400,
      300,
      200,
      100,
      90,
      80,
      70,
      60,
      50,
      40,
      30,
      20,
      19,
      18,
      17,
      16,
      15,
      10,
      9,
      8,
      7,
      6,
      5,
      4,
      3,
      2,
      1
    ],
    values: [
      "\u05D9\u05F3",
      "\u05D8\u05F3",
      "\u05D7\u05F3",
      "\u05D6\u05F3",
      "\u05D5\u05F3",
      "\u05D4\u05F3",
      "\u05D3\u05F3",
      "\u05D2\u05F3",
      "\u05D1\u05F3",
      "\u05D0\u05F3",
      "\u05EA",
      "\u05E9",
      "\u05E8",
      "\u05E7",
      "\u05E6",
      "\u05E4",
      "\u05E2",
      "\u05E1",
      "\u05E0",
      "\u05DE",
      "\u05DC",
      "\u05DB",
      "\u05D9\u05D8",
      "\u05D9\u05D7",
      "\u05D9\u05D6",
      "\u05D8\u05D6",
      "\u05D8\u05D5",
      "\u05D9",
      "\u05D8",
      "\u05D7",
      "\u05D6",
      "\u05D5",
      "\u05D4",
      "\u05D3",
      "\u05D2",
      "\u05D1",
      "\u05D0"
    ]
  };
  var GEORGIAN = {
    integers: [
      1e4,
      9e3,
      8e3,
      7e3,
      6e3,
      5e3,
      4e3,
      3e3,
      2e3,
      1e3,
      900,
      800,
      700,
      600,
      500,
      400,
      300,
      200,
      100,
      90,
      80,
      70,
      60,
      50,
      40,
      30,
      20,
      10,
      9,
      8,
      7,
      6,
      5,
      4,
      3,
      2,
      1
    ],
    values: [
      "\u10F5",
      "\u10F0",
      "\u10EF",
      "\u10F4",
      "\u10EE",
      "\u10ED",
      "\u10EC",
      "\u10EB",
      "\u10EA",
      "\u10E9",
      "\u10E8",
      "\u10E7",
      "\u10E6",
      "\u10E5",
      "\u10E4",
      "\u10F3",
      "\u10E2",
      "\u10E1",
      "\u10E0",
      "\u10DF",
      "\u10DE",
      "\u10DD",
      "\u10F2",
      "\u10DC",
      "\u10DB",
      "\u10DA",
      "\u10D9",
      "\u10D8",
      "\u10D7",
      "\u10F1",
      "\u10D6",
      "\u10D5",
      "\u10D4",
      "\u10D3",
      "\u10D2",
      "\u10D1",
      "\u10D0"
    ]
  };
  var createAdditiveCounter = function(value, min, max, symbols, fallback, suffix) {
    if (value < min || value > max) {
      return createCounterText(value, fallback, suffix.length > 0);
    }
    return symbols.integers.reduce(function(string, integer, index) {
      while (value >= integer) {
        value -= integer;
        string += symbols.values[index];
      }
      return string;
    }, "") + suffix;
  };
  var createCounterStyleWithSymbolResolver = function(value, codePointRangeLength, isNumeric, resolver) {
    var string = "";
    do {
      if (!isNumeric) {
        value--;
      }
      string = resolver(value) + string;
      value /= codePointRangeLength;
    } while (value * codePointRangeLength >= codePointRangeLength);
    return string;
  };
  var createCounterStyleFromRange = function(value, codePointRangeStart, codePointRangeEnd, isNumeric, suffix) {
    var codePointRangeLength = codePointRangeEnd - codePointRangeStart + 1;
    return (value < 0 ? "-" : "") + (createCounterStyleWithSymbolResolver(Math.abs(value), codePointRangeLength, isNumeric, function(codePoint) {
      return fromCodePoint$1(Math.floor(codePoint % codePointRangeLength) + codePointRangeStart);
    }) + suffix);
  };
  var createCounterStyleFromSymbols = function(value, symbols, suffix) {
    if (suffix === void 0) {
      suffix = ". ";
    }
    var codePointRangeLength = symbols.length;
    return createCounterStyleWithSymbolResolver(Math.abs(value), codePointRangeLength, false, function(codePoint) {
      return symbols[Math.floor(codePoint % codePointRangeLength)];
    }) + suffix;
  };
  var CJK_ZEROS = 1 << 0;
  var CJK_TEN_COEFFICIENTS = 1 << 1;
  var CJK_TEN_HIGH_COEFFICIENTS = 1 << 2;
  var CJK_HUNDRED_COEFFICIENTS = 1 << 3;
  var createCJKCounter = function(value, numbers, multipliers, negativeSign, suffix, flags) {
    if (value < -9999 || value > 9999) {
      return createCounterText(value, 4, suffix.length > 0);
    }
    var tmp = Math.abs(value);
    var string = suffix;
    if (tmp === 0) {
      return numbers[0] + string;
    }
    for (var digit = 0; tmp > 0 && digit <= 4; digit++) {
      var coefficient = tmp % 10;
      if (coefficient === 0 && contains(flags, CJK_ZEROS) && string !== "") {
        string = numbers[coefficient] + string;
      } else if (coefficient > 1 || coefficient === 1 && digit === 0 || coefficient === 1 && digit === 1 && contains(flags, CJK_TEN_COEFFICIENTS) || coefficient === 1 && digit === 1 && contains(flags, CJK_TEN_HIGH_COEFFICIENTS) && value > 100 || coefficient === 1 && digit > 1 && contains(flags, CJK_HUNDRED_COEFFICIENTS)) {
        string = numbers[coefficient] + (digit > 0 ? multipliers[digit - 1] : "") + string;
      } else if (coefficient === 1 && digit > 0) {
        string = multipliers[digit - 1] + string;
      }
      tmp = Math.floor(tmp / 10);
    }
    return (value < 0 ? negativeSign : "") + string;
  };
  var CHINESE_INFORMAL_MULTIPLIERS = "\u5341\u767E\u5343\u842C";
  var CHINESE_FORMAL_MULTIPLIERS = "\u62FE\u4F70\u4EDF\u842C";
  var JAPANESE_NEGATIVE = "\u30DE\u30A4\u30CA\u30B9";
  var KOREAN_NEGATIVE = "\uB9C8\uC774\uB108\uC2A4";
  var createCounterText = function(value, type, appendSuffix) {
    var defaultSuffix = appendSuffix ? ". " : "";
    var cjkSuffix = appendSuffix ? "\u3001" : "";
    var koreanSuffix = appendSuffix ? ", " : "";
    var spaceSuffix = appendSuffix ? " " : "";
    switch (type) {
      case 0:
        return "\u2022" + spaceSuffix;
      case 1:
        return "\u25E6" + spaceSuffix;
      case 2:
        return "\u25FE" + spaceSuffix;
      case 5:
        var string = createCounterStyleFromRange(value, 48, 57, true, defaultSuffix);
        return string.length < 4 ? "0" + string : string;
      case 4:
        return createCounterStyleFromSymbols(value, "\u3007\u4E00\u4E8C\u4E09\u56DB\u4E94\u516D\u4E03\u516B\u4E5D", cjkSuffix);
      case 6:
        return createAdditiveCounter(value, 1, 3999, ROMAN_UPPER, 3, defaultSuffix).toLowerCase();
      case 7:
        return createAdditiveCounter(value, 1, 3999, ROMAN_UPPER, 3, defaultSuffix);
      case 8:
        return createCounterStyleFromRange(value, 945, 969, false, defaultSuffix);
      case 9:
        return createCounterStyleFromRange(value, 97, 122, false, defaultSuffix);
      case 10:
        return createCounterStyleFromRange(value, 65, 90, false, defaultSuffix);
      case 11:
        return createCounterStyleFromRange(value, 1632, 1641, true, defaultSuffix);
      case 12:
      case 49:
        return createAdditiveCounter(value, 1, 9999, ARMENIAN, 3, defaultSuffix);
      case 35:
        return createAdditiveCounter(value, 1, 9999, ARMENIAN, 3, defaultSuffix).toLowerCase();
      case 13:
        return createCounterStyleFromRange(value, 2534, 2543, true, defaultSuffix);
      case 14:
      case 30:
        return createCounterStyleFromRange(value, 6112, 6121, true, defaultSuffix);
      case 15:
        return createCounterStyleFromSymbols(value, "\u5B50\u4E11\u5BC5\u536F\u8FB0\u5DF3\u5348\u672A\u7533\u9149\u620C\u4EA5", cjkSuffix);
      case 16:
        return createCounterStyleFromSymbols(value, "\u7532\u4E59\u4E19\u4E01\u620A\u5DF1\u5E9A\u8F9B\u58EC\u7678", cjkSuffix);
      case 17:
      case 48:
        return createCJKCounter(value, "\u96F6\u4E00\u4E8C\u4E09\u56DB\u4E94\u516D\u4E03\u516B\u4E5D", CHINESE_INFORMAL_MULTIPLIERS, "\u8CA0", cjkSuffix, CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);
      case 47:
        return createCJKCounter(value, "\u96F6\u58F9\u8CB3\u53C3\u8086\u4F0D\u9678\u67D2\u634C\u7396", CHINESE_FORMAL_MULTIPLIERS, "\u8CA0", cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);
      case 42:
        return createCJKCounter(value, "\u96F6\u4E00\u4E8C\u4E09\u56DB\u4E94\u516D\u4E03\u516B\u4E5D", CHINESE_INFORMAL_MULTIPLIERS, "\u8D1F", cjkSuffix, CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);
      case 41:
        return createCJKCounter(value, "\u96F6\u58F9\u8D30\u53C1\u8086\u4F0D\u9646\u67D2\u634C\u7396", CHINESE_FORMAL_MULTIPLIERS, "\u8D1F", cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);
      case 26:
        return createCJKCounter(value, "\u3007\u4E00\u4E8C\u4E09\u56DB\u4E94\u516D\u4E03\u516B\u4E5D", "\u5341\u767E\u5343\u4E07", JAPANESE_NEGATIVE, cjkSuffix, 0);
      case 25:
        return createCJKCounter(value, "\u96F6\u58F1\u5F10\u53C2\u56DB\u4F0D\u516D\u4E03\u516B\u4E5D", "\u62FE\u767E\u5343\u4E07", JAPANESE_NEGATIVE, cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);
      case 31:
        return createCJKCounter(value, "\uC601\uC77C\uC774\uC0BC\uC0AC\uC624\uC721\uCE60\uD314\uAD6C", "\uC2ED\uBC31\uCC9C\uB9CC", KOREAN_NEGATIVE, koreanSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);
      case 33:
        return createCJKCounter(value, "\u96F6\u4E00\u4E8C\u4E09\u56DB\u4E94\u516D\u4E03\u516B\u4E5D", "\u5341\u767E\u5343\u842C", KOREAN_NEGATIVE, koreanSuffix, 0);
      case 32:
        return createCJKCounter(value, "\u96F6\u58F9\u8CB3\u53C3\u56DB\u4E94\u516D\u4E03\u516B\u4E5D", "\u62FE\u767E\u5343", KOREAN_NEGATIVE, koreanSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);
      case 18:
        return createCounterStyleFromRange(value, 2406, 2415, true, defaultSuffix);
      case 20:
        return createAdditiveCounter(value, 1, 19999, GEORGIAN, 3, defaultSuffix);
      case 21:
        return createCounterStyleFromRange(value, 2790, 2799, true, defaultSuffix);
      case 22:
        return createCounterStyleFromRange(value, 2662, 2671, true, defaultSuffix);
      case 22:
        return createAdditiveCounter(value, 1, 10999, HEBREW, 3, defaultSuffix);
      case 23:
        return createCounterStyleFromSymbols(value, "\u3042\u3044\u3046\u3048\u304A\u304B\u304D\u304F\u3051\u3053\u3055\u3057\u3059\u305B\u305D\u305F\u3061\u3064\u3066\u3068\u306A\u306B\u306C\u306D\u306E\u306F\u3072\u3075\u3078\u307B\u307E\u307F\u3080\u3081\u3082\u3084\u3086\u3088\u3089\u308A\u308B\u308C\u308D\u308F\u3090\u3091\u3092\u3093");
      case 24:
        return createCounterStyleFromSymbols(value, "\u3044\u308D\u306F\u306B\u307B\u3078\u3068\u3061\u308A\u306C\u308B\u3092\u308F\u304B\u3088\u305F\u308C\u305D\u3064\u306D\u306A\u3089\u3080\u3046\u3090\u306E\u304A\u304F\u3084\u307E\u3051\u3075\u3053\u3048\u3066\u3042\u3055\u304D\u3086\u3081\u307F\u3057\u3091\u3072\u3082\u305B\u3059");
      case 27:
        return createCounterStyleFromRange(value, 3302, 3311, true, defaultSuffix);
      case 28:
        return createCounterStyleFromSymbols(value, "\u30A2\u30A4\u30A6\u30A8\u30AA\u30AB\u30AD\u30AF\u30B1\u30B3\u30B5\u30B7\u30B9\u30BB\u30BD\u30BF\u30C1\u30C4\u30C6\u30C8\u30CA\u30CB\u30CC\u30CD\u30CE\u30CF\u30D2\u30D5\u30D8\u30DB\u30DE\u30DF\u30E0\u30E1\u30E2\u30E4\u30E6\u30E8\u30E9\u30EA\u30EB\u30EC\u30ED\u30EF\u30F0\u30F1\u30F2\u30F3", cjkSuffix);
      case 29:
        return createCounterStyleFromSymbols(value, "\u30A4\u30ED\u30CF\u30CB\u30DB\u30D8\u30C8\u30C1\u30EA\u30CC\u30EB\u30F2\u30EF\u30AB\u30E8\u30BF\u30EC\u30BD\u30C4\u30CD\u30CA\u30E9\u30E0\u30A6\u30F0\u30CE\u30AA\u30AF\u30E4\u30DE\u30B1\u30D5\u30B3\u30A8\u30C6\u30A2\u30B5\u30AD\u30E6\u30E1\u30DF\u30B7\u30F1\u30D2\u30E2\u30BB\u30B9", cjkSuffix);
      case 34:
        return createCounterStyleFromRange(value, 3792, 3801, true, defaultSuffix);
      case 37:
        return createCounterStyleFromRange(value, 6160, 6169, true, defaultSuffix);
      case 38:
        return createCounterStyleFromRange(value, 4160, 4169, true, defaultSuffix);
      case 39:
        return createCounterStyleFromRange(value, 2918, 2927, true, defaultSuffix);
      case 40:
        return createCounterStyleFromRange(value, 1776, 1785, true, defaultSuffix);
      case 43:
        return createCounterStyleFromRange(value, 3046, 3055, true, defaultSuffix);
      case 44:
        return createCounterStyleFromRange(value, 3174, 3183, true, defaultSuffix);
      case 45:
        return createCounterStyleFromRange(value, 3664, 3673, true, defaultSuffix);
      case 46:
        return createCounterStyleFromRange(value, 3872, 3881, true, defaultSuffix);
      case 3:
      default:
        return createCounterStyleFromRange(value, 48, 57, true, defaultSuffix);
    }
  };
  var IGNORE_ATTRIBUTE = "data-html2canvas-ignore";
  var DocumentCloner = (
    /** @class */
    (function() {
      function DocumentCloner2(context, element, options) {
        this.context = context;
        this.options = options;
        this.scrolledElements = [];
        this.referenceElement = element;
        this.counters = new CounterState();
        this.quoteDepth = 0;
        if (!element.ownerDocument) {
          throw new Error("Cloned element does not have an owner document");
        }
        this.documentElement = this.cloneNode(element.ownerDocument.documentElement, false);
      }
      DocumentCloner2.prototype.toIFrame = function(ownerDocument, windowSize) {
        var _this = this;
        var iframe = createIFrameContainer(ownerDocument, windowSize);
        if (!iframe.contentWindow) {
          return Promise.reject("Unable to find iframe window");
        }
        var scrollX = ownerDocument.defaultView.pageXOffset;
        var scrollY = ownerDocument.defaultView.pageYOffset;
        var cloneWindow = iframe.contentWindow;
        var documentClone = cloneWindow.document;
        var iframeLoad = iframeLoader(iframe).then(function() {
          return __awaiter(_this, void 0, void 0, function() {
            var onclone, referenceElement;
            return __generator(this, function(_a) {
              switch (_a.label) {
                case 0:
                  this.scrolledElements.forEach(restoreNodeScroll);
                  if (cloneWindow) {
                    cloneWindow.scrollTo(windowSize.left, windowSize.top);
                    if (/(iPad|iPhone|iPod)/g.test(navigator.userAgent) && (cloneWindow.scrollY !== windowSize.top || cloneWindow.scrollX !== windowSize.left)) {
                      this.context.logger.warn("Unable to restore scroll position for cloned document");
                      this.context.windowBounds = this.context.windowBounds.add(cloneWindow.scrollX - windowSize.left, cloneWindow.scrollY - windowSize.top, 0, 0);
                    }
                  }
                  onclone = this.options.onclone;
                  referenceElement = this.clonedReferenceElement;
                  if (typeof referenceElement === "undefined") {
                    return [2, Promise.reject("Error finding the " + this.referenceElement.nodeName + " in the cloned document")];
                  }
                  if (!(documentClone.fonts && documentClone.fonts.ready)) return [3, 2];
                  return [4, documentClone.fonts.ready];
                case 1:
                  _a.sent();
                  _a.label = 2;
                case 2:
                  if (!/(AppleWebKit)/g.test(navigator.userAgent)) return [3, 4];
                  return [4, imagesReady(documentClone)];
                case 3:
                  _a.sent();
                  _a.label = 4;
                case 4:
                  if (typeof onclone === "function") {
                    return [2, Promise.resolve().then(function() {
                      return onclone(documentClone, referenceElement);
                    }).then(function() {
                      return iframe;
                    })];
                  }
                  return [2, iframe];
              }
            });
          });
        });
        documentClone.open();
        documentClone.write(serializeDoctype(document.doctype) + "<html></html>");
        restoreOwnerScroll(this.referenceElement.ownerDocument, scrollX, scrollY);
        documentClone.replaceChild(documentClone.adoptNode(this.documentElement), documentClone.documentElement);
        documentClone.close();
        return iframeLoad;
      };
      DocumentCloner2.prototype.createElementClone = function(node) {
        if (isDebugging(
          node,
          2
          /* CLONE */
        )) {
          debugger;
        }
        if (isCanvasElement(node)) {
          return this.createCanvasClone(node);
        }
        if (isVideoElement(node)) {
          return this.createVideoClone(node);
        }
        if (isStyleElement(node)) {
          return this.createStyleClone(node);
        }
        var clone = node.cloneNode(false);
        if (isImageElement(clone)) {
          if (isImageElement(node) && node.currentSrc && node.currentSrc !== node.src) {
            clone.src = node.currentSrc;
            clone.srcset = "";
          }
          if (clone.loading === "lazy") {
            clone.loading = "eager";
          }
        }
        if (isCustomElement(clone)) {
          return this.createCustomElementClone(clone);
        }
        return clone;
      };
      DocumentCloner2.prototype.createCustomElementClone = function(node) {
        var clone = document.createElement("html2canvascustomelement");
        copyCSSStyles(node.style, clone);
        return clone;
      };
      DocumentCloner2.prototype.createStyleClone = function(node) {
        try {
          var sheet = node.sheet;
          if (sheet && sheet.cssRules) {
            var css = [].slice.call(sheet.cssRules, 0).reduce(function(css2, rule) {
              if (rule && typeof rule.cssText === "string") {
                return css2 + rule.cssText;
              }
              return css2;
            }, "");
            var style = node.cloneNode(false);
            style.textContent = css;
            return style;
          }
        } catch (e2) {
          this.context.logger.error("Unable to access cssRules property", e2);
          if (e2.name !== "SecurityError") {
            throw e2;
          }
        }
        return node.cloneNode(false);
      };
      DocumentCloner2.prototype.createCanvasClone = function(canvas) {
        var _a;
        if (this.options.inlineImages && canvas.ownerDocument) {
          var img = canvas.ownerDocument.createElement("img");
          try {
            img.src = canvas.toDataURL();
            return img;
          } catch (e2) {
            this.context.logger.info("Unable to inline canvas contents, canvas is tainted", canvas);
          }
        }
        var clonedCanvas = canvas.cloneNode(false);
        try {
          clonedCanvas.width = canvas.width;
          clonedCanvas.height = canvas.height;
          var ctx = canvas.getContext("2d");
          var clonedCtx = clonedCanvas.getContext("2d");
          if (clonedCtx) {
            if (!this.options.allowTaint && ctx) {
              clonedCtx.putImageData(ctx.getImageData(0, 0, canvas.width, canvas.height), 0, 0);
            } else {
              var gl = (_a = canvas.getContext("webgl2")) !== null && _a !== void 0 ? _a : canvas.getContext("webgl");
              if (gl) {
                var attribs = gl.getContextAttributes();
                if ((attribs === null || attribs === void 0 ? void 0 : attribs.preserveDrawingBuffer) === false) {
                  this.context.logger.warn("Unable to clone WebGL context as it has preserveDrawingBuffer=false", canvas);
                }
              }
              clonedCtx.drawImage(canvas, 0, 0);
            }
          }
          return clonedCanvas;
        } catch (e2) {
          this.context.logger.info("Unable to clone canvas as it is tainted", canvas);
        }
        return clonedCanvas;
      };
      DocumentCloner2.prototype.createVideoClone = function(video) {
        var canvas = video.ownerDocument.createElement("canvas");
        canvas.width = video.offsetWidth;
        canvas.height = video.offsetHeight;
        var ctx = canvas.getContext("2d");
        try {
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            if (!this.options.allowTaint) {
              ctx.getImageData(0, 0, canvas.width, canvas.height);
            }
          }
          return canvas;
        } catch (e2) {
          this.context.logger.info("Unable to clone video as it is tainted", video);
        }
        var blankCanvas = video.ownerDocument.createElement("canvas");
        blankCanvas.width = video.offsetWidth;
        blankCanvas.height = video.offsetHeight;
        return blankCanvas;
      };
      DocumentCloner2.prototype.appendChildNode = function(clone, child, copyStyles) {
        if (!isElementNode(child) || !isScriptElement(child) && !child.hasAttribute(IGNORE_ATTRIBUTE) && (typeof this.options.ignoreElements !== "function" || !this.options.ignoreElements(child))) {
          if (!this.options.copyStyles || !isElementNode(child) || !isStyleElement(child)) {
            clone.appendChild(this.cloneNode(child, copyStyles));
          }
        }
      };
      DocumentCloner2.prototype.cloneChildNodes = function(node, clone, copyStyles) {
        var _this = this;
        for (var child = node.shadowRoot ? node.shadowRoot.firstChild : node.firstChild; child; child = child.nextSibling) {
          if (isElementNode(child) && isSlotElement(child) && typeof child.assignedNodes === "function") {
            var assignedNodes = child.assignedNodes();
            if (assignedNodes.length) {
              assignedNodes.forEach(function(assignedNode) {
                return _this.appendChildNode(clone, assignedNode, copyStyles);
              });
            }
          } else {
            this.appendChildNode(clone, child, copyStyles);
          }
        }
      };
      DocumentCloner2.prototype.cloneNode = function(node, copyStyles) {
        if (isTextNode(node)) {
          return document.createTextNode(node.data);
        }
        if (!node.ownerDocument) {
          return node.cloneNode(false);
        }
        var window2 = node.ownerDocument.defaultView;
        if (window2 && isElementNode(node) && (isHTMLElementNode(node) || isSVGElementNode(node))) {
          var clone = this.createElementClone(node);
          clone.style.transitionProperty = "none";
          var style = window2.getComputedStyle(node);
          var styleBefore = window2.getComputedStyle(node, ":before");
          var styleAfter = window2.getComputedStyle(node, ":after");
          if (this.referenceElement === node && isHTMLElementNode(clone)) {
            this.clonedReferenceElement = clone;
          }
          if (isBodyElement(clone)) {
            createPseudoHideStyles(clone);
          }
          var counters = this.counters.parse(new CSSParsedCounterDeclaration(this.context, style));
          var before = this.resolvePseudoContent(node, clone, styleBefore, PseudoElementType.BEFORE);
          if (isCustomElement(node)) {
            copyStyles = true;
          }
          if (!isVideoElement(node)) {
            this.cloneChildNodes(node, clone, copyStyles);
          }
          if (before) {
            clone.insertBefore(before, clone.firstChild);
          }
          var after = this.resolvePseudoContent(node, clone, styleAfter, PseudoElementType.AFTER);
          if (after) {
            clone.appendChild(after);
          }
          this.counters.pop(counters);
          if (style && (this.options.copyStyles || isSVGElementNode(node)) && !isIFrameElement(node) || copyStyles) {
            copyCSSStyles(style, clone);
          }
          if (node.scrollTop !== 0 || node.scrollLeft !== 0) {
            this.scrolledElements.push([clone, node.scrollLeft, node.scrollTop]);
          }
          if ((isTextareaElement(node) || isSelectElement(node)) && (isTextareaElement(clone) || isSelectElement(clone))) {
            clone.value = node.value;
          }
          return clone;
        }
        return node.cloneNode(false);
      };
      DocumentCloner2.prototype.resolvePseudoContent = function(node, clone, style, pseudoElt) {
        var _this = this;
        if (!style) {
          return;
        }
        var value = style.content;
        var document2 = clone.ownerDocument;
        if (!document2 || !value || value === "none" || value === "-moz-alt-content" || style.display === "none") {
          return;
        }
        this.counters.parse(new CSSParsedCounterDeclaration(this.context, style));
        var declaration = new CSSParsedPseudoDeclaration(this.context, style);
        var anonymousReplacedElement = document2.createElement("html2canvaspseudoelement");
        copyCSSStyles(style, anonymousReplacedElement);
        declaration.content.forEach(function(token) {
          if (token.type === 0) {
            anonymousReplacedElement.appendChild(document2.createTextNode(token.value));
          } else if (token.type === 22) {
            var img = document2.createElement("img");
            img.src = token.value;
            img.style.opacity = "1";
            anonymousReplacedElement.appendChild(img);
          } else if (token.type === 18) {
            if (token.name === "attr") {
              var attr = token.values.filter(isIdentToken);
              if (attr.length) {
                anonymousReplacedElement.appendChild(document2.createTextNode(node.getAttribute(attr[0].value) || ""));
              }
            } else if (token.name === "counter") {
              var _a = token.values.filter(nonFunctionArgSeparator), counter = _a[0], counterStyle = _a[1];
              if (counter && isIdentToken(counter)) {
                var counterState = _this.counters.getCounterValue(counter.value);
                var counterType = counterStyle && isIdentToken(counterStyle) ? listStyleType.parse(_this.context, counterStyle.value) : 3;
                anonymousReplacedElement.appendChild(document2.createTextNode(createCounterText(counterState, counterType, false)));
              }
            } else if (token.name === "counters") {
              var _b = token.values.filter(nonFunctionArgSeparator), counter = _b[0], delim = _b[1], counterStyle = _b[2];
              if (counter && isIdentToken(counter)) {
                var counterStates = _this.counters.getCounterValues(counter.value);
                var counterType_1 = counterStyle && isIdentToken(counterStyle) ? listStyleType.parse(_this.context, counterStyle.value) : 3;
                var separator = delim && delim.type === 0 ? delim.value : "";
                var text = counterStates.map(function(value2) {
                  return createCounterText(value2, counterType_1, false);
                }).join(separator);
                anonymousReplacedElement.appendChild(document2.createTextNode(text));
              }
            } else ;
          } else if (token.type === 20) {
            switch (token.value) {
              case "open-quote":
                anonymousReplacedElement.appendChild(document2.createTextNode(getQuote(declaration.quotes, _this.quoteDepth++, true)));
                break;
              case "close-quote":
                anonymousReplacedElement.appendChild(document2.createTextNode(getQuote(declaration.quotes, --_this.quoteDepth, false)));
                break;
              default:
                anonymousReplacedElement.appendChild(document2.createTextNode(token.value));
            }
          }
        });
        anonymousReplacedElement.className = PSEUDO_HIDE_ELEMENT_CLASS_BEFORE + " " + PSEUDO_HIDE_ELEMENT_CLASS_AFTER;
        var newClassName = pseudoElt === PseudoElementType.BEFORE ? " " + PSEUDO_HIDE_ELEMENT_CLASS_BEFORE : " " + PSEUDO_HIDE_ELEMENT_CLASS_AFTER;
        if (isSVGElementNode(clone)) {
          clone.className.baseValue += newClassName;
        } else {
          clone.className += newClassName;
        }
        return anonymousReplacedElement;
      };
      DocumentCloner2.destroy = function(container) {
        if (container.parentNode) {
          container.parentNode.removeChild(container);
          return true;
        }
        return false;
      };
      return DocumentCloner2;
    })()
  );
  var PseudoElementType;
  (function(PseudoElementType2) {
    PseudoElementType2[PseudoElementType2["BEFORE"] = 0] = "BEFORE";
    PseudoElementType2[PseudoElementType2["AFTER"] = 1] = "AFTER";
  })(PseudoElementType || (PseudoElementType = {}));
  var createIFrameContainer = function(ownerDocument, bounds) {
    var cloneIframeContainer = ownerDocument.createElement("iframe");
    cloneIframeContainer.className = "html2canvas-container";
    cloneIframeContainer.style.visibility = "hidden";
    cloneIframeContainer.style.position = "fixed";
    cloneIframeContainer.style.left = "-10000px";
    cloneIframeContainer.style.top = "0px";
    cloneIframeContainer.style.border = "0";
    cloneIframeContainer.width = bounds.width.toString();
    cloneIframeContainer.height = bounds.height.toString();
    cloneIframeContainer.scrolling = "no";
    cloneIframeContainer.setAttribute(IGNORE_ATTRIBUTE, "true");
    ownerDocument.body.appendChild(cloneIframeContainer);
    return cloneIframeContainer;
  };
  var imageReady = function(img) {
    return new Promise(function(resolve) {
      if (img.complete) {
        resolve();
        return;
      }
      if (!img.src) {
        resolve();
        return;
      }
      img.onload = resolve;
      img.onerror = resolve;
    });
  };
  var imagesReady = function(document2) {
    return Promise.all([].slice.call(document2.images, 0).map(imageReady));
  };
  var iframeLoader = function(iframe) {
    return new Promise(function(resolve, reject) {
      var cloneWindow = iframe.contentWindow;
      if (!cloneWindow) {
        return reject("No window assigned for iframe");
      }
      var documentClone = cloneWindow.document;
      cloneWindow.onload = iframe.onload = function() {
        cloneWindow.onload = iframe.onload = null;
        var interval = setInterval(function() {
          if (documentClone.body.childNodes.length > 0 && documentClone.readyState === "complete") {
            clearInterval(interval);
            resolve(iframe);
          }
        }, 50);
      };
    });
  };
  var ignoredStyleProperties = [
    "all",
    "d",
    "content"
    // Safari shows pseudoelements if content is set
  ];
  var copyCSSStyles = function(style, target) {
    for (var i = style.length - 1; i >= 0; i--) {
      var property = style.item(i);
      if (ignoredStyleProperties.indexOf(property) === -1) {
        target.style.setProperty(property, style.getPropertyValue(property));
      }
    }
    return target;
  };
  var serializeDoctype = function(doctype) {
    var str = "";
    if (doctype) {
      str += "<!DOCTYPE ";
      if (doctype.name) {
        str += doctype.name;
      }
      if (doctype.internalSubset) {
        str += doctype.internalSubset;
      }
      if (doctype.publicId) {
        str += '"' + doctype.publicId + '"';
      }
      if (doctype.systemId) {
        str += '"' + doctype.systemId + '"';
      }
      str += ">";
    }
    return str;
  };
  var restoreOwnerScroll = function(ownerDocument, x, y) {
    if (ownerDocument && ownerDocument.defaultView && (x !== ownerDocument.defaultView.pageXOffset || y !== ownerDocument.defaultView.pageYOffset)) {
      ownerDocument.defaultView.scrollTo(x, y);
    }
  };
  var restoreNodeScroll = function(_a) {
    var element = _a[0], x = _a[1], y = _a[2];
    element.scrollLeft = x;
    element.scrollTop = y;
  };
  var PSEUDO_BEFORE = ":before";
  var PSEUDO_AFTER = ":after";
  var PSEUDO_HIDE_ELEMENT_CLASS_BEFORE = "___html2canvas___pseudoelement_before";
  var PSEUDO_HIDE_ELEMENT_CLASS_AFTER = "___html2canvas___pseudoelement_after";
  var PSEUDO_HIDE_ELEMENT_STYLE = '{\n    content: "" !important;\n    display: none !important;\n}';
  var createPseudoHideStyles = function(body) {
    createStyles(body, "." + PSEUDO_HIDE_ELEMENT_CLASS_BEFORE + PSEUDO_BEFORE + PSEUDO_HIDE_ELEMENT_STYLE + "\n         ." + PSEUDO_HIDE_ELEMENT_CLASS_AFTER + PSEUDO_AFTER + PSEUDO_HIDE_ELEMENT_STYLE);
  };
  var createStyles = function(body, styles) {
    var document2 = body.ownerDocument;
    if (document2) {
      var style = document2.createElement("style");
      style.textContent = styles;
      body.appendChild(style);
    }
  };
  var CacheStorage = (
    /** @class */
    (function() {
      function CacheStorage2() {
      }
      CacheStorage2.getOrigin = function(url) {
        var link = CacheStorage2._link;
        if (!link) {
          return "about:blank";
        }
        link.href = url;
        link.href = link.href;
        return link.protocol + link.hostname + link.port;
      };
      CacheStorage2.isSameOrigin = function(src) {
        return CacheStorage2.getOrigin(src) === CacheStorage2._origin;
      };
      CacheStorage2.setContext = function(window2) {
        CacheStorage2._link = window2.document.createElement("a");
        CacheStorage2._origin = CacheStorage2.getOrigin(window2.location.href);
      };
      CacheStorage2._origin = "about:blank";
      return CacheStorage2;
    })()
  );
  var Cache = (
    /** @class */
    (function() {
      function Cache2(context, _options) {
        this.context = context;
        this._options = _options;
        this._cache = {};
      }
      Cache2.prototype.addImage = function(src) {
        var result = Promise.resolve();
        if (this.has(src)) {
          return result;
        }
        if (isBlobImage(src) || isRenderable(src)) {
          (this._cache[src] = this.loadImage(src)).catch(function() {
          });
          return result;
        }
        return result;
      };
      Cache2.prototype.match = function(src) {
        return this._cache[src];
      };
      Cache2.prototype.loadImage = function(key) {
        return __awaiter(this, void 0, void 0, function() {
          var isSameOrigin, useCORS, useProxy, src;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                isSameOrigin = CacheStorage.isSameOrigin(key);
                useCORS = !isInlineImage(key) && this._options.useCORS === true && FEATURES.SUPPORT_CORS_IMAGES && !isSameOrigin;
                useProxy = !isInlineImage(key) && !isSameOrigin && !isBlobImage(key) && typeof this._options.proxy === "string" && FEATURES.SUPPORT_CORS_XHR && !useCORS;
                if (!isSameOrigin && this._options.allowTaint === false && !isInlineImage(key) && !isBlobImage(key) && !useProxy && !useCORS) {
                  return [
                    2
                    /*return*/
                  ];
                }
                src = key;
                if (!useProxy) return [3, 2];
                return [4, this.proxy(src)];
              case 1:
                src = _a.sent();
                _a.label = 2;
              case 2:
                this.context.logger.debug("Added image " + key.substring(0, 256));
                return [4, new Promise(function(resolve, reject) {
                  var img = new Image();
                  img.onload = function() {
                    return resolve(img);
                  };
                  img.onerror = reject;
                  if (isInlineBase64Image(src) || useCORS) {
                    img.crossOrigin = "anonymous";
                  }
                  img.src = src;
                  if (img.complete === true) {
                    setTimeout(function() {
                      return resolve(img);
                    }, 500);
                  }
                  if (_this._options.imageTimeout > 0) {
                    setTimeout(function() {
                      return reject("Timed out (" + _this._options.imageTimeout + "ms) loading image");
                    }, _this._options.imageTimeout);
                  }
                })];
              case 3:
                return [2, _a.sent()];
            }
          });
        });
      };
      Cache2.prototype.has = function(key) {
        return typeof this._cache[key] !== "undefined";
      };
      Cache2.prototype.keys = function() {
        return Promise.resolve(Object.keys(this._cache));
      };
      Cache2.prototype.proxy = function(src) {
        var _this = this;
        var proxy = this._options.proxy;
        if (!proxy) {
          throw new Error("No proxy defined");
        }
        var key = src.substring(0, 256);
        return new Promise(function(resolve, reject) {
          var responseType = FEATURES.SUPPORT_RESPONSE_TYPE ? "blob" : "text";
          var xhr = new XMLHttpRequest();
          xhr.onload = function() {
            if (xhr.status === 200) {
              if (responseType === "text") {
                resolve(xhr.response);
              } else {
                var reader_1 = new FileReader();
                reader_1.addEventListener("load", function() {
                  return resolve(reader_1.result);
                }, false);
                reader_1.addEventListener("error", function(e2) {
                  return reject(e2);
                }, false);
                reader_1.readAsDataURL(xhr.response);
              }
            } else {
              reject("Failed to proxy resource " + key + " with status code " + xhr.status);
            }
          };
          xhr.onerror = reject;
          var queryString = proxy.indexOf("?") > -1 ? "&" : "?";
          xhr.open("GET", "" + proxy + queryString + "url=" + encodeURIComponent(src) + "&responseType=" + responseType);
          if (responseType !== "text" && xhr instanceof XMLHttpRequest) {
            xhr.responseType = responseType;
          }
          if (_this._options.imageTimeout) {
            var timeout_1 = _this._options.imageTimeout;
            xhr.timeout = timeout_1;
            xhr.ontimeout = function() {
              return reject("Timed out (" + timeout_1 + "ms) proxying " + key);
            };
          }
          xhr.send();
        });
      };
      return Cache2;
    })()
  );
  var INLINE_SVG = /^data:image\/svg\+xml/i;
  var INLINE_BASE64 = /^data:image\/.*;base64,/i;
  var INLINE_IMG = /^data:image\/.*/i;
  var isRenderable = function(src) {
    return FEATURES.SUPPORT_SVG_DRAWING || !isSVG(src);
  };
  var isInlineImage = function(src) {
    return INLINE_IMG.test(src);
  };
  var isInlineBase64Image = function(src) {
    return INLINE_BASE64.test(src);
  };
  var isBlobImage = function(src) {
    return src.substr(0, 4) === "blob";
  };
  var isSVG = function(src) {
    return src.substr(-3).toLowerCase() === "svg" || INLINE_SVG.test(src);
  };
  var Vector = (
    /** @class */
    (function() {
      function Vector2(x, y) {
        this.type = 0;
        this.x = x;
        this.y = y;
      }
      Vector2.prototype.add = function(deltaX, deltaY) {
        return new Vector2(this.x + deltaX, this.y + deltaY);
      };
      return Vector2;
    })()
  );
  var lerp = function(a2, b, t) {
    return new Vector(a2.x + (b.x - a2.x) * t, a2.y + (b.y - a2.y) * t);
  };
  var BezierCurve = (
    /** @class */
    (function() {
      function BezierCurve2(start, startControl, endControl, end) {
        this.type = 1;
        this.start = start;
        this.startControl = startControl;
        this.endControl = endControl;
        this.end = end;
      }
      BezierCurve2.prototype.subdivide = function(t, firstHalf) {
        var ab = lerp(this.start, this.startControl, t);
        var bc = lerp(this.startControl, this.endControl, t);
        var cd = lerp(this.endControl, this.end, t);
        var abbc = lerp(ab, bc, t);
        var bccd = lerp(bc, cd, t);
        var dest = lerp(abbc, bccd, t);
        return firstHalf ? new BezierCurve2(this.start, ab, abbc, dest) : new BezierCurve2(dest, bccd, cd, this.end);
      };
      BezierCurve2.prototype.add = function(deltaX, deltaY) {
        return new BezierCurve2(this.start.add(deltaX, deltaY), this.startControl.add(deltaX, deltaY), this.endControl.add(deltaX, deltaY), this.end.add(deltaX, deltaY));
      };
      BezierCurve2.prototype.reverse = function() {
        return new BezierCurve2(this.end, this.endControl, this.startControl, this.start);
      };
      return BezierCurve2;
    })()
  );
  var isBezierCurve = function(path) {
    return path.type === 1;
  };
  var BoundCurves = (
    /** @class */
    /* @__PURE__ */ (function() {
      function BoundCurves2(element) {
        var styles = element.styles;
        var bounds = element.bounds;
        var _a = getAbsoluteValueForTuple(styles.borderTopLeftRadius, bounds.width, bounds.height), tlh = _a[0], tlv = _a[1];
        var _b = getAbsoluteValueForTuple(styles.borderTopRightRadius, bounds.width, bounds.height), trh = _b[0], trv = _b[1];
        var _c = getAbsoluteValueForTuple(styles.borderBottomRightRadius, bounds.width, bounds.height), brh = _c[0], brv = _c[1];
        var _d = getAbsoluteValueForTuple(styles.borderBottomLeftRadius, bounds.width, bounds.height), blh = _d[0], blv = _d[1];
        var factors = [];
        factors.push((tlh + trh) / bounds.width);
        factors.push((blh + brh) / bounds.width);
        factors.push((tlv + blv) / bounds.height);
        factors.push((trv + brv) / bounds.height);
        var maxFactor = Math.max.apply(Math, factors);
        if (maxFactor > 1) {
          tlh /= maxFactor;
          tlv /= maxFactor;
          trh /= maxFactor;
          trv /= maxFactor;
          brh /= maxFactor;
          brv /= maxFactor;
          blh /= maxFactor;
          blv /= maxFactor;
        }
        var topWidth = bounds.width - trh;
        var rightHeight = bounds.height - brv;
        var bottomWidth = bounds.width - brh;
        var leftHeight = bounds.height - blv;
        var borderTopWidth2 = styles.borderTopWidth;
        var borderRightWidth2 = styles.borderRightWidth;
        var borderBottomWidth2 = styles.borderBottomWidth;
        var borderLeftWidth2 = styles.borderLeftWidth;
        var paddingTop2 = getAbsoluteValue(styles.paddingTop, element.bounds.width);
        var paddingRight2 = getAbsoluteValue(styles.paddingRight, element.bounds.width);
        var paddingBottom2 = getAbsoluteValue(styles.paddingBottom, element.bounds.width);
        var paddingLeft2 = getAbsoluteValue(styles.paddingLeft, element.bounds.width);
        this.topLeftBorderDoubleOuterBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2 / 3, bounds.top + borderTopWidth2 / 3, tlh - borderLeftWidth2 / 3, tlv - borderTopWidth2 / 3, CORNER.TOP_LEFT) : new Vector(bounds.left + borderLeftWidth2 / 3, bounds.top + borderTopWidth2 / 3);
        this.topRightBorderDoubleOuterBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + topWidth, bounds.top + borderTopWidth2 / 3, trh - borderRightWidth2 / 3, trv - borderTopWidth2 / 3, CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth2 / 3, bounds.top + borderTopWidth2 / 3);
        this.bottomRightBorderDoubleOuterBox = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh - borderRightWidth2 / 3, brv - borderBottomWidth2 / 3, CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth2 / 3, bounds.top + bounds.height - borderBottomWidth2 / 3);
        this.bottomLeftBorderDoubleOuterBox = blh > 0 || blv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2 / 3, bounds.top + leftHeight, blh - borderLeftWidth2 / 3, blv - borderBottomWidth2 / 3, CORNER.BOTTOM_LEFT) : new Vector(bounds.left + borderLeftWidth2 / 3, bounds.top + bounds.height - borderBottomWidth2 / 3);
        this.topLeftBorderDoubleInnerBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2 * 2 / 3, bounds.top + borderTopWidth2 * 2 / 3, tlh - borderLeftWidth2 * 2 / 3, tlv - borderTopWidth2 * 2 / 3, CORNER.TOP_LEFT) : new Vector(bounds.left + borderLeftWidth2 * 2 / 3, bounds.top + borderTopWidth2 * 2 / 3);
        this.topRightBorderDoubleInnerBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + topWidth, bounds.top + borderTopWidth2 * 2 / 3, trh - borderRightWidth2 * 2 / 3, trv - borderTopWidth2 * 2 / 3, CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth2 * 2 / 3, bounds.top + borderTopWidth2 * 2 / 3);
        this.bottomRightBorderDoubleInnerBox = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh - borderRightWidth2 * 2 / 3, brv - borderBottomWidth2 * 2 / 3, CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth2 * 2 / 3, bounds.top + bounds.height - borderBottomWidth2 * 2 / 3);
        this.bottomLeftBorderDoubleInnerBox = blh > 0 || blv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2 * 2 / 3, bounds.top + leftHeight, blh - borderLeftWidth2 * 2 / 3, blv - borderBottomWidth2 * 2 / 3, CORNER.BOTTOM_LEFT) : new Vector(bounds.left + borderLeftWidth2 * 2 / 3, bounds.top + bounds.height - borderBottomWidth2 * 2 / 3);
        this.topLeftBorderStroke = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2 / 2, bounds.top + borderTopWidth2 / 2, tlh - borderLeftWidth2 / 2, tlv - borderTopWidth2 / 2, CORNER.TOP_LEFT) : new Vector(bounds.left + borderLeftWidth2 / 2, bounds.top + borderTopWidth2 / 2);
        this.topRightBorderStroke = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + topWidth, bounds.top + borderTopWidth2 / 2, trh - borderRightWidth2 / 2, trv - borderTopWidth2 / 2, CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth2 / 2, bounds.top + borderTopWidth2 / 2);
        this.bottomRightBorderStroke = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh - borderRightWidth2 / 2, brv - borderBottomWidth2 / 2, CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth2 / 2, bounds.top + bounds.height - borderBottomWidth2 / 2);
        this.bottomLeftBorderStroke = blh > 0 || blv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2 / 2, bounds.top + leftHeight, blh - borderLeftWidth2 / 2, blv - borderBottomWidth2 / 2, CORNER.BOTTOM_LEFT) : new Vector(bounds.left + borderLeftWidth2 / 2, bounds.top + bounds.height - borderBottomWidth2 / 2);
        this.topLeftBorderBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left, bounds.top, tlh, tlv, CORNER.TOP_LEFT) : new Vector(bounds.left, bounds.top);
        this.topRightBorderBox = trh > 0 || trv > 0 ? getCurvePoints(bounds.left + topWidth, bounds.top, trh, trv, CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width, bounds.top);
        this.bottomRightBorderBox = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh, brv, CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width, bounds.top + bounds.height);
        this.bottomLeftBorderBox = blh > 0 || blv > 0 ? getCurvePoints(bounds.left, bounds.top + leftHeight, blh, blv, CORNER.BOTTOM_LEFT) : new Vector(bounds.left, bounds.top + bounds.height);
        this.topLeftPaddingBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2, bounds.top + borderTopWidth2, Math.max(0, tlh - borderLeftWidth2), Math.max(0, tlv - borderTopWidth2), CORNER.TOP_LEFT) : new Vector(bounds.left + borderLeftWidth2, bounds.top + borderTopWidth2);
        this.topRightPaddingBox = trh > 0 || trv > 0 ? getCurvePoints(bounds.left + Math.min(topWidth, bounds.width - borderRightWidth2), bounds.top + borderTopWidth2, topWidth > bounds.width + borderRightWidth2 ? 0 : Math.max(0, trh - borderRightWidth2), Math.max(0, trv - borderTopWidth2), CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth2, bounds.top + borderTopWidth2);
        this.bottomRightPaddingBox = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + Math.min(bottomWidth, bounds.width - borderLeftWidth2), bounds.top + Math.min(rightHeight, bounds.height - borderBottomWidth2), Math.max(0, brh - borderRightWidth2), Math.max(0, brv - borderBottomWidth2), CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth2, bounds.top + bounds.height - borderBottomWidth2);
        this.bottomLeftPaddingBox = blh > 0 || blv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2, bounds.top + Math.min(leftHeight, bounds.height - borderBottomWidth2), Math.max(0, blh - borderLeftWidth2), Math.max(0, blv - borderBottomWidth2), CORNER.BOTTOM_LEFT) : new Vector(bounds.left + borderLeftWidth2, bounds.top + bounds.height - borderBottomWidth2);
        this.topLeftContentBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2 + paddingLeft2, bounds.top + borderTopWidth2 + paddingTop2, Math.max(0, tlh - (borderLeftWidth2 + paddingLeft2)), Math.max(0, tlv - (borderTopWidth2 + paddingTop2)), CORNER.TOP_LEFT) : new Vector(bounds.left + borderLeftWidth2 + paddingLeft2, bounds.top + borderTopWidth2 + paddingTop2);
        this.topRightContentBox = trh > 0 || trv > 0 ? getCurvePoints(bounds.left + Math.min(topWidth, bounds.width + borderLeftWidth2 + paddingLeft2), bounds.top + borderTopWidth2 + paddingTop2, topWidth > bounds.width + borderLeftWidth2 + paddingLeft2 ? 0 : trh - borderLeftWidth2 + paddingLeft2, trv - (borderTopWidth2 + paddingTop2), CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width - (borderRightWidth2 + paddingRight2), bounds.top + borderTopWidth2 + paddingTop2);
        this.bottomRightContentBox = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + Math.min(bottomWidth, bounds.width - (borderLeftWidth2 + paddingLeft2)), bounds.top + Math.min(rightHeight, bounds.height + borderTopWidth2 + paddingTop2), Math.max(0, brh - (borderRightWidth2 + paddingRight2)), brv - (borderBottomWidth2 + paddingBottom2), CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width - (borderRightWidth2 + paddingRight2), bounds.top + bounds.height - (borderBottomWidth2 + paddingBottom2));
        this.bottomLeftContentBox = blh > 0 || blv > 0 ? getCurvePoints(bounds.left + borderLeftWidth2 + paddingLeft2, bounds.top + leftHeight, Math.max(0, blh - (borderLeftWidth2 + paddingLeft2)), blv - (borderBottomWidth2 + paddingBottom2), CORNER.BOTTOM_LEFT) : new Vector(bounds.left + borderLeftWidth2 + paddingLeft2, bounds.top + bounds.height - (borderBottomWidth2 + paddingBottom2));
      }
      return BoundCurves2;
    })()
  );
  var CORNER;
  (function(CORNER2) {
    CORNER2[CORNER2["TOP_LEFT"] = 0] = "TOP_LEFT";
    CORNER2[CORNER2["TOP_RIGHT"] = 1] = "TOP_RIGHT";
    CORNER2[CORNER2["BOTTOM_RIGHT"] = 2] = "BOTTOM_RIGHT";
    CORNER2[CORNER2["BOTTOM_LEFT"] = 3] = "BOTTOM_LEFT";
  })(CORNER || (CORNER = {}));
  var getCurvePoints = function(x, y, r1, r2, position2) {
    var kappa = 4 * ((Math.sqrt(2) - 1) / 3);
    var ox = r1 * kappa;
    var oy = r2 * kappa;
    var xm = x + r1;
    var ym = y + r2;
    switch (position2) {
      case CORNER.TOP_LEFT:
        return new BezierCurve(new Vector(x, ym), new Vector(x, ym - oy), new Vector(xm - ox, y), new Vector(xm, y));
      case CORNER.TOP_RIGHT:
        return new BezierCurve(new Vector(x, y), new Vector(x + ox, y), new Vector(xm, ym - oy), new Vector(xm, ym));
      case CORNER.BOTTOM_RIGHT:
        return new BezierCurve(new Vector(xm, y), new Vector(xm, y + oy), new Vector(x + ox, ym), new Vector(x, ym));
      case CORNER.BOTTOM_LEFT:
      default:
        return new BezierCurve(new Vector(xm, ym), new Vector(xm - ox, ym), new Vector(x, y + oy), new Vector(x, y));
    }
  };
  var calculateBorderBoxPath = function(curves) {
    return [curves.topLeftBorderBox, curves.topRightBorderBox, curves.bottomRightBorderBox, curves.bottomLeftBorderBox];
  };
  var calculateContentBoxPath = function(curves) {
    return [
      curves.topLeftContentBox,
      curves.topRightContentBox,
      curves.bottomRightContentBox,
      curves.bottomLeftContentBox
    ];
  };
  var calculatePaddingBoxPath = function(curves) {
    return [
      curves.topLeftPaddingBox,
      curves.topRightPaddingBox,
      curves.bottomRightPaddingBox,
      curves.bottomLeftPaddingBox
    ];
  };
  var TransformEffect = (
    /** @class */
    /* @__PURE__ */ (function() {
      function TransformEffect2(offsetX, offsetY, matrix2) {
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.matrix = matrix2;
        this.type = 0;
        this.target = 2 | 4;
      }
      return TransformEffect2;
    })()
  );
  var ClipEffect = (
    /** @class */
    /* @__PURE__ */ (function() {
      function ClipEffect2(path, target) {
        this.path = path;
        this.target = target;
        this.type = 1;
      }
      return ClipEffect2;
    })()
  );
  var OpacityEffect = (
    /** @class */
    /* @__PURE__ */ (function() {
      function OpacityEffect2(opacity2) {
        this.opacity = opacity2;
        this.type = 2;
        this.target = 2 | 4;
      }
      return OpacityEffect2;
    })()
  );
  var isTransformEffect = function(effect) {
    return effect.type === 0;
  };
  var isClipEffect = function(effect) {
    return effect.type === 1;
  };
  var isOpacityEffect = function(effect) {
    return effect.type === 2;
  };
  var equalPath = function(a2, b) {
    if (a2.length === b.length) {
      return a2.some(function(v, i) {
        return v === b[i];
      });
    }
    return false;
  };
  var transformPath = function(path, deltaX, deltaY, deltaW, deltaH) {
    return path.map(function(point, index) {
      switch (index) {
        case 0:
          return point.add(deltaX, deltaY);
        case 1:
          return point.add(deltaX + deltaW, deltaY);
        case 2:
          return point.add(deltaX + deltaW, deltaY + deltaH);
        case 3:
          return point.add(deltaX, deltaY + deltaH);
      }
      return point;
    });
  };
  var StackingContext = (
    /** @class */
    /* @__PURE__ */ (function() {
      function StackingContext2(container) {
        this.element = container;
        this.inlineLevel = [];
        this.nonInlineLevel = [];
        this.negativeZIndex = [];
        this.zeroOrAutoZIndexOrTransformedOrOpacity = [];
        this.positiveZIndex = [];
        this.nonPositionedFloats = [];
        this.nonPositionedInlineLevel = [];
      }
      return StackingContext2;
    })()
  );
  var ElementPaint = (
    /** @class */
    (function() {
      function ElementPaint2(container, parent) {
        this.container = container;
        this.parent = parent;
        this.effects = [];
        this.curves = new BoundCurves(this.container);
        if (this.container.styles.opacity < 1) {
          this.effects.push(new OpacityEffect(this.container.styles.opacity));
        }
        if (this.container.styles.transform !== null) {
          var offsetX = this.container.bounds.left + this.container.styles.transformOrigin[0].number;
          var offsetY = this.container.bounds.top + this.container.styles.transformOrigin[1].number;
          var matrix2 = this.container.styles.transform;
          this.effects.push(new TransformEffect(offsetX, offsetY, matrix2));
        }
        if (this.container.styles.overflowX !== 0) {
          var borderBox = calculateBorderBoxPath(this.curves);
          var paddingBox2 = calculatePaddingBoxPath(this.curves);
          if (equalPath(borderBox, paddingBox2)) {
            this.effects.push(new ClipEffect(
              borderBox,
              2 | 4
              /* CONTENT */
            ));
          } else {
            this.effects.push(new ClipEffect(
              borderBox,
              2
              /* BACKGROUND_BORDERS */
            ));
            this.effects.push(new ClipEffect(
              paddingBox2,
              4
              /* CONTENT */
            ));
          }
        }
      }
      ElementPaint2.prototype.getEffects = function(target) {
        var inFlow = [
          2,
          3
          /* FIXED */
        ].indexOf(this.container.styles.position) === -1;
        var parent = this.parent;
        var effects = this.effects.slice(0);
        while (parent) {
          var croplessEffects = parent.effects.filter(function(effect) {
            return !isClipEffect(effect);
          });
          if (inFlow || parent.container.styles.position !== 0 || !parent.parent) {
            effects.unshift.apply(effects, croplessEffects);
            inFlow = [
              2,
              3
              /* FIXED */
            ].indexOf(parent.container.styles.position) === -1;
            if (parent.container.styles.overflowX !== 0) {
              var borderBox = calculateBorderBoxPath(parent.curves);
              var paddingBox2 = calculatePaddingBoxPath(parent.curves);
              if (!equalPath(borderBox, paddingBox2)) {
                effects.unshift(new ClipEffect(
                  paddingBox2,
                  2 | 4
                  /* CONTENT */
                ));
              }
            }
          } else {
            effects.unshift.apply(effects, croplessEffects);
          }
          parent = parent.parent;
        }
        return effects.filter(function(effect) {
          return contains(effect.target, target);
        });
      };
      return ElementPaint2;
    })()
  );
  var parseStackTree = function(parent, stackingContext, realStackingContext, listItems) {
    parent.container.elements.forEach(function(child) {
      var treatAsRealStackingContext = contains(
        child.flags,
        4
        /* CREATES_REAL_STACKING_CONTEXT */
      );
      var createsStackingContext2 = contains(
        child.flags,
        2
        /* CREATES_STACKING_CONTEXT */
      );
      var paintContainer = new ElementPaint(child, parent);
      if (contains(
        child.styles.display,
        2048
        /* LIST_ITEM */
      )) {
        listItems.push(paintContainer);
      }
      var listOwnerItems = contains(
        child.flags,
        8
        /* IS_LIST_OWNER */
      ) ? [] : listItems;
      if (treatAsRealStackingContext || createsStackingContext2) {
        var parentStack = treatAsRealStackingContext || child.styles.isPositioned() ? realStackingContext : stackingContext;
        var stack = new StackingContext(paintContainer);
        if (child.styles.isPositioned() || child.styles.opacity < 1 || child.styles.isTransformed()) {
          var order_1 = child.styles.zIndex.order;
          if (order_1 < 0) {
            var index_1 = 0;
            parentStack.negativeZIndex.some(function(current, i) {
              if (order_1 > current.element.container.styles.zIndex.order) {
                index_1 = i;
                return false;
              } else if (index_1 > 0) {
                return true;
              }
              return false;
            });
            parentStack.negativeZIndex.splice(index_1, 0, stack);
          } else if (order_1 > 0) {
            var index_2 = 0;
            parentStack.positiveZIndex.some(function(current, i) {
              if (order_1 >= current.element.container.styles.zIndex.order) {
                index_2 = i + 1;
                return false;
              } else if (index_2 > 0) {
                return true;
              }
              return false;
            });
            parentStack.positiveZIndex.splice(index_2, 0, stack);
          } else {
            parentStack.zeroOrAutoZIndexOrTransformedOrOpacity.push(stack);
          }
        } else {
          if (child.styles.isFloating()) {
            parentStack.nonPositionedFloats.push(stack);
          } else {
            parentStack.nonPositionedInlineLevel.push(stack);
          }
        }
        parseStackTree(paintContainer, stack, treatAsRealStackingContext ? stack : realStackingContext, listOwnerItems);
      } else {
        if (child.styles.isInlineLevel()) {
          stackingContext.inlineLevel.push(paintContainer);
        } else {
          stackingContext.nonInlineLevel.push(paintContainer);
        }
        parseStackTree(paintContainer, stackingContext, realStackingContext, listOwnerItems);
      }
      if (contains(
        child.flags,
        8
        /* IS_LIST_OWNER */
      )) {
        processListItems(child, listOwnerItems);
      }
    });
  };
  var processListItems = function(owner, elements) {
    var numbering = owner instanceof OLElementContainer ? owner.start : 1;
    var reversed = owner instanceof OLElementContainer ? owner.reversed : false;
    for (var i = 0; i < elements.length; i++) {
      var item = elements[i];
      if (item.container instanceof LIElementContainer && typeof item.container.value === "number" && item.container.value !== 0) {
        numbering = item.container.value;
      }
      item.listValue = createCounterText(numbering, item.container.styles.listStyleType, true);
      numbering += reversed ? -1 : 1;
    }
  };
  var parseStackingContexts = function(container) {
    var paintContainer = new ElementPaint(container, null);
    var root = new StackingContext(paintContainer);
    var listItems = [];
    parseStackTree(paintContainer, root, root, listItems);
    processListItems(paintContainer.container, listItems);
    return root;
  };
  var parsePathForBorder = function(curves, borderSide) {
    switch (borderSide) {
      case 0:
        return createPathFromCurves(curves.topLeftBorderBox, curves.topLeftPaddingBox, curves.topRightBorderBox, curves.topRightPaddingBox);
      case 1:
        return createPathFromCurves(curves.topRightBorderBox, curves.topRightPaddingBox, curves.bottomRightBorderBox, curves.bottomRightPaddingBox);
      case 2:
        return createPathFromCurves(curves.bottomRightBorderBox, curves.bottomRightPaddingBox, curves.bottomLeftBorderBox, curves.bottomLeftPaddingBox);
      case 3:
      default:
        return createPathFromCurves(curves.bottomLeftBorderBox, curves.bottomLeftPaddingBox, curves.topLeftBorderBox, curves.topLeftPaddingBox);
    }
  };
  var parsePathForBorderDoubleOuter = function(curves, borderSide) {
    switch (borderSide) {
      case 0:
        return createPathFromCurves(curves.topLeftBorderBox, curves.topLeftBorderDoubleOuterBox, curves.topRightBorderBox, curves.topRightBorderDoubleOuterBox);
      case 1:
        return createPathFromCurves(curves.topRightBorderBox, curves.topRightBorderDoubleOuterBox, curves.bottomRightBorderBox, curves.bottomRightBorderDoubleOuterBox);
      case 2:
        return createPathFromCurves(curves.bottomRightBorderBox, curves.bottomRightBorderDoubleOuterBox, curves.bottomLeftBorderBox, curves.bottomLeftBorderDoubleOuterBox);
      case 3:
      default:
        return createPathFromCurves(curves.bottomLeftBorderBox, curves.bottomLeftBorderDoubleOuterBox, curves.topLeftBorderBox, curves.topLeftBorderDoubleOuterBox);
    }
  };
  var parsePathForBorderDoubleInner = function(curves, borderSide) {
    switch (borderSide) {
      case 0:
        return createPathFromCurves(curves.topLeftBorderDoubleInnerBox, curves.topLeftPaddingBox, curves.topRightBorderDoubleInnerBox, curves.topRightPaddingBox);
      case 1:
        return createPathFromCurves(curves.topRightBorderDoubleInnerBox, curves.topRightPaddingBox, curves.bottomRightBorderDoubleInnerBox, curves.bottomRightPaddingBox);
      case 2:
        return createPathFromCurves(curves.bottomRightBorderDoubleInnerBox, curves.bottomRightPaddingBox, curves.bottomLeftBorderDoubleInnerBox, curves.bottomLeftPaddingBox);
      case 3:
      default:
        return createPathFromCurves(curves.bottomLeftBorderDoubleInnerBox, curves.bottomLeftPaddingBox, curves.topLeftBorderDoubleInnerBox, curves.topLeftPaddingBox);
    }
  };
  var parsePathForBorderStroke = function(curves, borderSide) {
    switch (borderSide) {
      case 0:
        return createStrokePathFromCurves(curves.topLeftBorderStroke, curves.topRightBorderStroke);
      case 1:
        return createStrokePathFromCurves(curves.topRightBorderStroke, curves.bottomRightBorderStroke);
      case 2:
        return createStrokePathFromCurves(curves.bottomRightBorderStroke, curves.bottomLeftBorderStroke);
      case 3:
      default:
        return createStrokePathFromCurves(curves.bottomLeftBorderStroke, curves.topLeftBorderStroke);
    }
  };
  var createStrokePathFromCurves = function(outer1, outer2) {
    var path = [];
    if (isBezierCurve(outer1)) {
      path.push(outer1.subdivide(0.5, false));
    } else {
      path.push(outer1);
    }
    if (isBezierCurve(outer2)) {
      path.push(outer2.subdivide(0.5, true));
    } else {
      path.push(outer2);
    }
    return path;
  };
  var createPathFromCurves = function(outer1, inner1, outer2, inner2) {
    var path = [];
    if (isBezierCurve(outer1)) {
      path.push(outer1.subdivide(0.5, false));
    } else {
      path.push(outer1);
    }
    if (isBezierCurve(outer2)) {
      path.push(outer2.subdivide(0.5, true));
    } else {
      path.push(outer2);
    }
    if (isBezierCurve(inner2)) {
      path.push(inner2.subdivide(0.5, true).reverse());
    } else {
      path.push(inner2);
    }
    if (isBezierCurve(inner1)) {
      path.push(inner1.subdivide(0.5, false).reverse());
    } else {
      path.push(inner1);
    }
    return path;
  };
  var paddingBox = function(element) {
    var bounds = element.bounds;
    var styles = element.styles;
    return bounds.add(styles.borderLeftWidth, styles.borderTopWidth, -(styles.borderRightWidth + styles.borderLeftWidth), -(styles.borderTopWidth + styles.borderBottomWidth));
  };
  var contentBox = function(element) {
    var styles = element.styles;
    var bounds = element.bounds;
    var paddingLeft2 = getAbsoluteValue(styles.paddingLeft, bounds.width);
    var paddingRight2 = getAbsoluteValue(styles.paddingRight, bounds.width);
    var paddingTop2 = getAbsoluteValue(styles.paddingTop, bounds.width);
    var paddingBottom2 = getAbsoluteValue(styles.paddingBottom, bounds.width);
    return bounds.add(paddingLeft2 + styles.borderLeftWidth, paddingTop2 + styles.borderTopWidth, -(styles.borderRightWidth + styles.borderLeftWidth + paddingLeft2 + paddingRight2), -(styles.borderTopWidth + styles.borderBottomWidth + paddingTop2 + paddingBottom2));
  };
  var calculateBackgroundPositioningArea = function(backgroundOrigin2, element) {
    if (backgroundOrigin2 === 0) {
      return element.bounds;
    }
    if (backgroundOrigin2 === 2) {
      return contentBox(element);
    }
    return paddingBox(element);
  };
  var calculateBackgroundPaintingArea = function(backgroundClip2, element) {
    if (backgroundClip2 === 0) {
      return element.bounds;
    }
    if (backgroundClip2 === 2) {
      return contentBox(element);
    }
    return paddingBox(element);
  };
  var calculateBackgroundRendering = function(container, index, intrinsicSize) {
    var backgroundPositioningArea = calculateBackgroundPositioningArea(getBackgroundValueForIndex(container.styles.backgroundOrigin, index), container);
    var backgroundPaintingArea = calculateBackgroundPaintingArea(getBackgroundValueForIndex(container.styles.backgroundClip, index), container);
    var backgroundImageSize = calculateBackgroundSize(getBackgroundValueForIndex(container.styles.backgroundSize, index), intrinsicSize, backgroundPositioningArea);
    var sizeWidth = backgroundImageSize[0], sizeHeight = backgroundImageSize[1];
    var position2 = getAbsoluteValueForTuple(getBackgroundValueForIndex(container.styles.backgroundPosition, index), backgroundPositioningArea.width - sizeWidth, backgroundPositioningArea.height - sizeHeight);
    var path = calculateBackgroundRepeatPath(getBackgroundValueForIndex(container.styles.backgroundRepeat, index), position2, backgroundImageSize, backgroundPositioningArea, backgroundPaintingArea);
    var offsetX = Math.round(backgroundPositioningArea.left + position2[0]);
    var offsetY = Math.round(backgroundPositioningArea.top + position2[1]);
    return [path, offsetX, offsetY, sizeWidth, sizeHeight];
  };
  var isAuto = function(token) {
    return isIdentToken(token) && token.value === BACKGROUND_SIZE.AUTO;
  };
  var hasIntrinsicValue = function(value) {
    return typeof value === "number";
  };
  var calculateBackgroundSize = function(size, _a, bounds) {
    var intrinsicWidth = _a[0], intrinsicHeight = _a[1], intrinsicProportion = _a[2];
    var first = size[0], second = size[1];
    if (!first) {
      return [0, 0];
    }
    if (isLengthPercentage(first) && second && isLengthPercentage(second)) {
      return [getAbsoluteValue(first, bounds.width), getAbsoluteValue(second, bounds.height)];
    }
    var hasIntrinsicProportion = hasIntrinsicValue(intrinsicProportion);
    if (isIdentToken(first) && (first.value === BACKGROUND_SIZE.CONTAIN || first.value === BACKGROUND_SIZE.COVER)) {
      if (hasIntrinsicValue(intrinsicProportion)) {
        var targetRatio = bounds.width / bounds.height;
        return targetRatio < intrinsicProportion !== (first.value === BACKGROUND_SIZE.COVER) ? [bounds.width, bounds.width / intrinsicProportion] : [bounds.height * intrinsicProportion, bounds.height];
      }
      return [bounds.width, bounds.height];
    }
    var hasIntrinsicWidth = hasIntrinsicValue(intrinsicWidth);
    var hasIntrinsicHeight = hasIntrinsicValue(intrinsicHeight);
    var hasIntrinsicDimensions = hasIntrinsicWidth || hasIntrinsicHeight;
    if (isAuto(first) && (!second || isAuto(second))) {
      if (hasIntrinsicWidth && hasIntrinsicHeight) {
        return [intrinsicWidth, intrinsicHeight];
      }
      if (!hasIntrinsicProportion && !hasIntrinsicDimensions) {
        return [bounds.width, bounds.height];
      }
      if (hasIntrinsicDimensions && hasIntrinsicProportion) {
        var width_1 = hasIntrinsicWidth ? intrinsicWidth : intrinsicHeight * intrinsicProportion;
        var height_1 = hasIntrinsicHeight ? intrinsicHeight : intrinsicWidth / intrinsicProportion;
        return [width_1, height_1];
      }
      var width_2 = hasIntrinsicWidth ? intrinsicWidth : bounds.width;
      var height_2 = hasIntrinsicHeight ? intrinsicHeight : bounds.height;
      return [width_2, height_2];
    }
    if (hasIntrinsicProportion) {
      var width_3 = 0;
      var height_3 = 0;
      if (isLengthPercentage(first)) {
        width_3 = getAbsoluteValue(first, bounds.width);
      } else if (isLengthPercentage(second)) {
        height_3 = getAbsoluteValue(second, bounds.height);
      }
      if (isAuto(first)) {
        width_3 = height_3 * intrinsicProportion;
      } else if (!second || isAuto(second)) {
        height_3 = width_3 / intrinsicProportion;
      }
      return [width_3, height_3];
    }
    var width = null;
    var height = null;
    if (isLengthPercentage(first)) {
      width = getAbsoluteValue(first, bounds.width);
    } else if (second && isLengthPercentage(second)) {
      height = getAbsoluteValue(second, bounds.height);
    }
    if (width !== null && (!second || isAuto(second))) {
      height = hasIntrinsicWidth && hasIntrinsicHeight ? width / intrinsicWidth * intrinsicHeight : bounds.height;
    }
    if (height !== null && isAuto(first)) {
      width = hasIntrinsicWidth && hasIntrinsicHeight ? height / intrinsicHeight * intrinsicWidth : bounds.width;
    }
    if (width !== null && height !== null) {
      return [width, height];
    }
    throw new Error("Unable to calculate background-size for element");
  };
  var getBackgroundValueForIndex = function(values, index) {
    var value = values[index];
    if (typeof value === "undefined") {
      return values[0];
    }
    return value;
  };
  var calculateBackgroundRepeatPath = function(repeat, _a, _b, backgroundPositioningArea, backgroundPaintingArea) {
    var x = _a[0], y = _a[1];
    var width = _b[0], height = _b[1];
    switch (repeat) {
      case 2:
        return [
          new Vector(Math.round(backgroundPositioningArea.left), Math.round(backgroundPositioningArea.top + y)),
          new Vector(Math.round(backgroundPositioningArea.left + backgroundPositioningArea.width), Math.round(backgroundPositioningArea.top + y)),
          new Vector(Math.round(backgroundPositioningArea.left + backgroundPositioningArea.width), Math.round(height + backgroundPositioningArea.top + y)),
          new Vector(Math.round(backgroundPositioningArea.left), Math.round(height + backgroundPositioningArea.top + y))
        ];
      case 3:
        return [
          new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top)),
          new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top)),
          new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.height + backgroundPositioningArea.top)),
          new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.height + backgroundPositioningArea.top))
        ];
      case 1:
        return [
          new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top + y)),
          new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top + y)),
          new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top + y + height)),
          new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top + y + height))
        ];
      default:
        return [
          new Vector(Math.round(backgroundPaintingArea.left), Math.round(backgroundPaintingArea.top)),
          new Vector(Math.round(backgroundPaintingArea.left + backgroundPaintingArea.width), Math.round(backgroundPaintingArea.top)),
          new Vector(Math.round(backgroundPaintingArea.left + backgroundPaintingArea.width), Math.round(backgroundPaintingArea.height + backgroundPaintingArea.top)),
          new Vector(Math.round(backgroundPaintingArea.left), Math.round(backgroundPaintingArea.height + backgroundPaintingArea.top))
        ];
    }
  };
  var SMALL_IMAGE = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
  var SAMPLE_TEXT = "Hidden Text";
  var FontMetrics = (
    /** @class */
    (function() {
      function FontMetrics2(document2) {
        this._data = {};
        this._document = document2;
      }
      FontMetrics2.prototype.parseMetrics = function(fontFamily2, fontSize2) {
        var container = this._document.createElement("div");
        var img = this._document.createElement("img");
        var span = this._document.createElement("span");
        var body = this._document.body;
        container.style.visibility = "hidden";
        container.style.fontFamily = fontFamily2;
        container.style.fontSize = fontSize2;
        container.style.margin = "0";
        container.style.padding = "0";
        container.style.whiteSpace = "nowrap";
        body.appendChild(container);
        img.src = SMALL_IMAGE;
        img.width = 1;
        img.height = 1;
        img.style.margin = "0";
        img.style.padding = "0";
        img.style.verticalAlign = "baseline";
        span.style.fontFamily = fontFamily2;
        span.style.fontSize = fontSize2;
        span.style.margin = "0";
        span.style.padding = "0";
        span.appendChild(this._document.createTextNode(SAMPLE_TEXT));
        container.appendChild(span);
        container.appendChild(img);
        var baseline = img.offsetTop - span.offsetTop + 2;
        container.removeChild(span);
        container.appendChild(this._document.createTextNode(SAMPLE_TEXT));
        container.style.lineHeight = "normal";
        img.style.verticalAlign = "super";
        var middle = img.offsetTop - container.offsetTop + 2;
        body.removeChild(container);
        return { baseline, middle };
      };
      FontMetrics2.prototype.getMetrics = function(fontFamily2, fontSize2) {
        var key = fontFamily2 + " " + fontSize2;
        if (typeof this._data[key] === "undefined") {
          this._data[key] = this.parseMetrics(fontFamily2, fontSize2);
        }
        return this._data[key];
      };
      return FontMetrics2;
    })()
  );
  var Renderer = (
    /** @class */
    /* @__PURE__ */ (function() {
      function Renderer2(context, options) {
        this.context = context;
        this.options = options;
      }
      return Renderer2;
    })()
  );
  var MASK_OFFSET = 1e4;
  var CanvasRenderer = (
    /** @class */
    (function(_super) {
      __extends(CanvasRenderer2, _super);
      function CanvasRenderer2(context, options) {
        var _this = _super.call(this, context, options) || this;
        _this._activeEffects = [];
        _this.canvas = options.canvas ? options.canvas : document.createElement("canvas");
        _this.ctx = _this.canvas.getContext("2d");
        if (!options.canvas) {
          _this.canvas.width = Math.floor(options.width * options.scale);
          _this.canvas.height = Math.floor(options.height * options.scale);
          _this.canvas.style.width = options.width + "px";
          _this.canvas.style.height = options.height + "px";
        }
        _this.fontMetrics = new FontMetrics(document);
        _this.ctx.scale(_this.options.scale, _this.options.scale);
        _this.ctx.translate(-options.x, -options.y);
        _this.ctx.textBaseline = "bottom";
        _this._activeEffects = [];
        _this.context.logger.debug("Canvas renderer initialized (" + options.width + "x" + options.height + ") with scale " + options.scale);
        return _this;
      }
      CanvasRenderer2.prototype.applyEffects = function(effects) {
        var _this = this;
        while (this._activeEffects.length) {
          this.popEffect();
        }
        effects.forEach(function(effect) {
          return _this.applyEffect(effect);
        });
      };
      CanvasRenderer2.prototype.applyEffect = function(effect) {
        this.ctx.save();
        if (isOpacityEffect(effect)) {
          this.ctx.globalAlpha = effect.opacity;
        }
        if (isTransformEffect(effect)) {
          this.ctx.translate(effect.offsetX, effect.offsetY);
          this.ctx.transform(effect.matrix[0], effect.matrix[1], effect.matrix[2], effect.matrix[3], effect.matrix[4], effect.matrix[5]);
          this.ctx.translate(-effect.offsetX, -effect.offsetY);
        }
        if (isClipEffect(effect)) {
          this.path(effect.path);
          this.ctx.clip();
        }
        this._activeEffects.push(effect);
      };
      CanvasRenderer2.prototype.popEffect = function() {
        this._activeEffects.pop();
        this.ctx.restore();
      };
      CanvasRenderer2.prototype.renderStack = function(stack) {
        return __awaiter(this, void 0, void 0, function() {
          var styles;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                styles = stack.element.container.styles;
                if (!styles.isVisible()) return [3, 2];
                return [4, this.renderStackContent(stack)];
              case 1:
                _a.sent();
                _a.label = 2;
              case 2:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      CanvasRenderer2.prototype.renderNode = function(paint) {
        return __awaiter(this, void 0, void 0, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                if (contains(
                  paint.container.flags,
                  16
                  /* DEBUG_RENDER */
                )) {
                  debugger;
                }
                if (!paint.container.styles.isVisible()) return [3, 3];
                return [4, this.renderNodeBackgroundAndBorders(paint)];
              case 1:
                _a.sent();
                return [4, this.renderNodeContent(paint)];
              case 2:
                _a.sent();
                _a.label = 3;
              case 3:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      CanvasRenderer2.prototype.renderTextWithLetterSpacing = function(text, letterSpacing2, baseline) {
        var _this = this;
        if (letterSpacing2 === 0) {
          this.ctx.fillText(text.text, text.bounds.left, text.bounds.top + baseline);
        } else {
          var letters = segmentGraphemes(text.text);
          letters.reduce(function(left, letter) {
            _this.ctx.fillText(letter, left, text.bounds.top + baseline);
            return left + _this.ctx.measureText(letter).width;
          }, text.bounds.left);
        }
      };
      CanvasRenderer2.prototype.createFontStyle = function(styles) {
        var fontVariant2 = styles.fontVariant.filter(function(variant) {
          return variant === "normal" || variant === "small-caps";
        }).join("");
        var fontFamily2 = fixIOSSystemFonts(styles.fontFamily).join(", ");
        var fontSize2 = isDimensionToken(styles.fontSize) ? "" + styles.fontSize.number + styles.fontSize.unit : styles.fontSize.number + "px";
        return [
          [styles.fontStyle, fontVariant2, styles.fontWeight, fontSize2, fontFamily2].join(" "),
          fontFamily2,
          fontSize2
        ];
      };
      CanvasRenderer2.prototype.renderTextNode = function(text, styles) {
        return __awaiter(this, void 0, void 0, function() {
          var _a, font, fontFamily2, fontSize2, _b, baseline, middle, paintOrder2;
          var _this = this;
          return __generator(this, function(_c) {
            _a = this.createFontStyle(styles), font = _a[0], fontFamily2 = _a[1], fontSize2 = _a[2];
            this.ctx.font = font;
            this.ctx.direction = styles.direction === 1 ? "rtl" : "ltr";
            this.ctx.textAlign = "left";
            this.ctx.textBaseline = "alphabetic";
            _b = this.fontMetrics.getMetrics(fontFamily2, fontSize2), baseline = _b.baseline, middle = _b.middle;
            paintOrder2 = styles.paintOrder;
            text.textBounds.forEach(function(text2) {
              paintOrder2.forEach(function(paintOrderLayer) {
                switch (paintOrderLayer) {
                  case 0:
                    _this.ctx.fillStyle = asString(styles.color);
                    _this.renderTextWithLetterSpacing(text2, styles.letterSpacing, baseline);
                    var textShadows = styles.textShadow;
                    if (textShadows.length && text2.text.trim().length) {
                      textShadows.slice(0).reverse().forEach(function(textShadow2) {
                        _this.ctx.shadowColor = asString(textShadow2.color);
                        _this.ctx.shadowOffsetX = textShadow2.offsetX.number * _this.options.scale;
                        _this.ctx.shadowOffsetY = textShadow2.offsetY.number * _this.options.scale;
                        _this.ctx.shadowBlur = textShadow2.blur.number;
                        _this.renderTextWithLetterSpacing(text2, styles.letterSpacing, baseline);
                      });
                      _this.ctx.shadowColor = "";
                      _this.ctx.shadowOffsetX = 0;
                      _this.ctx.shadowOffsetY = 0;
                      _this.ctx.shadowBlur = 0;
                    }
                    if (styles.textDecorationLine.length) {
                      _this.ctx.fillStyle = asString(styles.textDecorationColor || styles.color);
                      styles.textDecorationLine.forEach(function(textDecorationLine2) {
                        switch (textDecorationLine2) {
                          case 1:
                            _this.ctx.fillRect(text2.bounds.left, Math.round(text2.bounds.top + baseline), text2.bounds.width, 1);
                            break;
                          case 2:
                            _this.ctx.fillRect(text2.bounds.left, Math.round(text2.bounds.top), text2.bounds.width, 1);
                            break;
                          case 3:
                            _this.ctx.fillRect(text2.bounds.left, Math.ceil(text2.bounds.top + middle), text2.bounds.width, 1);
                            break;
                        }
                      });
                    }
                    break;
                  case 1:
                    if (styles.webkitTextStrokeWidth && text2.text.trim().length) {
                      _this.ctx.strokeStyle = asString(styles.webkitTextStrokeColor);
                      _this.ctx.lineWidth = styles.webkitTextStrokeWidth;
                      _this.ctx.lineJoin = !!window.chrome ? "miter" : "round";
                      _this.ctx.strokeText(text2.text, text2.bounds.left, text2.bounds.top + baseline);
                    }
                    _this.ctx.strokeStyle = "";
                    _this.ctx.lineWidth = 0;
                    _this.ctx.lineJoin = "miter";
                    break;
                }
              });
            });
            return [
              2
              /*return*/
            ];
          });
        });
      };
      CanvasRenderer2.prototype.renderReplacedElement = function(container, curves, image2) {
        if (image2 && container.intrinsicWidth > 0 && container.intrinsicHeight > 0) {
          var box = contentBox(container);
          var path = calculatePaddingBoxPath(curves);
          this.path(path);
          this.ctx.save();
          this.ctx.clip();
          this.ctx.drawImage(image2, 0, 0, container.intrinsicWidth, container.intrinsicHeight, box.left, box.top, box.width, box.height);
          this.ctx.restore();
        }
      };
      CanvasRenderer2.prototype.renderNodeContent = function(paint) {
        return __awaiter(this, void 0, void 0, function() {
          var container, curves, styles, _i, _a, child, image2, image2, iframeRenderer, canvas, size, _b, fontFamily2, fontSize2, baseline, bounds, x, textBounds, img, image2, url, fontFamily2, bounds;
          return __generator(this, function(_c) {
            switch (_c.label) {
              case 0:
                this.applyEffects(paint.getEffects(
                  4
                  /* CONTENT */
                ));
                container = paint.container;
                curves = paint.curves;
                styles = container.styles;
                _i = 0, _a = container.textNodes;
                _c.label = 1;
              case 1:
                if (!(_i < _a.length)) return [3, 4];
                child = _a[_i];
                return [4, this.renderTextNode(child, styles)];
              case 2:
                _c.sent();
                _c.label = 3;
              case 3:
                _i++;
                return [3, 1];
              case 4:
                if (!(container instanceof ImageElementContainer)) return [3, 8];
                _c.label = 5;
              case 5:
                _c.trys.push([5, 7, , 8]);
                return [4, this.context.cache.match(container.src)];
              case 6:
                image2 = _c.sent();
                this.renderReplacedElement(container, curves, image2);
                return [3, 8];
              case 7:
                _c.sent();
                this.context.logger.error("Error loading image " + container.src);
                return [3, 8];
              case 8:
                if (container instanceof CanvasElementContainer) {
                  this.renderReplacedElement(container, curves, container.canvas);
                }
                if (!(container instanceof SVGElementContainer)) return [3, 12];
                _c.label = 9;
              case 9:
                _c.trys.push([9, 11, , 12]);
                return [4, this.context.cache.match(container.svg)];
              case 10:
                image2 = _c.sent();
                this.renderReplacedElement(container, curves, image2);
                return [3, 12];
              case 11:
                _c.sent();
                this.context.logger.error("Error loading svg " + container.svg.substring(0, 255));
                return [3, 12];
              case 12:
                if (!(container instanceof IFrameElementContainer && container.tree)) return [3, 14];
                iframeRenderer = new CanvasRenderer2(this.context, {
                  scale: this.options.scale,
                  backgroundColor: container.backgroundColor,
                  x: 0,
                  y: 0,
                  width: container.width,
                  height: container.height
                });
                return [4, iframeRenderer.render(container.tree)];
              case 13:
                canvas = _c.sent();
                if (container.width && container.height) {
                  this.ctx.drawImage(canvas, 0, 0, container.width, container.height, container.bounds.left, container.bounds.top, container.bounds.width, container.bounds.height);
                }
                _c.label = 14;
              case 14:
                if (container instanceof InputElementContainer) {
                  size = Math.min(container.bounds.width, container.bounds.height);
                  if (container.type === CHECKBOX) {
                    if (container.checked) {
                      this.ctx.save();
                      this.path([
                        new Vector(container.bounds.left + size * 0.39363, container.bounds.top + size * 0.79),
                        new Vector(container.bounds.left + size * 0.16, container.bounds.top + size * 0.5549),
                        new Vector(container.bounds.left + size * 0.27347, container.bounds.top + size * 0.44071),
                        new Vector(container.bounds.left + size * 0.39694, container.bounds.top + size * 0.5649),
                        new Vector(container.bounds.left + size * 0.72983, container.bounds.top + size * 0.23),
                        new Vector(container.bounds.left + size * 0.84, container.bounds.top + size * 0.34085),
                        new Vector(container.bounds.left + size * 0.39363, container.bounds.top + size * 0.79)
                      ]);
                      this.ctx.fillStyle = asString(INPUT_COLOR);
                      this.ctx.fill();
                      this.ctx.restore();
                    }
                  } else if (container.type === RADIO) {
                    if (container.checked) {
                      this.ctx.save();
                      this.ctx.beginPath();
                      this.ctx.arc(container.bounds.left + size / 2, container.bounds.top + size / 2, size / 4, 0, Math.PI * 2, true);
                      this.ctx.fillStyle = asString(INPUT_COLOR);
                      this.ctx.fill();
                      this.ctx.restore();
                    }
                  }
                }
                if (isTextInputElement(container) && container.value.length) {
                  _b = this.createFontStyle(styles), fontFamily2 = _b[0], fontSize2 = _b[1];
                  baseline = this.fontMetrics.getMetrics(fontFamily2, fontSize2).baseline;
                  this.ctx.font = fontFamily2;
                  this.ctx.fillStyle = asString(styles.color);
                  this.ctx.textBaseline = "alphabetic";
                  this.ctx.textAlign = canvasTextAlign(container.styles.textAlign);
                  bounds = contentBox(container);
                  x = 0;
                  switch (container.styles.textAlign) {
                    case 1:
                      x += bounds.width / 2;
                      break;
                    case 2:
                      x += bounds.width;
                      break;
                  }
                  textBounds = bounds.add(x, 0, 0, -bounds.height / 2 + 1);
                  this.ctx.save();
                  this.path([
                    new Vector(bounds.left, bounds.top),
                    new Vector(bounds.left + bounds.width, bounds.top),
                    new Vector(bounds.left + bounds.width, bounds.top + bounds.height),
                    new Vector(bounds.left, bounds.top + bounds.height)
                  ]);
                  this.ctx.clip();
                  this.renderTextWithLetterSpacing(new TextBounds(container.value, textBounds), styles.letterSpacing, baseline);
                  this.ctx.restore();
                  this.ctx.textBaseline = "alphabetic";
                  this.ctx.textAlign = "left";
                }
                if (!contains(
                  container.styles.display,
                  2048
                  /* LIST_ITEM */
                )) return [3, 20];
                if (!(container.styles.listStyleImage !== null)) return [3, 19];
                img = container.styles.listStyleImage;
                if (!(img.type === 0)) return [3, 18];
                image2 = void 0;
                url = img.url;
                _c.label = 15;
              case 15:
                _c.trys.push([15, 17, , 18]);
                return [4, this.context.cache.match(url)];
              case 16:
                image2 = _c.sent();
                this.ctx.drawImage(image2, container.bounds.left - (image2.width + 10), container.bounds.top);
                return [3, 18];
              case 17:
                _c.sent();
                this.context.logger.error("Error loading list-style-image " + url);
                return [3, 18];
              case 18:
                return [3, 20];
              case 19:
                if (paint.listValue && container.styles.listStyleType !== -1) {
                  fontFamily2 = this.createFontStyle(styles)[0];
                  this.ctx.font = fontFamily2;
                  this.ctx.fillStyle = asString(styles.color);
                  this.ctx.textBaseline = "middle";
                  this.ctx.textAlign = "right";
                  bounds = new Bounds(container.bounds.left, container.bounds.top + getAbsoluteValue(container.styles.paddingTop, container.bounds.width), container.bounds.width, computeLineHeight(styles.lineHeight, styles.fontSize.number) / 2 + 1);
                  this.renderTextWithLetterSpacing(new TextBounds(paint.listValue, bounds), styles.letterSpacing, computeLineHeight(styles.lineHeight, styles.fontSize.number) / 2 + 2);
                  this.ctx.textBaseline = "bottom";
                  this.ctx.textAlign = "left";
                }
                _c.label = 20;
              case 20:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      CanvasRenderer2.prototype.renderStackContent = function(stack) {
        return __awaiter(this, void 0, void 0, function() {
          var _i, _a, child, _b, _c, child, _d, _e, child, _f, _g, child, _h, _j, child, _k, _l, child, _m, _o, child;
          return __generator(this, function(_p) {
            switch (_p.label) {
              case 0:
                if (contains(
                  stack.element.container.flags,
                  16
                  /* DEBUG_RENDER */
                )) {
                  debugger;
                }
                return [4, this.renderNodeBackgroundAndBorders(stack.element)];
              case 1:
                _p.sent();
                _i = 0, _a = stack.negativeZIndex;
                _p.label = 2;
              case 2:
                if (!(_i < _a.length)) return [3, 5];
                child = _a[_i];
                return [4, this.renderStack(child)];
              case 3:
                _p.sent();
                _p.label = 4;
              case 4:
                _i++;
                return [3, 2];
              case 5:
                return [4, this.renderNodeContent(stack.element)];
              case 6:
                _p.sent();
                _b = 0, _c = stack.nonInlineLevel;
                _p.label = 7;
              case 7:
                if (!(_b < _c.length)) return [3, 10];
                child = _c[_b];
                return [4, this.renderNode(child)];
              case 8:
                _p.sent();
                _p.label = 9;
              case 9:
                _b++;
                return [3, 7];
              case 10:
                _d = 0, _e = stack.nonPositionedFloats;
                _p.label = 11;
              case 11:
                if (!(_d < _e.length)) return [3, 14];
                child = _e[_d];
                return [4, this.renderStack(child)];
              case 12:
                _p.sent();
                _p.label = 13;
              case 13:
                _d++;
                return [3, 11];
              case 14:
                _f = 0, _g = stack.nonPositionedInlineLevel;
                _p.label = 15;
              case 15:
                if (!(_f < _g.length)) return [3, 18];
                child = _g[_f];
                return [4, this.renderStack(child)];
              case 16:
                _p.sent();
                _p.label = 17;
              case 17:
                _f++;
                return [3, 15];
              case 18:
                _h = 0, _j = stack.inlineLevel;
                _p.label = 19;
              case 19:
                if (!(_h < _j.length)) return [3, 22];
                child = _j[_h];
                return [4, this.renderNode(child)];
              case 20:
                _p.sent();
                _p.label = 21;
              case 21:
                _h++;
                return [3, 19];
              case 22:
                _k = 0, _l = stack.zeroOrAutoZIndexOrTransformedOrOpacity;
                _p.label = 23;
              case 23:
                if (!(_k < _l.length)) return [3, 26];
                child = _l[_k];
                return [4, this.renderStack(child)];
              case 24:
                _p.sent();
                _p.label = 25;
              case 25:
                _k++;
                return [3, 23];
              case 26:
                _m = 0, _o = stack.positiveZIndex;
                _p.label = 27;
              case 27:
                if (!(_m < _o.length)) return [3, 30];
                child = _o[_m];
                return [4, this.renderStack(child)];
              case 28:
                _p.sent();
                _p.label = 29;
              case 29:
                _m++;
                return [3, 27];
              case 30:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      CanvasRenderer2.prototype.mask = function(paths) {
        this.ctx.beginPath();
        this.ctx.moveTo(0, 0);
        this.ctx.lineTo(this.canvas.width, 0);
        this.ctx.lineTo(this.canvas.width, this.canvas.height);
        this.ctx.lineTo(0, this.canvas.height);
        this.ctx.lineTo(0, 0);
        this.formatPath(paths.slice(0).reverse());
        this.ctx.closePath();
      };
      CanvasRenderer2.prototype.path = function(paths) {
        this.ctx.beginPath();
        this.formatPath(paths);
        this.ctx.closePath();
      };
      CanvasRenderer2.prototype.formatPath = function(paths) {
        var _this = this;
        paths.forEach(function(point, index) {
          var start = isBezierCurve(point) ? point.start : point;
          if (index === 0) {
            _this.ctx.moveTo(start.x, start.y);
          } else {
            _this.ctx.lineTo(start.x, start.y);
          }
          if (isBezierCurve(point)) {
            _this.ctx.bezierCurveTo(point.startControl.x, point.startControl.y, point.endControl.x, point.endControl.y, point.end.x, point.end.y);
          }
        });
      };
      CanvasRenderer2.prototype.renderRepeat = function(path, pattern, offsetX, offsetY) {
        this.path(path);
        this.ctx.fillStyle = pattern;
        this.ctx.translate(offsetX, offsetY);
        this.ctx.fill();
        this.ctx.translate(-offsetX, -offsetY);
      };
      CanvasRenderer2.prototype.resizeImage = function(image2, width, height) {
        var _a;
        if (image2.width === width && image2.height === height) {
          return image2;
        }
        var ownerDocument = (_a = this.canvas.ownerDocument) !== null && _a !== void 0 ? _a : document;
        var canvas = ownerDocument.createElement("canvas");
        canvas.width = Math.max(1, width);
        canvas.height = Math.max(1, height);
        var ctx = canvas.getContext("2d");
        ctx.drawImage(image2, 0, 0, image2.width, image2.height, 0, 0, width, height);
        return canvas;
      };
      CanvasRenderer2.prototype.renderBackgroundImage = function(container) {
        return __awaiter(this, void 0, void 0, function() {
          var index, _loop_1, this_1, _i, _a, backgroundImage2;
          return __generator(this, function(_b) {
            switch (_b.label) {
              case 0:
                index = container.styles.backgroundImage.length - 1;
                _loop_1 = function(backgroundImage3) {
                  var image2, url, _c, path, x, y, width, height, pattern, _d, path, x, y, width, height, _e, lineLength, x0, x1, y0, y1, canvas, ctx, gradient_1, pattern, _f, path, left, top_1, width, height, position2, x, y, _g, rx, ry, radialGradient_1, midX, midY, f2, invF;
                  return __generator(this, function(_h) {
                    switch (_h.label) {
                      case 0:
                        if (!(backgroundImage3.type === 0)) return [3, 5];
                        image2 = void 0;
                        url = backgroundImage3.url;
                        _h.label = 1;
                      case 1:
                        _h.trys.push([1, 3, , 4]);
                        return [4, this_1.context.cache.match(url)];
                      case 2:
                        image2 = _h.sent();
                        return [3, 4];
                      case 3:
                        _h.sent();
                        this_1.context.logger.error("Error loading background-image " + url);
                        return [3, 4];
                      case 4:
                        if (image2) {
                          _c = calculateBackgroundRendering(container, index, [
                            image2.width,
                            image2.height,
                            image2.width / image2.height
                          ]), path = _c[0], x = _c[1], y = _c[2], width = _c[3], height = _c[4];
                          pattern = this_1.ctx.createPattern(this_1.resizeImage(image2, width, height), "repeat");
                          this_1.renderRepeat(path, pattern, x, y);
                        }
                        return [3, 6];
                      case 5:
                        if (isLinearGradient(backgroundImage3)) {
                          _d = calculateBackgroundRendering(container, index, [null, null, null]), path = _d[0], x = _d[1], y = _d[2], width = _d[3], height = _d[4];
                          _e = calculateGradientDirection(backgroundImage3.angle, width, height), lineLength = _e[0], x0 = _e[1], x1 = _e[2], y0 = _e[3], y1 = _e[4];
                          canvas = document.createElement("canvas");
                          canvas.width = width;
                          canvas.height = height;
                          ctx = canvas.getContext("2d");
                          gradient_1 = ctx.createLinearGradient(x0, y0, x1, y1);
                          processColorStops(backgroundImage3.stops, lineLength).forEach(function(colorStop) {
                            return gradient_1.addColorStop(colorStop.stop, asString(colorStop.color));
                          });
                          ctx.fillStyle = gradient_1;
                          ctx.fillRect(0, 0, width, height);
                          if (width > 0 && height > 0) {
                            pattern = this_1.ctx.createPattern(canvas, "repeat");
                            this_1.renderRepeat(path, pattern, x, y);
                          }
                        } else if (isRadialGradient(backgroundImage3)) {
                          _f = calculateBackgroundRendering(container, index, [
                            null,
                            null,
                            null
                          ]), path = _f[0], left = _f[1], top_1 = _f[2], width = _f[3], height = _f[4];
                          position2 = backgroundImage3.position.length === 0 ? [FIFTY_PERCENT] : backgroundImage3.position;
                          x = getAbsoluteValue(position2[0], width);
                          y = getAbsoluteValue(position2[position2.length - 1], height);
                          _g = calculateRadius(backgroundImage3, x, y, width, height), rx = _g[0], ry = _g[1];
                          if (rx > 0 && ry > 0) {
                            radialGradient_1 = this_1.ctx.createRadialGradient(left + x, top_1 + y, 0, left + x, top_1 + y, rx);
                            processColorStops(backgroundImage3.stops, rx * 2).forEach(function(colorStop) {
                              return radialGradient_1.addColorStop(colorStop.stop, asString(colorStop.color));
                            });
                            this_1.path(path);
                            this_1.ctx.fillStyle = radialGradient_1;
                            if (rx !== ry) {
                              midX = container.bounds.left + 0.5 * container.bounds.width;
                              midY = container.bounds.top + 0.5 * container.bounds.height;
                              f2 = ry / rx;
                              invF = 1 / f2;
                              this_1.ctx.save();
                              this_1.ctx.translate(midX, midY);
                              this_1.ctx.transform(1, 0, 0, f2, 0, 0);
                              this_1.ctx.translate(-midX, -midY);
                              this_1.ctx.fillRect(left, invF * (top_1 - midY) + midY, width, height * invF);
                              this_1.ctx.restore();
                            } else {
                              this_1.ctx.fill();
                            }
                          }
                        }
                        _h.label = 6;
                      case 6:
                        index--;
                        return [
                          2
                          /*return*/
                        ];
                    }
                  });
                };
                this_1 = this;
                _i = 0, _a = container.styles.backgroundImage.slice(0).reverse();
                _b.label = 1;
              case 1:
                if (!(_i < _a.length)) return [3, 4];
                backgroundImage2 = _a[_i];
                return [5, _loop_1(backgroundImage2)];
              case 2:
                _b.sent();
                _b.label = 3;
              case 3:
                _i++;
                return [3, 1];
              case 4:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      CanvasRenderer2.prototype.renderSolidBorder = function(color2, side, curvePoints) {
        return __awaiter(this, void 0, void 0, function() {
          return __generator(this, function(_a) {
            this.path(parsePathForBorder(curvePoints, side));
            this.ctx.fillStyle = asString(color2);
            this.ctx.fill();
            return [
              2
              /*return*/
            ];
          });
        });
      };
      CanvasRenderer2.prototype.renderDoubleBorder = function(color2, width, side, curvePoints) {
        return __awaiter(this, void 0, void 0, function() {
          var outerPaths, innerPaths;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                if (!(width < 3)) return [3, 2];
                return [4, this.renderSolidBorder(color2, side, curvePoints)];
              case 1:
                _a.sent();
                return [
                  2
                  /*return*/
                ];
              case 2:
                outerPaths = parsePathForBorderDoubleOuter(curvePoints, side);
                this.path(outerPaths);
                this.ctx.fillStyle = asString(color2);
                this.ctx.fill();
                innerPaths = parsePathForBorderDoubleInner(curvePoints, side);
                this.path(innerPaths);
                this.ctx.fill();
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      CanvasRenderer2.prototype.renderNodeBackgroundAndBorders = function(paint) {
        return __awaiter(this, void 0, void 0, function() {
          var styles, hasBackground, borders, backgroundPaintingArea, side, _i, borders_1, border;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                this.applyEffects(paint.getEffects(
                  2
                  /* BACKGROUND_BORDERS */
                ));
                styles = paint.container.styles;
                hasBackground = !isTransparent(styles.backgroundColor) || styles.backgroundImage.length;
                borders = [
                  { style: styles.borderTopStyle, color: styles.borderTopColor, width: styles.borderTopWidth },
                  { style: styles.borderRightStyle, color: styles.borderRightColor, width: styles.borderRightWidth },
                  { style: styles.borderBottomStyle, color: styles.borderBottomColor, width: styles.borderBottomWidth },
                  { style: styles.borderLeftStyle, color: styles.borderLeftColor, width: styles.borderLeftWidth }
                ];
                backgroundPaintingArea = calculateBackgroundCurvedPaintingArea(getBackgroundValueForIndex(styles.backgroundClip, 0), paint.curves);
                if (!(hasBackground || styles.boxShadow.length)) return [3, 2];
                this.ctx.save();
                this.path(backgroundPaintingArea);
                this.ctx.clip();
                if (!isTransparent(styles.backgroundColor)) {
                  this.ctx.fillStyle = asString(styles.backgroundColor);
                  this.ctx.fill();
                }
                return [4, this.renderBackgroundImage(paint.container)];
              case 1:
                _a.sent();
                this.ctx.restore();
                styles.boxShadow.slice(0).reverse().forEach(function(shadow) {
                  _this.ctx.save();
                  var borderBoxArea = calculateBorderBoxPath(paint.curves);
                  var maskOffset = shadow.inset ? 0 : MASK_OFFSET;
                  var shadowPaintingArea = transformPath(borderBoxArea, -maskOffset + (shadow.inset ? 1 : -1) * shadow.spread.number, (shadow.inset ? 1 : -1) * shadow.spread.number, shadow.spread.number * (shadow.inset ? -2 : 2), shadow.spread.number * (shadow.inset ? -2 : 2));
                  if (shadow.inset) {
                    _this.path(borderBoxArea);
                    _this.ctx.clip();
                    _this.mask(shadowPaintingArea);
                  } else {
                    _this.mask(borderBoxArea);
                    _this.ctx.clip();
                    _this.path(shadowPaintingArea);
                  }
                  _this.ctx.shadowOffsetX = shadow.offsetX.number + maskOffset;
                  _this.ctx.shadowOffsetY = shadow.offsetY.number;
                  _this.ctx.shadowColor = asString(shadow.color);
                  _this.ctx.shadowBlur = shadow.blur.number;
                  _this.ctx.fillStyle = shadow.inset ? asString(shadow.color) : "rgba(0,0,0,1)";
                  _this.ctx.fill();
                  _this.ctx.restore();
                });
                _a.label = 2;
              case 2:
                side = 0;
                _i = 0, borders_1 = borders;
                _a.label = 3;
              case 3:
                if (!(_i < borders_1.length)) return [3, 13];
                border = borders_1[_i];
                if (!(border.style !== 0 && !isTransparent(border.color) && border.width > 0)) return [3, 11];
                if (!(border.style === 2)) return [3, 5];
                return [4, this.renderDashedDottedBorder(
                  border.color,
                  border.width,
                  side,
                  paint.curves,
                  2
                  /* DASHED */
                )];
              case 4:
                _a.sent();
                return [3, 11];
              case 5:
                if (!(border.style === 3)) return [3, 7];
                return [4, this.renderDashedDottedBorder(
                  border.color,
                  border.width,
                  side,
                  paint.curves,
                  3
                  /* DOTTED */
                )];
              case 6:
                _a.sent();
                return [3, 11];
              case 7:
                if (!(border.style === 4)) return [3, 9];
                return [4, this.renderDoubleBorder(border.color, border.width, side, paint.curves)];
              case 8:
                _a.sent();
                return [3, 11];
              case 9:
                return [4, this.renderSolidBorder(border.color, side, paint.curves)];
              case 10:
                _a.sent();
                _a.label = 11;
              case 11:
                side++;
                _a.label = 12;
              case 12:
                _i++;
                return [3, 3];
              case 13:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      CanvasRenderer2.prototype.renderDashedDottedBorder = function(color2, width, side, curvePoints, style) {
        return __awaiter(this, void 0, void 0, function() {
          var strokePaths, boxPaths, startX, startY, endX, endY, length, dashLength, spaceLength, useLineDash, multiplier, numberOfDashes, minSpace, maxSpace, path1, path2, path1, path2;
          return __generator(this, function(_a) {
            this.ctx.save();
            strokePaths = parsePathForBorderStroke(curvePoints, side);
            boxPaths = parsePathForBorder(curvePoints, side);
            if (style === 2) {
              this.path(boxPaths);
              this.ctx.clip();
            }
            if (isBezierCurve(boxPaths[0])) {
              startX = boxPaths[0].start.x;
              startY = boxPaths[0].start.y;
            } else {
              startX = boxPaths[0].x;
              startY = boxPaths[0].y;
            }
            if (isBezierCurve(boxPaths[1])) {
              endX = boxPaths[1].end.x;
              endY = boxPaths[1].end.y;
            } else {
              endX = boxPaths[1].x;
              endY = boxPaths[1].y;
            }
            if (side === 0 || side === 2) {
              length = Math.abs(startX - endX);
            } else {
              length = Math.abs(startY - endY);
            }
            this.ctx.beginPath();
            if (style === 3) {
              this.formatPath(strokePaths);
            } else {
              this.formatPath(boxPaths.slice(0, 2));
            }
            dashLength = width < 3 ? width * 3 : width * 2;
            spaceLength = width < 3 ? width * 2 : width;
            if (style === 3) {
              dashLength = width;
              spaceLength = width;
            }
            useLineDash = true;
            if (length <= dashLength * 2) {
              useLineDash = false;
            } else if (length <= dashLength * 2 + spaceLength) {
              multiplier = length / (2 * dashLength + spaceLength);
              dashLength *= multiplier;
              spaceLength *= multiplier;
            } else {
              numberOfDashes = Math.floor((length + spaceLength) / (dashLength + spaceLength));
              minSpace = (length - numberOfDashes * dashLength) / (numberOfDashes - 1);
              maxSpace = (length - (numberOfDashes + 1) * dashLength) / numberOfDashes;
              spaceLength = maxSpace <= 0 || Math.abs(spaceLength - minSpace) < Math.abs(spaceLength - maxSpace) ? minSpace : maxSpace;
            }
            if (useLineDash) {
              if (style === 3) {
                this.ctx.setLineDash([0, dashLength + spaceLength]);
              } else {
                this.ctx.setLineDash([dashLength, spaceLength]);
              }
            }
            if (style === 3) {
              this.ctx.lineCap = "round";
              this.ctx.lineWidth = width;
            } else {
              this.ctx.lineWidth = width * 2 + 1.1;
            }
            this.ctx.strokeStyle = asString(color2);
            this.ctx.stroke();
            this.ctx.setLineDash([]);
            if (style === 2) {
              if (isBezierCurve(boxPaths[0])) {
                path1 = boxPaths[3];
                path2 = boxPaths[0];
                this.ctx.beginPath();
                this.formatPath([new Vector(path1.end.x, path1.end.y), new Vector(path2.start.x, path2.start.y)]);
                this.ctx.stroke();
              }
              if (isBezierCurve(boxPaths[1])) {
                path1 = boxPaths[1];
                path2 = boxPaths[2];
                this.ctx.beginPath();
                this.formatPath([new Vector(path1.end.x, path1.end.y), new Vector(path2.start.x, path2.start.y)]);
                this.ctx.stroke();
              }
            }
            this.ctx.restore();
            return [
              2
              /*return*/
            ];
          });
        });
      };
      CanvasRenderer2.prototype.render = function(element) {
        return __awaiter(this, void 0, void 0, function() {
          var stack;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                if (this.options.backgroundColor) {
                  this.ctx.fillStyle = asString(this.options.backgroundColor);
                  this.ctx.fillRect(this.options.x, this.options.y, this.options.width, this.options.height);
                }
                stack = parseStackingContexts(element);
                return [4, this.renderStack(stack)];
              case 1:
                _a.sent();
                this.applyEffects([]);
                return [2, this.canvas];
            }
          });
        });
      };
      return CanvasRenderer2;
    })(Renderer)
  );
  var isTextInputElement = function(container) {
    if (container instanceof TextareaElementContainer) {
      return true;
    } else if (container instanceof SelectElementContainer) {
      return true;
    } else if (container instanceof InputElementContainer && container.type !== RADIO && container.type !== CHECKBOX) {
      return true;
    }
    return false;
  };
  var calculateBackgroundCurvedPaintingArea = function(clip, curves) {
    switch (clip) {
      case 0:
        return calculateBorderBoxPath(curves);
      case 2:
        return calculateContentBoxPath(curves);
      case 1:
      default:
        return calculatePaddingBoxPath(curves);
    }
  };
  var canvasTextAlign = function(textAlign2) {
    switch (textAlign2) {
      case 1:
        return "center";
      case 2:
        return "right";
      case 0:
      default:
        return "left";
    }
  };
  var iOSBrokenFonts = ["-apple-system", "system-ui"];
  var fixIOSSystemFonts = function(fontFamilies) {
    return /iPhone OS 15_(0|1)/.test(window.navigator.userAgent) ? fontFamilies.filter(function(fontFamily2) {
      return iOSBrokenFonts.indexOf(fontFamily2) === -1;
    }) : fontFamilies;
  };
  var ForeignObjectRenderer = (
    /** @class */
    (function(_super) {
      __extends(ForeignObjectRenderer2, _super);
      function ForeignObjectRenderer2(context, options) {
        var _this = _super.call(this, context, options) || this;
        _this.canvas = options.canvas ? options.canvas : document.createElement("canvas");
        _this.ctx = _this.canvas.getContext("2d");
        _this.options = options;
        _this.canvas.width = Math.floor(options.width * options.scale);
        _this.canvas.height = Math.floor(options.height * options.scale);
        _this.canvas.style.width = options.width + "px";
        _this.canvas.style.height = options.height + "px";
        _this.ctx.scale(_this.options.scale, _this.options.scale);
        _this.ctx.translate(-options.x, -options.y);
        _this.context.logger.debug("EXPERIMENTAL ForeignObject renderer initialized (" + options.width + "x" + options.height + " at " + options.x + "," + options.y + ") with scale " + options.scale);
        return _this;
      }
      ForeignObjectRenderer2.prototype.render = function(element) {
        return __awaiter(this, void 0, void 0, function() {
          var svg, img;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                svg = createForeignObjectSVG(this.options.width * this.options.scale, this.options.height * this.options.scale, this.options.scale, this.options.scale, element);
                return [4, loadSerializedSVG(svg)];
              case 1:
                img = _a.sent();
                if (this.options.backgroundColor) {
                  this.ctx.fillStyle = asString(this.options.backgroundColor);
                  this.ctx.fillRect(0, 0, this.options.width * this.options.scale, this.options.height * this.options.scale);
                }
                this.ctx.drawImage(img, -this.options.x * this.options.scale, -this.options.y * this.options.scale);
                return [2, this.canvas];
            }
          });
        });
      };
      return ForeignObjectRenderer2;
    })(Renderer)
  );
  var loadSerializedSVG = function(svg) {
    return new Promise(function(resolve, reject) {
      var img = new Image();
      img.onload = function() {
        resolve(img);
      };
      img.onerror = reject;
      img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(svg));
    });
  };
  var Logger = (
    /** @class */
    (function() {
      function Logger2(_a) {
        var id = _a.id, enabled = _a.enabled;
        this.id = id;
        this.enabled = enabled;
        this.start = Date.now();
      }
      Logger2.prototype.debug = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        if (this.enabled) {
          if (typeof window !== "undefined" && window.console && typeof console.debug === "function") {
            console.debug.apply(console, __spreadArray([this.id, this.getTime() + "ms"], args));
          } else {
            this.info.apply(this, args);
          }
        }
      };
      Logger2.prototype.getTime = function() {
        return Date.now() - this.start;
      };
      Logger2.prototype.info = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        if (this.enabled) {
          if (typeof window !== "undefined" && window.console && typeof console.info === "function") {
            console.info.apply(console, __spreadArray([this.id, this.getTime() + "ms"], args));
          }
        }
      };
      Logger2.prototype.warn = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        if (this.enabled) {
          if (typeof window !== "undefined" && window.console && typeof console.warn === "function") {
            console.warn.apply(console, __spreadArray([this.id, this.getTime() + "ms"], args));
          } else {
            this.info.apply(this, args);
          }
        }
      };
      Logger2.prototype.error = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        if (this.enabled) {
          if (typeof window !== "undefined" && window.console && typeof console.error === "function") {
            console.error.apply(console, __spreadArray([this.id, this.getTime() + "ms"], args));
          } else {
            this.info.apply(this, args);
          }
        }
      };
      Logger2.instances = {};
      return Logger2;
    })()
  );
  var Context = (
    /** @class */
    (function() {
      function Context2(options, windowBounds) {
        var _a;
        this.windowBounds = windowBounds;
        this.instanceName = "#" + Context2.instanceCount++;
        this.logger = new Logger({ id: this.instanceName, enabled: options.logging });
        this.cache = (_a = options.cache) !== null && _a !== void 0 ? _a : new Cache(this, options);
      }
      Context2.instanceCount = 1;
      return Context2;
    })()
  );
  var html2canvas = function(element, options) {
    if (options === void 0) {
      options = {};
    }
    return renderElement(element, options);
  };
  if (typeof window !== "undefined") {
    CacheStorage.setContext(window);
  }
  var renderElement = function(element, opts) {
    return __awaiter(void 0, void 0, void 0, function() {
      var ownerDocument, defaultView, resourceOptions, contextOptions, windowOptions, windowBounds, context, foreignObjectRendering, cloneOptions, documentCloner, clonedElement, container, _a, width, height, left, top, backgroundColor2, renderOptions, canvas, renderer, root, renderer;
      var _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;
      return __generator(this, function(_u) {
        switch (_u.label) {
          case 0:
            if (!element || typeof element !== "object") {
              return [2, Promise.reject("Invalid element provided as first argument")];
            }
            ownerDocument = element.ownerDocument;
            if (!ownerDocument) {
              throw new Error("Element is not attached to a Document");
            }
            defaultView = ownerDocument.defaultView;
            if (!defaultView) {
              throw new Error("Document is not attached to a Window");
            }
            resourceOptions = {
              allowTaint: (_b = opts.allowTaint) !== null && _b !== void 0 ? _b : false,
              imageTimeout: (_c = opts.imageTimeout) !== null && _c !== void 0 ? _c : 15e3,
              proxy: opts.proxy,
              useCORS: (_d = opts.useCORS) !== null && _d !== void 0 ? _d : false
            };
            contextOptions = __assign({ logging: (_e = opts.logging) !== null && _e !== void 0 ? _e : true, cache: opts.cache }, resourceOptions);
            windowOptions = {
              windowWidth: (_f = opts.windowWidth) !== null && _f !== void 0 ? _f : defaultView.innerWidth,
              windowHeight: (_g = opts.windowHeight) !== null && _g !== void 0 ? _g : defaultView.innerHeight,
              scrollX: (_h = opts.scrollX) !== null && _h !== void 0 ? _h : defaultView.pageXOffset,
              scrollY: (_j = opts.scrollY) !== null && _j !== void 0 ? _j : defaultView.pageYOffset
            };
            windowBounds = new Bounds(windowOptions.scrollX, windowOptions.scrollY, windowOptions.windowWidth, windowOptions.windowHeight);
            context = new Context(contextOptions, windowBounds);
            foreignObjectRendering = (_k = opts.foreignObjectRendering) !== null && _k !== void 0 ? _k : false;
            cloneOptions = {
              allowTaint: (_l = opts.allowTaint) !== null && _l !== void 0 ? _l : false,
              onclone: opts.onclone,
              ignoreElements: opts.ignoreElements,
              inlineImages: foreignObjectRendering,
              copyStyles: foreignObjectRendering
            };
            context.logger.debug("Starting document clone with size " + windowBounds.width + "x" + windowBounds.height + " scrolled to " + -windowBounds.left + "," + -windowBounds.top);
            documentCloner = new DocumentCloner(context, element, cloneOptions);
            clonedElement = documentCloner.clonedReferenceElement;
            if (!clonedElement) {
              return [2, Promise.reject("Unable to find element in cloned iframe")];
            }
            return [4, documentCloner.toIFrame(ownerDocument, windowBounds)];
          case 1:
            container = _u.sent();
            _a = isBodyElement(clonedElement) || isHTMLElement(clonedElement) ? parseDocumentSize(clonedElement.ownerDocument) : parseBounds(context, clonedElement), width = _a.width, height = _a.height, left = _a.left, top = _a.top;
            backgroundColor2 = parseBackgroundColor(context, clonedElement, opts.backgroundColor);
            renderOptions = {
              canvas: opts.canvas,
              backgroundColor: backgroundColor2,
              scale: (_o = (_m = opts.scale) !== null && _m !== void 0 ? _m : defaultView.devicePixelRatio) !== null && _o !== void 0 ? _o : 1,
              x: ((_p = opts.x) !== null && _p !== void 0 ? _p : 0) + left,
              y: ((_q = opts.y) !== null && _q !== void 0 ? _q : 0) + top,
              width: (_r = opts.width) !== null && _r !== void 0 ? _r : Math.ceil(width),
              height: (_s = opts.height) !== null && _s !== void 0 ? _s : Math.ceil(height)
            };
            if (!foreignObjectRendering) return [3, 3];
            context.logger.debug("Document cloned, using foreign object rendering");
            renderer = new ForeignObjectRenderer(context, renderOptions);
            return [4, renderer.render(clonedElement)];
          case 2:
            canvas = _u.sent();
            return [3, 5];
          case 3:
            context.logger.debug("Document cloned, element located at " + left + "," + top + " with size " + width + "x" + height + " using computed rendering");
            context.logger.debug("Starting DOM parsing");
            root = parseTree(context, clonedElement);
            if (backgroundColor2 === root.styles.backgroundColor) {
              root.styles.backgroundColor = COLORS.TRANSPARENT;
            }
            context.logger.debug("Starting renderer for element at " + renderOptions.x + "," + renderOptions.y + " with size " + renderOptions.width + "x" + renderOptions.height);
            renderer = new CanvasRenderer(context, renderOptions);
            return [4, renderer.render(root)];
          case 4:
            canvas = _u.sent();
            _u.label = 5;
          case 5:
            if ((_t = opts.removeContainer) !== null && _t !== void 0 ? _t : true) {
              if (!DocumentCloner.destroy(container)) {
                context.logger.error("Cannot detach cloned iframe as it is not in the DOM anymore");
              }
            }
            context.logger.debug("Finished rendering");
            return [2, canvas];
        }
      });
    });
  };
  var parseBackgroundColor = function(context, element, backgroundColorOverride) {
    var ownerDocument = element.ownerDocument;
    var documentBackgroundColor = ownerDocument.documentElement ? parseColor(context, getComputedStyle(ownerDocument.documentElement).backgroundColor) : COLORS.TRANSPARENT;
    var bodyBackgroundColor = ownerDocument.body ? parseColor(context, getComputedStyle(ownerDocument.body).backgroundColor) : COLORS.TRANSPARENT;
    var defaultBackgroundColor = typeof backgroundColorOverride === "string" ? parseColor(context, backgroundColorOverride) : backgroundColorOverride === null ? COLORS.TRANSPARENT : 4294967295;
    return element === ownerDocument.documentElement ? isTransparent(documentBackgroundColor) ? isTransparent(bodyBackgroundColor) ? defaultBackgroundColor : bodyBackgroundColor : documentBackgroundColor : defaultBackgroundColor;
  };
  var html2canvas_esm_default = html2canvas;

  // src/screenshot.ts
  var PANEL_ID = "tracebug-dashboard-panel";
  var BTN_ID = "tracebug-dashboard-btn";
  var MAX_SCREENSHOTS = 50;
  var screenshotCounter = 0;
  var screenshots = [];
  function getScreenshots() {
    return [...screenshots];
  }
  function clearScreenshots() {
    screenshots.length = 0;
    screenshotCounter = 0;
  }
  async function captureScreenshot(lastEvent) {
    screenshotCounter++;
    const eventContext = lastEvent ? buildEventLabel(lastEvent) : "manual_capture";
    const filename = `${String(screenshotCounter).padStart(2, "0")}_${sanitizeFilename(eventContext)}.png`;
    const panel = document.getElementById(PANEL_ID);
    const btn = document.getElementById(BTN_ID);
    const root = document.getElementById("tracebug-root");
    if (root) root.style.display = "none";
    let dataUrl;
    let width = window.innerWidth;
    let height = window.innerHeight;
    try {
      const renderer = html2canvas_esm_default;
      if (renderer) {
        const canvas = await renderer(document.body, {
          useCORS: true,
          allowTaint: true,
          scale: 1,
          logging: false,
          width: window.innerWidth,
          height: window.innerHeight,
          windowWidth: window.innerWidth,
          windowHeight: window.innerHeight
        });
        dataUrl = canvas.toDataURL("image/png", 0.8);
        width = canvas.width;
        height = canvas.height;
      } else {
        dataUrl = await captureViaCanvas();
      }
    } catch (e2) {
      dataUrl = await captureViaCanvas();
    }
    if (root) root.style.display = "";
    const screenshot = {
      id: `ss_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      timestamp: Date.now(),
      dataUrl,
      filename,
      eventContext,
      page: window.location.pathname,
      width,
      height
    };
    screenshots.push(screenshot);
    if (screenshots.length > MAX_SCREENSHOTS) {
      screenshots.splice(0, screenshots.length - MAX_SCREENSHOTS);
    }
    return screenshot;
  }
  async function captureViaCanvas() {
    const canvas = document.createElement("canvas");
    canvas.width = 400;
    canvas.height = 200;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#1a1a2e";
    ctx.fillRect(0, 0, 400, 200);
    ctx.fillStyle = "#e0e0e0";
    ctx.font = "14px monospace";
    ctx.fillText("Screenshot (html2canvas unavailable)", 20, 40);
    ctx.fillStyle = "#888";
    ctx.font = "12px monospace";
    ctx.fillText(`Page: ${window.location.pathname}`, 20, 70);
    ctx.fillText(`Time: ${(/* @__PURE__ */ new Date()).toLocaleTimeString()}`, 20, 90);
    ctx.fillText(`Viewport: ${window.innerWidth}x${window.innerHeight}`, 20, 110);
    return canvas.toDataURL("image/png");
  }
  function buildEventLabel(event) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    switch (event.type) {
      case "click": {
        const el = event.data.element;
        const target = ((_a = el == null ? void 0 : el.text) == null ? void 0 : _a.trim()) || (el == null ? void 0 : el.id) || (el == null ? void 0 : el.ariaLabel) || (el == null ? void 0 : el.tag) || "element";
        return `click_${target}`;
      }
      case "input": {
        const name = ((_b = event.data.element) == null ? void 0 : _b.name) || ((_c = event.data.element) == null ? void 0 : _c.id) || "field";
        return `enter_${name}`;
      }
      case "select_change": {
        const name = ((_d = event.data.element) == null ? void 0 : _d.name) || "dropdown";
        const val = ((_e = event.data.element) == null ? void 0 : _e.selectedText) || "";
        return `select_${name}_${val}`;
      }
      case "form_submit":
        return `submit_${((_f = event.data.form) == null ? void 0 : _f.id) || "form"}`;
      case "route_change":
        return `navigate_${event.data.to || "page"}`;
      case "api_request":
        return `api_${(_g = event.data.request) == null ? void 0 : _g.method}_${(_h = event.data.request) == null ? void 0 : _h.statusCode}`;
      case "error":
      case "unhandled_rejection":
        return "error_occurred";
      default:
        return event.type;
    }
  }
  function downloadAllScreenshots() {
    for (const ss of screenshots) {
      downloadDataUrl(ss.dataUrl, ss.filename);
    }
  }
  function downloadDataUrl(dataUrl, filename) {
    const a2 = document.createElement("a");
    a2.href = dataUrl;
    a2.download = filename;
    document.body.appendChild(a2);
    a2.click();
    document.body.removeChild(a2);
  }
  function sanitizeFilename(str) {
    return str.toLowerCase().replace(/[^a-z0-9_]/g, "_").replace(/_+/g, "_").replace(/^_|_$/g, "").slice(0, 50);
  }

  // src/environment.ts
  function captureEnvironment() {
    const ua = navigator.userAgent;
    const browser = detectBrowser(ua);
    const os = detectOS(ua);
    const deviceType = detectDeviceType();
    const connection = getConnectionType();
    return {
      browser: browser.name,
      browserVersion: browser.version,
      os,
      viewport: `${window.innerWidth}x${window.innerHeight}`,
      screenResolution: `${screen.width}x${screen.height}`,
      language: navigator.language || "unknown",
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "unknown",
      userAgent: ua,
      url: window.location.href,
      deviceType,
      connectionType: connection,
      timestamp: Date.now()
    };
  }
  function detectBrowser(ua) {
    const tests = [
      ["Edge", /Edg(?:e|A|iOS)?\/(\d+[\d.]*)/],
      ["Opera", /(?:OPR|Opera)\/(\d+[\d.]*)/],
      ["Chrome", /Chrome\/(\d+[\d.]*)/],
      ["Firefox", /Firefox\/(\d+[\d.]*)/],
      ["Safari", /Version\/(\d+[\d.]*).*Safari/],
      ["IE", /(?:MSIE |Trident.*rv:)(\d+[\d.]*)/]
    ];
    for (const [name, regex] of tests) {
      const match = ua.match(regex);
      if (match) return { name, version: match[1] };
    }
    return { name: "Unknown", version: "" };
  }
  function detectOS(ua) {
    var _a, _b, _c, _d, _e;
    if (/Windows NT 10/.test(ua)) return "Windows 10/11";
    if (/Windows NT/.test(ua)) return "Windows";
    if (/Mac OS X (\d+[._]\d+)/.test(ua)) {
      const ver = (_b = (_a = ua.match(/Mac OS X (\d+[._]\d+)/)) == null ? void 0 : _a[1]) == null ? void 0 : _b.replace(/_/g, ".");
      return `macOS ${ver}`;
    }
    if (/CrOS/.test(ua)) return "Chrome OS";
    if (/Linux/.test(ua)) return "Linux";
    if (/Android (\d+[\d.]*)/.test(ua)) return `Android ${(_c = ua.match(/Android (\d+[\d.]*)/)) == null ? void 0 : _c[1]}`;
    if (/iPhone|iPad/.test(ua)) {
      const ver = (_e = (_d = ua.match(/OS (\d+_\d+)/)) == null ? void 0 : _d[1]) == null ? void 0 : _e.replace(/_/g, ".");
      return `iOS ${ver || ""}`;
    }
    return "Unknown OS";
  }
  function detectDeviceType() {
    const w = window.innerWidth;
    if (/Mobi|Android.*Mobile|iPhone/i.test(navigator.userAgent) || w < 768) return "mobile";
    if (/iPad|Android(?!.*Mobile)|Tablet/i.test(navigator.userAgent) || w >= 768 && w < 1024) return "tablet";
    return "desktop";
  }
  function getConnectionType() {
    const nav = navigator;
    if (nav.connection) {
      const c = nav.connection;
      return c.effectiveType || c.type || "unknown";
    }
    return "unknown";
  }

  // src/voice-recorder.ts
  var recognition = null;
  var isRecording = false;
  var transcript = "";
  var interimTranscript = "";
  var startTime = 0;
  var transcripts = [];
  var onTranscriptUpdate = null;
  var onStatusChange = null;
  function isVoiceSupported() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  }
  function startVoiceRecording(options) {
    var _a;
    if (isRecording) return false;
    if (!isVoiceSupported()) {
      (_a = options == null ? void 0 : options.onStatus) == null ? void 0 : _a.call(options, "error", "Speech recognition not supported in this browser.");
      return false;
    }
    onTranscriptUpdate = (options == null ? void 0 : options.onUpdate) || null;
    onStatusChange = (options == null ? void 0 : options.onStatus) || null;
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = navigator.language || "en-US";
    recognition.maxAlternatives = 1;
    transcript = "";
    interimTranscript = "";
    startTime = Date.now();
    recognition.onresult = (event) => {
      let final = "";
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          final += result[0].transcript;
        } else {
          interim += result[0].transcript;
        }
      }
      if (final) {
        transcript += (transcript ? " " : "") + cleanTranscript(final.trim());
      }
      interimTranscript = interim;
      onTranscriptUpdate == null ? void 0 : onTranscriptUpdate(transcript, interimTranscript);
    };
    recognition.onerror = (event) => {
      const errorMessages = {
        "not-allowed": "Microphone access denied. Please allow microphone permission.",
        "no-speech": "No speech detected. Try speaking louder.",
        "network": "Network error. Speech recognition requires an internet connection.",
        "audio-capture": "No microphone found. Please connect a microphone.",
        "aborted": "Recording was cancelled."
      };
      const message = errorMessages[event.error] || `Speech recognition error: ${event.error}`;
      if (event.error === "no-speech") return;
      isRecording = false;
      recognition = null;
      onStatusChange == null ? void 0 : onStatusChange("error", message);
      onStatusChange = null;
      onTranscriptUpdate = null;
    };
    recognition.onend = () => {
      if (isRecording) {
        try {
          recognition.start();
        } catch (e2) {
          isRecording = false;
          onStatusChange == null ? void 0 : onStatusChange("stopped");
        }
        return;
      }
      onStatusChange == null ? void 0 : onStatusChange("stopped");
    };
    try {
      recognition.start();
      isRecording = true;
      onStatusChange == null ? void 0 : onStatusChange("recording");
      return true;
    } catch (err) {
      onStatusChange == null ? void 0 : onStatusChange("error", err.message || "Failed to start voice recording.");
      return false;
    }
  }
  function stopVoiceRecording() {
    if (!isRecording && !recognition) return null;
    isRecording = false;
    onStatusChange == null ? void 0 : onStatusChange("stopped");
    if (recognition) {
      try {
        recognition.onend = null;
        recognition.stop();
      } catch (e2) {
      }
      recognition = null;
    }
    if (interimTranscript.trim()) {
      transcript += (transcript ? " " : "") + cleanTranscript(interimTranscript.trim());
      interimTranscript = "";
    }
    if (!transcript.trim()) return null;
    const result = {
      id: `voice_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      timestamp: startTime,
      text: transcript.trim(),
      duration: Date.now() - startTime
    };
    transcripts.push(result);
    onTranscriptUpdate = null;
    onStatusChange = null;
    return result;
  }
  function isVoiceRecording() {
    return isRecording;
  }
  function getVoiceTranscripts() {
    return [...transcripts];
  }
  function clearVoiceTranscripts() {
    transcripts.length = 0;
  }
  function cleanTranscript(text) {
    if (!text) return text;
    text = text.charAt(0).toUpperCase() + text.slice(1);
    if (!/[.!?]$/.test(text.trim())) {
      text = text.trim() + ".";
    }
    text = text.replace(/\bperiod\b/gi, ".").replace(/\bcomma\b/gi, ",").replace(/\bquestion mark\b/gi, "?").replace(/\bexclamation mark\b/gi, "!").replace(/\bnew line\b/gi, "\n").replace(/\s+/g, " ").replace(/\s+([.,!?])/g, "$1").replace(/([.!?])\s+([a-z])/g, (_m, p, c) => `${p} ${c.toUpperCase()}`);
    return text;
  }

  // src/title-generator.ts
  function generateBugTitle(session) {
    var _a;
    const events = session.events;
    const errorEvents = events.filter((e2) => e2.type === "error" || e2.type === "unhandled_rejection");
    const userActions = events.filter(
      (e2) => ["click", "input", "select_change", "form_submit", "route_change"].includes(e2.type)
    );
    if (errorEvents.length === 0) {
      return generateFlowTitle(userActions, events);
    }
    const errorMsg = ((_a = errorEvents[0].data.error) == null ? void 0 : _a.message) || session.errorMessage || "Unknown error";
    const errorType = classifyError(errorMsg);
    const lastAction = userActions.length > 0 ? userActions[userActions.length - 1] : null;
    const page = errorEvents[0].page || "";
    const context = getActionContext(lastAction);
    const pageName = friendlyPage(page);
    if (context && pageName) {
      return `${pageName}: ${context} Fails \u2014 ${errorType}`;
    }
    if (context) {
      return `${context} Fails Due to ${errorType}`;
    }
    if (pageName) {
      return `${errorType} on ${pageName}`;
    }
    return `${errorType}: ${truncate(errorMsg, 60)}`;
  }
  function generateFlowSummary(events) {
    const userActions = events.filter(
      (e2) => ["click", "input", "select_change", "form_submit", "route_change"].includes(e2.type)
    );
    if (userActions.length === 0) return "No user interactions recorded";
    const parts = [];
    for (const ev of userActions.slice(-5)) {
      parts.push(describeAction(ev));
    }
    return parts.join(" \u2192 ");
  }
  function generateFlowTitle(userActions, allEvents) {
    const failedApis = allEvents.filter(
      (e2) => {
        var _a, _b;
        return e2.type === "api_request" && (((_a = e2.data.request) == null ? void 0 : _a.statusCode) >= 400 || ((_b = e2.data.request) == null ? void 0 : _b.statusCode) === 0);
      }
    );
    if (failedApis.length > 0) {
      const api = failedApis[0].data.request;
      const lastAction = userActions.length > 0 ? userActions[userActions.length - 1] : null;
      const context = getActionContext(lastAction);
      return context ? `${context} \u2014 API ${api == null ? void 0 : api.method} Returns ${(api == null ? void 0 : api.statusCode) || "Network Error"}` : `API Failure: ${api == null ? void 0 : api.method} ${shortenUrl2(api == null ? void 0 : api.url)} Returns ${(api == null ? void 0 : api.statusCode) || "Network Error"}`;
    }
    if (userActions.length === 0) return "Empty Session \u2014 No User Interactions";
    const lastActions = userActions.slice(-3);
    const parts = lastActions.map((a2) => describeAction(a2));
    return `Session: ${parts.join(" \u2192 ")}`;
  }
  function getActionContext(event) {
    var _a, _b, _c, _d, _e, _f;
    if (!event) return "";
    switch (event.type) {
      case "click": {
        const el = event.data.element;
        const text = ((_a = el == null ? void 0 : el.text) == null ? void 0 : _a.trim()) || (el == null ? void 0 : el.ariaLabel) || "";
        if (text && text.length < 40) return `"${text}" Action`;
        if (el == null ? void 0 : el.id) return `${capitalize2(el.id.replace(/[-_]/g, " "))} Action`;
        return "Button Click";
      }
      case "input": {
        const name = ((_b = event.data.element) == null ? void 0 : _b.name) || ((_c = event.data.element) == null ? void 0 : _c.id) || "";
        return name ? `${capitalize2(name.replace(/[-_]/g, " "))} Input` : "Form Input";
      }
      case "select_change": {
        const name = ((_d = event.data.element) == null ? void 0 : _d.name) || "";
        const value = ((_e = event.data.element) == null ? void 0 : _e.selectedText) || "";
        if (name && value) return `Setting ${capitalize2(name)} to "${value}"`;
        return "Dropdown Selection";
      }
      case "form_submit": {
        const formId = ((_f = event.data.form) == null ? void 0 : _f.id) || "";
        return formId ? `${capitalize2(formId.replace(/[-_]/g, " "))} Submission` : "Form Submission";
      }
      case "route_change":
        return `Navigation to ${friendlyPage(event.data.to || "")}`;
      default:
        return "";
    }
  }
  function describeAction(ev) {
    var _a, _b, _c, _d, _e;
    switch (ev.type) {
      case "click": {
        const text = ((_b = (_a = ev.data.element) == null ? void 0 : _a.text) == null ? void 0 : _b.trim()) || ((_c = ev.data.element) == null ? void 0 : _c.id) || "element";
        return `Click "${truncate(text, 20)}"`;
      }
      case "input":
        return `Type in "${((_d = ev.data.element) == null ? void 0 : _d.name) || "field"}"`;
      case "select_change":
        return `Select "${((_e = ev.data.element) == null ? void 0 : _e.selectedText) || "option"}"`;
      case "form_submit":
        return "Submit Form";
      case "route_change":
        return `Go to ${ev.data.to || "/"}`;
      default:
        return ev.type;
    }
  }
  function classifyError(msg) {
    const m = msg.toLowerCase();
    if (m.includes("typeerror") || m.includes("cannot read prop") || m.includes("is not a function"))
      return "TypeError";
    if (m.includes("referenceerror") || m.includes("is not defined"))
      return "ReferenceError";
    if (m.includes("syntaxerror"))
      return "SyntaxError";
    if (m.includes("rangeerror"))
      return "RangeError";
    if (m.includes("networkerror") || m.includes("failed to fetch") || m.includes("network"))
      return "Network Error";
    if (m.includes("timeout") || m.includes("timed out"))
      return "Timeout Error";
    if (m.includes("aborted"))
      return "Aborted Request";
    if (m.includes("permission") || m.includes("cors"))
      return "Permission Error";
    const typeMatch = msg.match(/^(\w+Error):/);
    if (typeMatch) return typeMatch[1];
    return "Runtime Error";
  }
  function friendlyPage(path) {
    if (!path || path === "/") return "Home Page";
    const parts = path.split("/").filter(Boolean);
    return parts.map((p) => capitalize2(p)).join(" ") + " Page";
  }
  function capitalize2(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
  function truncate(str, len) {
    return str.length > len ? str.slice(0, len) + "..." : str;
  }
  function shortenUrl2(url) {
    if (!url) return "";
    try {
      return new URL(url, window.location.origin).pathname;
    } catch (e2) {
      return url.slice(0, 40);
    }
  }

  // src/timeline-builder.ts
  function buildTimeline(events) {
    var _a, _b;
    if (events.length === 0) return [];
    const startTs = events[0].timestamp;
    const timeline = [];
    let lastDescription = "";
    for (const ev of events) {
      const elapsed = formatElapsed(ev.timestamp - startTs);
      const isError = ["error", "unhandled_rejection", "console_error"].includes(ev.type);
      const isApiError = ev.type === "api_request" && (((_a = ev.data.request) == null ? void 0 : _a.statusCode) >= 400 || ((_b = ev.data.request) == null ? void 0 : _b.statusCode) === 0);
      const description = describeTimelineEvent(ev);
      const entryKey = `${ev.type}:${description}`;
      if (entryKey === lastDescription) continue;
      lastDescription = entryKey;
      timeline.push({
        timestamp: ev.timestamp,
        elapsed,
        type: ev.type,
        description,
        isError: isError || isApiError,
        page: ev.page
      });
    }
    return timeline;
  }
  function formatTimelineText(entries) {
    if (entries.length === 0) return "(empty session)";
    const lines = [];
    for (const entry of entries) {
      const marker = entry.isError ? "!!" : "  ";
      lines.push(`${entry.elapsed} ${marker} ${entry.type.padEnd(18)} ${entry.description}`);
    }
    return lines.join("\n");
  }
  function describeTimelineEvent(ev) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
    switch (ev.type) {
      case "click": {
        const el = ev.data.element;
        let target = ((_a = el == null ? void 0 : el.text) == null ? void 0 : _a.trim()) || (el == null ? void 0 : el.ariaLabel) || (el == null ? void 0 : el.id) || (el == null ? void 0 : el.tag) || "element";
        if (target.includes("\n")) target = target.split("\n")[0].trim();
        return `click "${target.slice(0, 50)}"`;
      }
      case "input": {
        const name = ((_b = ev.data.element) == null ? void 0 : _b.name) || ((_c = ev.data.element) == null ? void 0 : _c.id) || "field";
        const val = (_d = ev.data.element) == null ? void 0 : _d.value;
        if (val && val !== "[REDACTED]") return `input "${name}" = "${val.slice(0, 30)}"`;
        return `input "${name}"`;
      }
      case "select_change": {
        const name = ((_e = ev.data.element) == null ? void 0 : _e.name) || "dropdown";
        return `select "${name}" \u2192 "${((_f = ev.data.element) == null ? void 0 : _f.selectedText) || ""}"`;
      }
      case "form_submit": {
        const id = ((_g = ev.data.form) == null ? void 0 : _g.id) || "form";
        return `submit ${id} (${((_h = ev.data.form) == null ? void 0 : _h.fieldCount) || 0} fields)`;
      }
      case "route_change":
        return `${ev.data.from || "/"} \u2192 ${ev.data.to || "/"}`;
      case "api_request": {
        const r = ev.data.request;
        const status = (r == null ? void 0 : r.statusCode) === 0 ? "NETWORK_ERR" : String(r == null ? void 0 : r.statusCode);
        return `${r == null ? void 0 : r.method} ${shortenUrl3(r == null ? void 0 : r.url)} \u2192 ${status} (${r == null ? void 0 : r.durationMs}ms)`;
      }
      case "error":
      case "unhandled_rejection":
        return ((_i = ev.data.error) == null ? void 0 : _i.message) || "Unknown error";
      case "console_error":
        return (((_j = ev.data.error) == null ? void 0 : _j.message) || "").slice(0, 80);
      default:
        return JSON.stringify(ev.data).slice(0, 60);
    }
  }
  function formatElapsed(ms) {
    const totalSeconds = Math.floor(ms / 1e3);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    const millis = Math.floor(ms % 1e3 / 10);
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}.${String(millis).padStart(2, "0")}`;
  }
  function shortenUrl3(url) {
    if (!url) return "";
    try {
      return new URL(url, window.location.origin).pathname.slice(0, 40);
    } catch (e2) {
      return (url || "").slice(0, 40);
    }
  }

  // src/report-builder.ts
  function buildReport(session, extraScreenshots) {
    const environment = session.environment || captureEnvironment();
    let steps = session.reproSteps || "";
    if (!steps && session.events.length > 0) {
      const errorMsg = session.errorMessage || "Issue reported by tester";
      const result = generateReproSteps(session.events, errorMsg, session.errorStack || void 0);
      steps = result.reproSteps;
    }
    const seenErrors = /* @__PURE__ */ new Set();
    const consoleErrors = session.events.filter((e2) => ["error", "unhandled_rejection", "console_error"].includes(e2.type)).map((e2) => {
      var _a, _b;
      return {
        message: ((_a = e2.data.error) == null ? void 0 : _a.message) || "",
        stack: (_b = e2.data.error) == null ? void 0 : _b.stack,
        timestamp: e2.timestamp
      };
    }).filter((e2) => {
      if (seenErrors.has(e2.message)) return false;
      seenErrors.add(e2.message);
      return true;
    });
    const networkErrors = session.events.filter((e2) => {
      var _a, _b;
      return e2.type === "api_request" && (((_a = e2.data.request) == null ? void 0 : _a.statusCode) >= 400 || ((_b = e2.data.request) == null ? void 0 : _b.statusCode) === 0);
    }).map((e2) => {
      var _a, _b, _c, _d;
      return {
        method: ((_a = e2.data.request) == null ? void 0 : _a.method) || "GET",
        url: ((_b = e2.data.request) == null ? void 0 : _b.url) || "",
        status: ((_c = e2.data.request) == null ? void 0 : _c.statusCode) || 0,
        duration: ((_d = e2.data.request) == null ? void 0 : _d.durationMs) || 0,
        timestamp: e2.timestamp
      };
    });
    const screenshots2 = [...getScreenshots(), ...extraScreenshots || []];
    const timeline = buildTimeline(session.events);
    const voiceTranscripts = getVoiceTranscripts();
    const title = generateBugTitle(session);
    return {
      title,
      steps,
      environment,
      consoleErrors,
      networkErrors,
      annotations: session.annotations || [],
      screenshots: screenshots2,
      timeline,
      voiceTranscripts,
      session,
      generatedAt: Date.now()
    };
  }

  // src/github-issue.ts
  function generateGitHubIssue(report) {
    const env = report.environment;
    let md = `## ${report.title}

`;
    md += `**Environment:** ${env.browser} ${env.browserVersion} \xB7 ${env.os} \xB7 ${env.viewport} \xB7 ${env.deviceType}
`;
    md += `**URL:** ${env.url}

`;
    md += `### Steps to Reproduce

`;
    if (report.steps) {
      md += `${report.steps}

`;
    } else {
      md += `_No steps recorded_

`;
    }
    if (report.annotations.length > 0) {
      md += `### Tester Notes

`;
      for (const note of report.annotations) {
        md += `- **[${note.severity.toUpperCase()}]** ${note.text}
`;
        if (note.expected) md += `  - **Expected:** ${note.expected}
`;
        if (note.actual) md += `  - **Actual:** ${note.actual}
`;
      }
      md += `
`;
    }
    const hasTesterResult = report.annotations.some((a2) => a2.actual);
    if (!hasTesterResult && report.consoleErrors.length > 0) {
      md += `### Error

`;
      md += `\`${report.consoleErrors[0].message}\`

`;
    }
    if (report.consoleErrors.length > 0) {
      md += `### Console Errors

`;
      md += `\`\`\`
`;
      for (const err of report.consoleErrors.slice(0, 3)) {
        md += `${err.message}
`;
        if (err.stack) {
          const stackLines = err.stack.split("\n").filter((l) => l.trim().startsWith("at ")).slice(0, 3);
          if (stackLines.length > 0) md += `${stackLines.join("\n")}
`;
        }
      }
      md += `\`\`\`

`;
    }
    if (report.networkErrors.length > 0) {
      md += `### Failed Requests

`;
      md += `| Method | URL | Status | Duration |
`;
      md += `|--------|-----|--------|----------|
`;
      for (const req of report.networkErrors) {
        const status = req.status === 0 ? "Network Error" : `${req.status}`;
        const url = req.url.length > 60 ? req.url.slice(0, 57) + "..." : req.url;
        md += `| ${req.method} | \`${url}\` | ${status} | ${req.duration}ms |
`;
      }
      md += `
`;
    }
    if (report.voiceTranscripts && report.voiceTranscripts.length > 0) {
      md += `### Bug Description (Voice)

`;
      for (const vt of report.voiceTranscripts) {
        md += `> ${vt.text}

`;
      }
    }
    if (report.screenshots.length > 0) {
      md += `### Screenshots

`;
      md += `> Drag and drop the downloaded screenshot files below:

`;
      for (const ss of report.screenshots) {
        md += `- \`${ss.filename}\`
`;
      }
      md += `
`;
    }
    const significantTimeline = report.timeline.filter(
      (e2) => e2.type !== "api_request" || e2.isError
    );
    if (significantTimeline.length > 0) {
      md += `<details>
<summary>Session Timeline (${significantTimeline.length} events)</summary>

`;
      md += `\`\`\`
`;
      md += formatTimelineText(significantTimeline);
      md += `
\`\`\`

`;
      md += `</details>

`;
    }
    md += `---
`;
    md += `_[TraceBug SDK](https://www.npmjs.com/package/tracebug-sdk) \xB7 Session: \`${report.session.sessionId.slice(0, 8)}\`_
`;
    return md;
  }

  // src/jira-issue.ts
  function generateJiraTicket(report) {
    const env = report.environment;
    const priority = determinePriority(report);
    const labels = ["tracebug", "bug"];
    if (report.consoleErrors.length > 0) labels.push("has-errors");
    if (report.networkErrors.length > 0) labels.push("api-failure");
    const envStr = `${env.browser} ${env.browserVersion} / ${env.os} / ${env.viewport} / ${env.deviceType}`;
    let desc = "";
    desc += `h3. Steps to Reproduce
`;
    if (report.steps) {
      desc += `{noformat}
${report.steps}
{noformat}

`;
    }
    if (report.annotations.length > 0) {
      desc += `h3. Tester Notes
`;
      for (const note of report.annotations) {
        desc += `* *[${note.severity.toUpperCase()}]* ${note.text}
`;
        if (note.expected) desc += `** *Expected:* ${note.expected}
`;
        if (note.actual) desc += `** *Actual:* ${note.actual}
`;
      }
      desc += `
`;
    }
    const hasTesterResult = report.annotations.some((a2) => a2.actual);
    if (!hasTesterResult && report.consoleErrors.length > 0) {
      desc += `h3. Actual Result
Application throws error:
{code}${report.consoleErrors[0].message}{code}

`;
    }
    if (report.consoleErrors.length > 0) {
      desc += `h3. Console Errors
{code}
`;
      for (const err of report.consoleErrors.slice(0, 3)) {
        desc += `${err.message}
`;
        if (err.stack) {
          const stackLines = err.stack.split("\n").filter((l) => l.trim().startsWith("at ")).slice(0, 3);
          if (stackLines.length > 0) desc += `${stackLines.join("\n")}
`;
        }
      }
      desc += `{code}

`;
    }
    if (report.networkErrors.length > 0) {
      desc += `h3. Failed Requests
`;
      desc += `||Method||URL||Status||Duration||
`;
      for (const req of report.networkErrors) {
        const status = req.status === 0 ? "Network Error" : String(req.status);
        desc += `|${req.method}|${req.url.slice(0, 80)}|${status}|${req.duration}ms|
`;
      }
      desc += `
`;
    }
    if (report.voiceTranscripts && report.voiceTranscripts.length > 0) {
      desc += `h3. Bug Description (Voice)
`;
      desc += `{quote}
`;
      for (const vt of report.voiceTranscripts) {
        desc += `${vt.text}
`;
      }
      desc += `{quote}

`;
    }
    if (report.screenshots.length > 0) {
      desc += `h3. Screenshots
`;
      desc += `_Attach the downloaded screenshot files:_
`;
      for (const ss of report.screenshots) {
        desc += `* !${ss.filename}|thumbnail!
`;
      }
      desc += `
`;
    }
    const significantTimeline = report.timeline.filter(
      (e2) => e2.type !== "api_request" || e2.isError
    );
    if (significantTimeline.length > 0) {
      desc += `h3. Session Timeline
{code}
`;
      desc += formatTimelineText(significantTimeline);
      desc += `
{code}

`;
    }
    desc += `h3. Environment
`;
    desc += `* *Browser:* ${env.browser} ${env.browserVersion}
`;
    desc += `* *OS:* ${env.os}
`;
    desc += `* *Viewport:* ${env.viewport}
`;
    desc += `* *Device:* ${env.deviceType}
`;
    desc += `* *URL:* ${env.url}

`;
    desc += `----
_Generated by TraceBug SDK \xB7 Session: ${report.session.sessionId.slice(0, 8)}_
`;
    return {
      summary: report.title,
      description: desc,
      environment: envStr,
      stepsToReproduce: report.steps || "",
      priority,
      labels
    };
  }
  function determinePriority(report) {
    const hasCriticalError = report.consoleErrors.some(
      (e2) => /TypeError|ReferenceError|SyntaxError/i.test(e2.message)
    );
    if (hasCriticalError) return "Highest";
    const hasServerError = report.networkErrors.some((r) => r.status >= 500);
    if (hasServerError) return "High";
    if (report.networkErrors.length > 0) return "Medium";
    if (report.consoleErrors.length > 0) return "Low";
    if (report.annotations.some((a2) => a2.severity === "critical" || a2.severity === "major")) return "Medium";
    return "Low";
  }

  // src/pdf-generator.ts
  function generatePdfReport(report) {
    const html = buildPdfHtml(report);
    const printWindow = window.open("", "_blank", "width=900,height=700");
    if (!printWindow) {
      downloadAsHtml(html, `tracebug-report-${report.session.sessionId.slice(0, 8)}.html`);
      return;
    }
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.onload = () => {
      setTimeout(() => {
        printWindow.print();
      }, 300);
    };
  }
  function downloadPdfAsHtml(report) {
    const html = buildPdfHtml(report);
    downloadAsHtml(html, `tracebug-report-${report.session.sessionId.slice(0, 8)}.html`);
  }
  function buildPdfHtml(report) {
    const env = report.environment;
    const session = report.session;
    const hasError = report.consoleErrors.length > 0;
    let html = `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<title>TraceBug Report \u2014 ${escapeHtml(report.title)}</title>
<style>
  @page { margin: 20mm 15mm; size: A4; }
  @media print {
    body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .no-print { display: none !important; }
    .page-break { page-break-before: always; }
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 12px; color: #1a1a2e; line-height: 1.5; padding: 24px; max-width: 800px; margin: 0 auto; }
  h1 { font-size: 20px; color: #0f0f1a; margin-bottom: 4px; border-bottom: 2px solid #ef4444; padding-bottom: 8px; }
  h2 { font-size: 15px; color: #1a1a2e; margin: 20px 0 8px; padding-bottom: 4px; border-bottom: 1px solid #e0e0e0; }
  .meta { color: #666; font-size: 11px; margin-bottom: 16px; }
  .badge { display: inline-block; font-size: 10px; padding: 2px 8px; border-radius: 4px; font-weight: 600; }
  .badge-error { background: #fee2e2; color: #dc2626; }
  .badge-success { background: #dcfce7; color: #16a34a; }
  .badge-warn { background: #fef3c7; color: #d97706; }
  .env-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin: 12px 0; }
  .env-item { background: #f8f9fa; border: 1px solid #e0e0e0; border-radius: 6px; padding: 8px; }
  .env-label { font-size: 9px; color: #888; text-transform: uppercase; letter-spacing: 0.5px; }
  .env-value { font-size: 13px; color: #1a1a2e; margin-top: 2px; }
  .steps { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 14px; margin: 12px 0; }
  .steps pre { white-space: pre-wrap; font-size: 12px; line-height: 1.8; font-family: inherit; }
  .error-box { background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 14px; margin: 12px 0; }
  .error-msg { color: #dc2626; font-size: 13px; font-weight: 500; margin-bottom: 6px; }
  .stack { font-family: monospace; font-size: 10px; color: #666; white-space: pre-wrap; max-height: 150px; overflow: auto; background: #fff5f5; padding: 8px; border-radius: 4px; margin-top: 6px; }
  .network-table { width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 11px; }
  .network-table th { background: #f1f5f9; padding: 6px 8px; text-align: left; font-weight: 600; border-bottom: 2px solid #e2e8f0; }
  .network-table td { padding: 5px 8px; border-bottom: 1px solid #f1f5f9; }
  .network-table tr.error td { background: #fef2f2; }
  .timeline { margin: 12px 0; }
  .timeline-item { display: flex; gap: 12px; padding: 6px 0; border-bottom: 1px solid #f8f9fa; font-size: 11px; }
  .timeline-time { color: #888; font-family: monospace; min-width: 70px; }
  .timeline-type { min-width: 90px; font-weight: 600; }
  .timeline-desc { color: #444; flex: 1; }
  .timeline-item.error { background: #fef2f2; }
  .timeline-item.error .timeline-type { color: #dc2626; }
  .annotation { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 6px; padding: 10px; margin: 6px 0; }
  .annotation-severity { font-size: 9px; font-weight: 700; text-transform: uppercase; }
  .screenshot-list { margin: 8px 0; }
  .screenshot-item { margin: 12px 0; }
  .screenshot-item img { max-width: 100%; border: 1px solid #e0e0e0; border-radius: 6px; }
  .screenshot-label { font-size: 10px; color: #888; margin-top: 4px; }
  .footer { text-align: center; color: #888; font-size: 10px; margin-top: 24px; padding-top: 12px; border-top: 1px solid #e0e0e0; }
  .print-btn { display: block; margin: 16px auto; padding: 10px 24px; background: #3b82f6; color: white; border: none; border-radius: 6px; font-size: 14px; cursor: pointer; }
  .print-btn:hover { background: #2563eb; }
</style></head><body>`;
    html += `<button class="print-btn no-print" onclick="window.print()">Save as PDF</button>
`;
    html += `<h1>TraceBug Bug Report</h1>
`;
    html += `<div class="meta">${escapeHtml(report.title)} \xB7 ${new Date(report.generatedAt).toLocaleString()}</div>
`;
    html += `<h2>Environment</h2>
`;
    html += `<div class="env-grid">
    <div class="env-item"><div class="env-label">Browser</div><div class="env-value">${escapeHtml(env.browser)} ${escapeHtml(env.browserVersion)}</div></div>
    <div class="env-item"><div class="env-label">OS</div><div class="env-value">${escapeHtml(env.os)}</div></div>
    <div class="env-item"><div class="env-label">Viewport</div><div class="env-value">${escapeHtml(env.viewport)}</div></div>
    <div class="env-item"><div class="env-label">Device</div><div class="env-value">${env.deviceType}</div></div>
    <div class="env-item"><div class="env-label">Connection</div><div class="env-value">${escapeHtml(env.connectionType)}</div></div>
    <div class="env-item"><div class="env-label">URL</div><div class="env-value" style="word-break:break-all;font-size:10px">${escapeHtml(env.url)}</div></div>
  </div>
`;
    html += `<h2>Steps to Reproduce</h2>
`;
    if (report.steps) {
      html += `<div class="steps"><pre>${escapeHtml(report.steps)}</pre></div>
`;
    } else {
      html += `<p style="color:#888">No steps recorded</p>
`;
    }
    if (report.annotations.length > 0) {
      html += `<h2>Tester Notes</h2>
`;
      for (const note of report.annotations) {
        const severityColor = note.severity === "critical" ? "#dc2626" : note.severity === "major" ? "#d97706" : note.severity === "minor" ? "#2563eb" : "#666";
        html += `<div class="annotation">
        <span class="annotation-severity" style="color:${severityColor}">${note.severity}</span>
        <div style="margin-top:4px">${escapeHtml(note.text)}</div>
        ${note.expected ? `<div style="margin-top:4px"><strong>Expected:</strong> ${escapeHtml(note.expected)}</div>` : ""}
        ${note.actual ? `<div style="margin-top:2px"><strong>Actual:</strong> ${escapeHtml(note.actual)}</div>` : ""}
      </div>
`;
      }
    }
    if (report.voiceTranscripts && report.voiceTranscripts.length > 0) {
      html += `<h2>Bug Description (Voice)</h2>
`;
      for (const vt of report.voiceTranscripts) {
        html += `<div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:14px;margin:8px 0;font-style:italic;color:#92400e">
        <span style="font-size:16px;margin-right:6px">\u{1F3A4}</span> ${escapeHtml(vt.text)}
      </div>
`;
      }
    }
    if (report.consoleErrors.length > 0) {
      html += `<h2>Console Errors <span class="badge badge-error">${report.consoleErrors.length}</span></h2>
`;
      for (const err of report.consoleErrors) {
        html += `<div class="error-box">
        <div class="error-msg">${escapeHtml(err.message)}</div>
        ${err.stack ? `<div class="stack">${escapeHtml(err.stack)}</div>` : ""}
      </div>
`;
      }
    }
    if (report.networkErrors.length > 0) {
      html += `<h2>Failed Network Requests <span class="badge badge-error">${report.networkErrors.length}</span></h2>
`;
      html += `<table class="network-table">
      <thead><tr><th>Method</th><th>URL</th><th>Status</th><th>Duration</th></tr></thead>
      <tbody>
`;
      for (const req of report.networkErrors) {
        const status = req.status === 0 ? "Network Error" : String(req.status);
        html += `<tr class="error"><td>${req.method}</td><td style="word-break:break-all">${escapeHtml(req.url.slice(0, 80))}</td><td>${status}</td><td>${req.duration}ms</td></tr>
`;
      }
      html += `</tbody></table>
`;
    }
    if (report.screenshots.length > 0) {
      html += `<h2>Screenshots</h2>
<div class="screenshot-list">
`;
      for (const ss of report.screenshots) {
        html += `<div class="screenshot-item">
        <div class="screenshot-label">${escapeHtml(ss.filename)} \u2014 ${escapeHtml(ss.eventContext)}</div>
        <img src="${ss.dataUrl}" alt="${escapeHtml(ss.filename)}" />
      </div>
`;
      }
      html += `</div>
`;
    }
    if (report.timeline.length > 0) {
      html += `<h2>Session Timeline (${report.timeline.length} events)</h2>
<div class="timeline">
`;
      for (const entry of report.timeline) {
        const errClass = entry.isError ? " error" : "";
        html += `<div class="timeline-item${errClass}">
        <span class="timeline-time">${escapeHtml(entry.elapsed)}</span>
        <span class="timeline-type">${escapeHtml(entry.type)}</span>
        <span class="timeline-desc">${escapeHtml(entry.description)}</span>
      </div>
`;
      }
      html += `</div>
`;
    }
    html += `<div class="footer">Generated by TraceBug SDK \xB7 Session: ${session.sessionId.slice(0, 8)} \xB7 ${new Date(report.generatedAt).toLocaleString()}</div>
`;
    html += `</body></html>`;
    return html;
  }
  function downloadAsHtml(html, filename) {
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a2 = document.createElement("a");
    a2.href = url;
    a2.download = filename;
    document.body.appendChild(a2);
    a2.click();
    document.body.removeChild(a2);
    URL.revokeObjectURL(url);
  }
  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // src/dashboard.ts
  var PANEL_ID2 = "tracebug-dashboard-panel";
  var BTN_ID2 = "tracebug-dashboard-btn";
  var _isRecording = true;
  var _onToggleRecording = null;
  function setRecordingState(isRecording2, onToggle) {
    _isRecording = isRecording2;
    _onToggleRecording = onToggle;
  }
  function updateRecordingState(isRecording2) {
    _isRecording = isRecording2;
    const indicator = document.getElementById("bt-rec-indicator");
    if (indicator) {
      indicator.style.background = isRecording2 ? "#22c55e" : "#ef4444";
      indicator.title = isRecording2 ? "Recording" : "Paused";
    }
    const recBtn = document.getElementById("bt-rec-toggle");
    if (recBtn) {
      recBtn.textContent = isRecording2 ? "\u23F8 Pause" : "\u25B6 Record";
      recBtn.style.color = isRecording2 ? "#fbbf24" : "#22c55e";
      recBtn.style.borderColor = isRecording2 ? "#fbbf2444" : "#22c55e44";
      recBtn.style.background = isRecording2 ? "#fbbf2422" : "#22c55e22";
    }
  }
  function mountDashboard() {
    if (document.getElementById(BTN_ID2)) return () => {
    };
    const style = document.createElement("style");
    style.id = "tracebug-styles";
    style.textContent = `
    #tracebug-root {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 0 !important;
      height: 0 !important;
      overflow: visible !important;
      z-index: 2147483647 !important;
      pointer-events: none !important;
      isolation: isolate !important;
    }
    #tracebug-root * {
      pointer-events: auto;
    }
    #${BTN_ID2} {
      position: fixed !important;
      bottom: 20px !important;
      right: 20px !important;
      z-index: 2147483647 !important;
      width: 48px !important;
      height: 48px !important;
      border-radius: 50% !important;
      border: 2px solid #ef4444 !important;
      background: #1a1a2e !important;
      color: #ef4444 !important;
      font-size: 22px !important;
      cursor: pointer !important;
      box-shadow: 0 4px 20px rgba(0,0,0,0.5) !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      transition: right 0.3s ease, transform 0.2s !important;
      font-family: system-ui, sans-serif !important;
      padding: 0 !important;
      margin: 0 !important;
      outline: none !important;
    }
    #${BTN_ID2}:hover {
      transform: scale(1.1) !important;
    }
    #${BTN_ID2}.bt-panel-open {
      right: 484px !important;
    }
    #${PANEL_ID2} {
      position: fixed !important;
      top: 0 !important;
      width: 470px !important;
      height: 100vh !important;
      z-index: 2147483647 !important;
      background: #0f0f1a !important;
      border-left: 1px solid #2a2a3e !important;
      color: #e0e0e0 !important;
      font-family: 'SF Mono', Consolas, monospace, system-ui, sans-serif !important;
      font-size: 13px !important;
      overflow: hidden !important;
      transition: right 0.3s ease !important;
      display: flex !important;
      flex-direction: column !important;
      box-shadow: -4px 0 30px rgba(0,0,0,0.6) !important;
    }
  `;
    document.head.appendChild(style);
    const root = document.createElement("div");
    root.id = "tracebug-root";
    const btn = document.createElement("button");
    btn.id = BTN_ID2;
    btn.innerHTML = `<svg width="22" height="22" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="tb-p" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#9B7DFF"/><stop offset="50%" stop-color="#7B61FF"/><stop offset="100%" stop-color="#00E5FF"/></linearGradient><linearGradient id="tb-s" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="#00E5FF" stop-opacity="0"/><stop offset="35%" stop-color="#00E5FF" stop-opacity="0.9"/><stop offset="65%" stop-color="#7B61FF" stop-opacity="0.9"/><stop offset="100%" stop-color="#7B61FF" stop-opacity="0"/></linearGradient></defs><path d="M48 20 L66 30 L66 52 L48 62 L30 52 L30 30 Z" fill="url(#tb-p)" opacity="0.18"/><path d="M48 20 L66 30 L66 52 L48 62 L30 52 L30 30 Z" fill="none" stroke="url(#tb-p)" stroke-width="2.5"/><rect x="22" y="39" width="52" height="3" rx="1.5" fill="url(#tb-s)" opacity="0.95"/><line x1="34" y1="29" x2="21" y2="16" stroke="#9B7DFF" stroke-width="2.5" stroke-linecap="round"/><circle cx="21" cy="16" r="3.5" fill="#9B7DFF"/><circle cx="21" cy="16" r="1.4" fill="white"/><line x1="62" y1="29" x2="75" y2="16" stroke="#00E5FF" stroke-width="2.5" stroke-linecap="round"/><circle cx="75" cy="16" r="3.5" fill="#00E5FF"/><circle cx="75" cy="16" r="1.4" fill="white"/><line x1="30" y1="36" x2="17" y2="32" stroke="#7B61FF" stroke-width="2" stroke-linecap="round" opacity="0.8"/><line x1="30" y1="43" x2="15" y2="43" stroke="#7B61FF" stroke-width="2" stroke-linecap="round" opacity="0.8"/><line x1="30" y1="50" x2="17" y2="54" stroke="#7B61FF" stroke-width="2" stroke-linecap="round" opacity="0.8"/><line x1="66" y1="36" x2="79" y2="32" stroke="#00E5FF" stroke-width="2" stroke-linecap="round" opacity="0.8"/><line x1="66" y1="43" x2="81" y2="43" stroke="#00E5FF" stroke-width="2" stroke-linecap="round" opacity="0.8"/><line x1="66" y1="50" x2="79" y2="54" stroke="#00E5FF" stroke-width="2" stroke-linecap="round" opacity="0.8"/><circle cx="48" cy="41" r="5" fill="url(#tb-p)"/><circle cx="48" cy="41" r="2.2" fill="white"/><circle cx="41" cy="34" r="2.5" fill="#00E5FF" opacity="0.9"/><circle cx="41" cy="34" r="1" fill="white"/><circle cx="55" cy="34" r="2.5" fill="#9B7DFF" opacity="0.9"/><circle cx="55" cy="34" r="1" fill="white"/></svg>`;
    btn.title = "TraceBug AI Dashboard";
    const panel = document.createElement("div");
    panel.id = PANEL_ID2;
    panel.style.right = "-480px";
    let isOpen = false;
    btn.onclick = () => {
      isOpen = !isOpen;
      panel.style.right = isOpen ? "0" : "-480px";
      btn.innerHTML = isOpen ? `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>` : `<svg width="22" height="22" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="tb-p2" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#9B7DFF"/><stop offset="50%" stop-color="#7B61FF"/><stop offset="100%" stop-color="#00E5FF"/></linearGradient><linearGradient id="tb-s2" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="#00E5FF" stop-opacity="0"/><stop offset="35%" stop-color="#00E5FF" stop-opacity="0.9"/><stop offset="65%" stop-color="#7B61FF" stop-opacity="0.9"/><stop offset="100%" stop-color="#7B61FF" stop-opacity="0"/></linearGradient></defs><path d="M48 20 L66 30 L66 52 L48 62 L30 52 L30 30 Z" fill="url(#tb-p2)" opacity="0.18"/><path d="M48 20 L66 30 L66 52 L48 62 L30 52 L30 30 Z" fill="none" stroke="url(#tb-p2)" stroke-width="2.5"/><rect x="22" y="39" width="52" height="3" rx="1.5" fill="url(#tb-s2)" opacity="0.95"/><line x1="34" y1="29" x2="21" y2="16" stroke="#9B7DFF" stroke-width="2.5" stroke-linecap="round"/><circle cx="21" cy="16" r="3.5" fill="#9B7DFF"/><circle cx="75" cy="16" r="3.5" fill="#00E5FF"/><line x1="62" y1="29" x2="75" y2="16" stroke="#00E5FF" stroke-width="2.5" stroke-linecap="round"/><circle cx="48" cy="41" r="5" fill="url(#tb-p2)"/><circle cx="48" cy="41" r="2.2" fill="white"/></svg>`;
      if (isOpen) {
        btn.classList.add("bt-panel-open");
        renderPanel(panel);
      } else {
        btn.classList.remove("bt-panel-open");
      }
    };
    root.appendChild(btn);
    root.appendChild(panel);
    document.documentElement.appendChild(root);
    const keyHandler = async (e2) => {
      if (e2.ctrlKey && e2.shiftKey && e2.key === "S") {
        e2.preventDefault();
        const sessions = getAllSessions().sort((a2, b) => b.updatedAt - a2.updatedAt);
        const currentSession = sessions[0];
        const lastEvent = (currentSession == null ? void 0 : currentSession.events[currentSession.events.length - 1]) || null;
        showToast("\u{1F4F8} Capturing screenshot...", root);
        try {
          const ss = await captureScreenshot(lastEvent);
          showToast(`\u2713 Screenshot: ${ss.filename}`, root);
          showAnnotationEditor(ss, root);
        } catch (e3) {
          showToast("\u2717 Screenshot failed", root);
        }
      }
    };
    document.addEventListener("keydown", keyHandler);
    return () => {
      root.remove();
      style.remove();
      document.removeEventListener("keydown", keyHandler);
    };
  }
  function renderPanel(panel) {
    const sessions = getAllSessions().sort((a2, b) => b.updatedAt - a2.updatedAt);
    const errorSessions = sessions.filter((s) => s.errorMessage);
    const allSessions = sessions;
    panel.innerHTML = `
    <div style="padding:16px 20px;border-bottom:1px solid #2a2a3e;display:flex;align-items:center;justify-content:space-between;flex-shrink:0">
      <div>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="font-size:16px;font-weight:700;color:#fff;font-family:system-ui,sans-serif;display:flex;align-items:center;gap:6px"><svg width="18" height="18" viewBox="0 0 96 96" fill="none"><defs><linearGradient id="th-p" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#9B7DFF"/><stop offset="50%" stop-color="#7B61FF"/><stop offset="100%" stop-color="#00E5FF"/></linearGradient><linearGradient id="th-s" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="#00E5FF" stop-opacity="0"/><stop offset="35%" stop-color="#00E5FF" stop-opacity="0.9"/><stop offset="65%" stop-color="#7B61FF" stop-opacity="0.9"/><stop offset="100%" stop-color="#7B61FF" stop-opacity="0"/></linearGradient></defs><path d="M48 20 L66 30 L66 52 L48 62 L30 52 L30 30 Z" fill="url(#th-p)" opacity="0.18"/><path d="M48 20 L66 30 L66 52 L48 62 L30 52 L30 30 Z" fill="none" stroke="url(#th-p)" stroke-width="2.5"/><rect x="22" y="39" width="52" height="3" rx="1.5" fill="url(#th-s)" opacity="0.95"/><line x1="34" y1="29" x2="21" y2="16" stroke="#9B7DFF" stroke-width="2.5" stroke-linecap="round"/><circle cx="21" cy="16" r="3.5" fill="#9B7DFF"/><line x1="62" y1="29" x2="75" y2="16" stroke="#00E5FF" stroke-width="2.5" stroke-linecap="round"/><circle cx="75" cy="16" r="3.5" fill="#00E5FF"/><circle cx="48" cy="41" r="5" fill="url(#th-p)"/><circle cx="48" cy="41" r="2.2" fill="white"/><circle cx="41" cy="34" r="2.5" fill="#00E5FF" opacity="0.9"/><circle cx="55" cy="34" r="2.5" fill="#9B7DFF" opacity="0.9"/></svg>TraceBug AI</div>
          <div id="bt-rec-indicator" style="width:8px;height:8px;border-radius:50%;background:${_isRecording ? "#22c55e" : "#ef4444"};animation:${_isRecording ? "bt-pulse 2s infinite" : "none"}" title="${_isRecording ? "Recording" : "Paused"}"></div>
        </div>
        <div style="font-size:11px;color:#666;margin-top:2px">${errorSessions.length} error${errorSessions.length !== 1 ? "s" : ""} \xB7 ${allSessions.length} session${allSessions.length !== 1 ? "s" : ""}</div>
      </div>
      <div style="display:flex;gap:6px">
        <button id="bt-rec-toggle" style="${smallBtnStyle(_isRecording ? "#fbbf24" : "#22c55e")}font-size:10px">${_isRecording ? "\u23F8 Pause" : "\u25B6 Record"}</button>
        <button id="bt-refresh" style="${smallBtnStyle("#3b82f6")}font-size:10px">\u21BB</button>
        <button id="bt-clear" style="${smallBtnStyle("#ef4444")}font-size:10px">Clear</button>
      </div>
    </div>
    <style>@keyframes bt-pulse { 0%,100% { opacity:1 } 50% { opacity:0.4 } }</style>
    <div id="bt-content" style="flex:1;overflow-y:auto;padding:12px 16px"></div>
  `;
    const content2 = panel.querySelector("#bt-content");
    panel.querySelector("#bt-refresh").addEventListener("click", () => renderPanel(panel));
    panel.querySelector("#bt-clear").addEventListener("click", () => {
      if (confirm("Delete all TraceBug sessions?")) {
        clearAllSessions();
        renderPanel(panel);
      }
    });
    panel.querySelector("#bt-rec-toggle").addEventListener("click", () => {
      if (_onToggleRecording) _onToggleRecording();
    });
    if (allSessions.length === 0) {
      content2.innerHTML = `
      <div style="text-align:center;padding:60px 20px;color:#555">
        <div style="font-size:36px;margin-bottom:12px">\u{1F50D}</div>
        <div style="font-family:system-ui,sans-serif">No sessions recorded yet.</div>
        <div style="font-size:11px;margin-top:8px;color:#444">Interact with the app to start capturing events.</div>
      </div>
    `;
      return;
    }
    content2.innerHTML = "";
    for (const session of allSessions) {
      const card = document.createElement("div");
      card.style.cssText = "border:1px solid #2a2a3e;border-radius:8px;padding:12px;margin-bottom:10px;cursor:pointer;transition:border-color 0.2s";
      card.onmouseenter = () => card.style.borderColor = "#4a4a6e";
      card.onmouseleave = () => card.style.borderColor = "#2a2a3e";
      const hasError = !!session.errorMessage;
      const dot = hasError ? '<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#ef4444;margin-right:6px"></span>' : '<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#22c55e;margin-right:6px"></span>';
      const badge = session.reproSteps ? '<span style="font-size:10px;background:#14532d;color:#4ade80;padding:2px 6px;border-radius:4px;margin-left:6px">Repro Ready</span>' : "";
      card.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;align-items:center">
          ${dot}
          <span style="color:#888;font-size:11px">${session.sessionId.slice(0, 12)}\u2026</span>
          ${badge}
        </div>
        <span style="color:#555;font-size:10px">${timeAgo(session.updatedAt)}</span>
      </div>
      ${hasError ? `<div style="color:#f87171;font-size:12px;margin-top:6px;line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml2(session.errorMessage)}</div>` : ""}
      <div style="color:#555;font-size:11px;margin-top:4px">${session.events.length} events</div>
    `;
      card.onclick = () => renderSessionDetail(panel, session);
      content2.appendChild(card);
    }
  }
  function renderSessionDetail(panel, session) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
    const content2 = panel.querySelector("#bt-content");
    const s = session;
    const problems = [];
    const apiEvents = s.events.filter((e2) => e2.type === "api_request");
    const errorEvents = s.events.filter((e2) => ["error", "unhandled_rejection"].includes(e2.type));
    const consoleErrors = s.events.filter((e2) => e2.type === "console_error");
    const failedApis = apiEvents.filter((e2) => {
      var _a2, _b2;
      return ((_a2 = e2.data.request) == null ? void 0 : _a2.statusCode) >= 400 || ((_b2 = e2.data.request) == null ? void 0 : _b2.statusCode) === 0;
    });
    const slowApis = apiEvents.filter((e2) => {
      var _a2;
      return ((_a2 = e2.data.request) == null ? void 0 : _a2.durationMs) > 3e3;
    });
    for (const ev of errorEvents) {
      const errType = getErrorType(((_a = ev.data.error) == null ? void 0 : _a.message) || "");
      problems.push({ severity: "critical", icon: "\u{1F4A5}", title: `${errType.type}: Runtime Exception`, detail: ((_b = ev.data.error) == null ? void 0 : _b.message) || "Unknown error", color: "#ef4444" });
    }
    for (const ev of failedApis) {
      const r = ev.data.request;
      const code = (r == null ? void 0 : r.statusCode) || 0;
      const severity = code >= 500 || code === 0 ? "critical" : "warning";
      problems.push({ severity, icon: code === 0 ? "\u{1F50C}" : "\u{1F6AB}", title: `HTTP ${code} \u2014 ${getStatusLabel(code)}`, detail: `${r == null ? void 0 : r.method} ${(_c = r == null ? void 0 : r.url) == null ? void 0 : _c.slice(0, 80)}`, color: getStatusColor(code) });
    }
    for (const ev of slowApis) {
      const r = ev.data.request;
      if (!failedApis.includes(ev)) {
        problems.push({ severity: "warning", icon: "\u{1F40C}", title: `Slow Response \u2014 ${formatDuration(r == null ? void 0 : r.durationMs)}`, detail: `${r == null ? void 0 : r.method} ${(_d = r == null ? void 0 : r.url) == null ? void 0 : _d.slice(0, 80)}`, color: "#f97316" });
      }
    }
    for (const ev of consoleErrors) {
      const msg = ((_e = ev.data.error) == null ? void 0 : _e.message) || "";
      if (!msg.includes("Warning:") && !msg.includes("ReactDOM")) {
        problems.push({ severity: "info", icon: "\u26A0\uFE0F", title: "Console Error", detail: msg.slice(0, 120), color: "#fb923c" });
      }
    }
    const firstTs = s.events.length > 0 ? s.events[0].timestamp : s.createdAt;
    const lastTs = s.events.length > 0 ? s.events[s.events.length - 1].timestamp : s.createdAt;
    const sessionDur = lastTs - firstTs;
    const avgApiTime = apiEvents.length > 0 ? Math.round(apiEvents.reduce((sum, e2) => {
      var _a2;
      return sum + (((_a2 = e2.data.request) == null ? void 0 : _a2.durationMs) || 0);
    }, 0) / apiEvents.length) : 0;
    const maxApiTime = apiEvents.length > 0 ? Math.max(...apiEvents.map((e2) => {
      var _a2;
      return ((_a2 = e2.data.request) == null ? void 0 : _a2.durationMs) || 0;
    })) : 0;
    const pagesVisited = new Set(s.events.map((e2) => e2.page)).size;
    let html = "";
    html += `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
    <button id="bt-back" style="background:none;border:none;color:#3b82f6;cursor:pointer;font-size:12px;padding:0;font-family:inherit">\u2190 Back to sessions</button>
    <div style="display:flex;gap:6px">
      <button id="bt-download-json" style="${smallBtnStyle("#22d3ee")}font-size:10px" title="Download as JSON">\u2B07 JSON</button>
      <button id="bt-download-txt" style="${smallBtnStyle("#a78bfa")}font-size:10px" title="Download as text report">\u2B07 Report</button>
      <button id="bt-download-html" style="${smallBtnStyle("#f472b6")}font-size:10px" title="Download visual HTML report">\u2B07 HTML</button>
    </div>
  </div>`;
    html += `<div style="background:#0c1222;border:1px solid #1e3a5f;border-radius:10px;padding:10px;margin-bottom:14px">
    <div style="font-size:10px;color:#60a5fa;font-weight:700;margin-bottom:8px;font-family:system-ui,sans-serif">QA TOOLS</div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">
      <button id="bt-screenshot" style="${smallBtnStyle("#22d3ee")}font-size:10px">\u{1F4F8} Screenshot</button>
      <button id="bt-add-note" style="${smallBtnStyle("#a78bfa")}font-size:10px">\u{1F4DD} Add Note</button>
      <button id="bt-github-issue" style="${smallBtnStyle("#e0e0e0")}font-size:10px">\u{1F419} GitHub Issue</button>
      <button id="bt-jira-ticket" style="${smallBtnStyle("#2684FF")}font-size:10px">\u{1F3AB} Jira Ticket</button>
      <button id="bt-download-pdf" style="${smallBtnStyle("#f472b6")}font-size:10px">\u{1F4C4} PDF Report</button>
      ${isVoiceSupported() ? `<button id="bt-voice-note" style="${smallBtnStyle("#f59e0b")}font-size:10px">\u{1F3A4} Voice Note</button>` : ""}
    </div>
  </div>`;
    html += `<div style="background:#12121f;border:1px solid #2a2a3e;border-radius:10px;padding:14px;margin-bottom:14px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
      <div style="font-size:13px;font-weight:700;color:#fff;font-family:system-ui,sans-serif">Session Overview</div>
      <span style="font-size:10px;padding:2px 8px;border-radius:10px;background:${problems.some((p) => p.severity === "critical") ? "#7f1d1d" : problems.length > 0 ? "#78350f" : "#14532d"};color:${problems.some((p) => p.severity === "critical") ? "#fca5a5" : problems.length > 0 ? "#fbbf24" : "#4ade80"};font-family:system-ui,sans-serif">${problems.some((p) => p.severity === "critical") ? "Has Errors" : problems.length > 0 ? "Has Warnings" : "Healthy"}</span>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div style="background:#0f0f1a;border-radius:6px;padding:8px 10px">
        <div style="font-size:9px;color:#555;text-transform:uppercase;letter-spacing:0.5px;font-family:system-ui,sans-serif">Duration</div>
        <div style="font-size:14px;color:#e0e0e0;margin-top:2px">${formatDuration(sessionDur)}</div>
      </div>
      <div style="background:#0f0f1a;border-radius:6px;padding:8px 10px">
        <div style="font-size:9px;color:#555;text-transform:uppercase;letter-spacing:0.5px;font-family:system-ui,sans-serif">Events</div>
        <div style="font-size:14px;color:#e0e0e0;margin-top:2px">${s.events.length}</div>
      </div>
      <div style="background:#0f0f1a;border-radius:6px;padding:8px 10px">
        <div style="font-size:9px;color:#555;text-transform:uppercase;letter-spacing:0.5px;font-family:system-ui,sans-serif">Pages Visited</div>
        <div style="font-size:14px;color:#e0e0e0;margin-top:2px">${pagesVisited}</div>
      </div>
      <div style="background:#0f0f1a;border-radius:6px;padding:8px 10px">
        <div style="font-size:9px;color:#555;text-transform:uppercase;letter-spacing:0.5px;font-family:system-ui,sans-serif">API Calls</div>
        <div style="font-size:14px;color:#e0e0e0;margin-top:2px">${apiEvents.length} <span style="font-size:10px;color:${failedApis.length > 0 ? "#ef4444" : "#22c55e"}">(${failedApis.length} failed)</span></div>
      </div>
    </div>
    <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">
      <span style="font-size:10px;color:#555">ID: ${s.sessionId.slice(0, 8)}\u2026</span>
      <span style="font-size:10px;color:#444">\xB7</span>
      <span style="font-size:10px;color:#555">${new Date(s.createdAt).toLocaleString()}</span>
    </div>
  </div>`;
    if (problems.length > 0) {
      const criticalCount = problems.filter((p) => p.severity === "critical").length;
      const warningCount = problems.filter((p) => p.severity === "warning").length;
      const infoCount = problems.filter((p) => p.severity === "info").length;
      html += `<div style="border:1px solid ${criticalCount > 0 ? "#7f1d1d" : "#78350f"};background:${criticalCount > 0 ? "#1a0505" : "#1a1005"};border-radius:10px;padding:14px;margin-bottom:14px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
        <div style="font-size:13px;font-weight:700;color:${criticalCount > 0 ? "#fca5a5" : "#fbbf24"};font-family:system-ui,sans-serif">\u{1F50D} Problems Detected (${problems.length})</div>
        <div style="display:flex;gap:6px">
          ${criticalCount > 0 ? `<span style="font-size:9px;padding:2px 6px;border-radius:3px;background:#7f1d1d;color:#fca5a5">${criticalCount} Critical</span>` : ""}
          ${warningCount > 0 ? `<span style="font-size:9px;padding:2px 6px;border-radius:3px;background:#78350f;color:#fbbf24">${warningCount} Warning</span>` : ""}
          ${infoCount > 0 ? `<span style="font-size:9px;padding:2px 6px;border-radius:3px;background:#1e1533;color:#c084fc">${infoCount} Info</span>` : ""}
        </div>
      </div>`;
      for (const p of problems) {
        const sevBorder = p.severity === "critical" ? "#7f1d1d" : p.severity === "warning" ? "#78350f" : "#2a2a3e";
        const sevBg = p.severity === "critical" ? "#0f0205" : p.severity === "warning" ? "#0f0a02" : "#12121f";
        html += `<div style="border:1px solid ${sevBorder};background:${sevBg};border-radius:6px;padding:10px;margin-bottom:6px">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
          <span style="font-size:13px">${p.icon}</span>
          <span style="font-size:11px;font-weight:600;color:${p.color};font-family:system-ui,sans-serif">${escapeHtml2(p.title)}</span>
        </div>
        <div style="color:#888;font-size:11px;line-height:1.4;padding-left:22px;word-break:break-word">${escapeHtml2(p.detail)}</div>
      </div>`;
      }
      html += `</div>`;
    }
    if (s.errorMessage) {
      const errType = getErrorType(s.errorMessage);
      html += `<div style="border:1px solid #7f1d1d;background:#1a0505;border-radius:10px;padding:14px;margin-bottom:14px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:13px;font-weight:700;color:#fca5a5;font-family:system-ui,sans-serif">Error Details</span>
        <span style="font-size:9px;padding:2px 6px;border-radius:3px;background:${errType.color}22;color:${errType.color};border:1px solid ${errType.color}44">${errType.type}</span>
      </div>
      <div style="background:#0f0205;border-radius:6px;padding:10px;margin-bottom:8px">
        <div style="font-size:9px;color:#666;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;font-family:system-ui,sans-serif">Error Message</div>
        <div style="color:#fca5a5;font-size:12px;line-height:1.5;word-break:break-word">${escapeHtml2(s.errorMessage)}</div>
      </div>`;
      if (s.errorStack) {
        const locationMatch = s.errorStack.match(/at\s+(\S+)\s+\(([^)]+)\)/);
        if (locationMatch) {
          html += `<div style="background:#0f0205;border-radius:6px;padding:10px;margin-bottom:8px">
          <div style="font-size:9px;color:#666;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;font-family:system-ui,sans-serif">Error Location</div>
          <div style="display:flex;align-items:center;gap:6px">
            <span style="font-size:12px;color:#60a5fa">${escapeHtml2(locationMatch[1])}</span>
            <span style="font-size:10px;color:#555">at</span>
            <span style="font-size:10px;color:#888;word-break:break-all">${escapeHtml2(locationMatch[2])}</span>
          </div>
        </div>`;
        }
        html += `<details style="margin-top:4px">
        <summary style="font-size:10px;color:#555;cursor:pointer;user-select:none;font-family:system-ui,sans-serif">View Full Stack Trace</summary>
        <pre style="color:#dc262690;font-size:10px;margin-top:6px;white-space:pre-wrap;line-height:1.4;max-height:150px;overflow:auto;background:#0a0a0a;padding:8px;border-radius:4px">${escapeHtml2(s.errorStack)}</pre>
      </details>`;
      }
      html += `</div>`;
    }
    if (apiEvents.length > 0) {
      html += `<div style="background:#12121f;border:1px solid #2a2a3e;border-radius:10px;padding:14px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:10px;font-family:system-ui,sans-serif">\u26A1 Performance</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:10px">
        <div style="background:#0f0f1a;border-radius:6px;padding:8px;text-align:center">
          <div style="font-size:9px;color:#555;text-transform:uppercase;font-family:system-ui,sans-serif">Avg</div>
          <div style="font-size:13px;color:${getSpeedLabel(avgApiTime).color};margin-top:2px">${formatDuration(avgApiTime)}</div>
        </div>
        <div style="background:#0f0f1a;border-radius:6px;padding:8px;text-align:center">
          <div style="font-size:9px;color:#555;text-transform:uppercase;font-family:system-ui,sans-serif">Slowest</div>
          <div style="font-size:13px;color:${getSpeedLabel(maxApiTime).color};margin-top:2px">${formatDuration(maxApiTime)}</div>
        </div>
        <div style="background:#0f0f1a;border-radius:6px;padding:8px;text-align:center">
          <div style="font-size:9px;color:#555;text-transform:uppercase;font-family:system-ui,sans-serif">Success</div>
          <div style="font-size:13px;color:${failedApis.length === 0 ? "#22c55e" : "#fbbf24"};margin-top:2px">${apiEvents.length > 0 ? Math.round((apiEvents.length - failedApis.length) / apiEvents.length * 100) : 0}%</div>
        </div>
      </div>`;
      for (const ev of apiEvents) {
        const r = ev.data.request;
        const code = (r == null ? void 0 : r.statusCode) || 0;
        const dur = (r == null ? void 0 : r.durationMs) || 0;
        const speed = getSpeedLabel(dur);
        const statusClr = getStatusColor(code);
        const isFail = code >= 400 || code === 0;
        const urlPath = ((r == null ? void 0 : r.url) || "").replace(/https?:\/\/[^/]+/, "").slice(0, 50);
        html += `<div style="background:${isFail ? "#0f0205" : "#0f0f1a"};border:1px solid ${isFail ? "#7f1d1d44" : "#1e1e32"};border-radius:6px;padding:8px 10px;margin-bottom:4px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
          <div style="display:flex;align-items:center;gap:6px">
            <span style="font-size:10px;font-weight:600;color:#e0e0e0;background:#1e293b;padding:1px 5px;border-radius:3px">${(r == null ? void 0 : r.method) || "GET"}</span>
            <span style="font-size:10px;color:#888;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:180px">${escapeHtml2(urlPath)}</span>
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            <span style="font-size:10px;font-weight:700;color:${statusClr}">${code}</span>
            <span style="font-size:9px;color:${statusClr}66">${getStatusLabel(code)}</span>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="flex:1;height:3px;background:#1e1e32;border-radius:2px;overflow:hidden">
            <div style="height:100%;width:${Math.min(100, dur / Math.max(maxApiTime, 1) * 100)}%;background:${speed.color};border-radius:2px"></div>
          </div>
          <span style="font-size:10px;color:${speed.color};white-space:nowrap">${formatDuration(dur)}</span>
          ${dur > 3e3 ? `<span style="font-size:8px;padding:1px 4px;border-radius:2px;background:${speed.color}22;color:${speed.color}">${speed.label}</span>` : ""}
        </div>
      </div>`;
      }
      html += `</div>`;
    }
    if (s.reproSteps) {
      html += `<div style="border:1px solid #14532d;background:#031a09;border-radius:10px;padding:14px;margin-bottom:14px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <div style="font-size:13px;font-weight:700;color:#4ade80;font-family:system-ui,sans-serif">\u{1F4CB} Reproduction Steps</div>
        <button id="bt-copy" style="${smallBtnStyle("#3b82f6")}font-size:10px">Copy</button>
      </div>
      <pre style="color:#bbf7d0;font-size:12px;white-space:pre-wrap;line-height:1.7;margin:0">${escapeHtml2(s.reproSteps)}</pre>
      ${s.errorSummary ? `<div style="border-top:1px solid #14532d;margin-top:10px;padding-top:8px"><div style="font-size:10px;font-weight:600;color:#4ade80;margin-bottom:4px;font-family:system-ui,sans-serif">Summary</div><pre style="color:#86efac;font-size:11px;white-space:pre-wrap;line-height:1.4;margin:0">${escapeHtml2(s.errorSummary)}</pre></div>` : ""}
    </div>`;
    }
    const annotations = s.annotations || [];
    if (annotations.length > 0) {
      html += `<div style="border:1px solid #1e3a5f;background:#0c1222;border-radius:10px;padding:14px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;color:#60a5fa;margin-bottom:10px;font-family:system-ui,sans-serif">\u{1F4DD} Tester Notes (${annotations.length})</div>`;
      for (const note of annotations) {
        const sevColor = note.severity === "critical" ? "#ef4444" : note.severity === "major" ? "#f97316" : note.severity === "minor" ? "#3b82f6" : "#888";
        html += `<div style="border:1px solid #2a2a3e;background:#12121f;border-radius:6px;padding:10px;margin-bottom:6px">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
          <span style="font-size:9px;padding:1px 6px;border-radius:3px;background:${sevColor}22;color:${sevColor};border:1px solid ${sevColor}44;font-weight:600;text-transform:uppercase">${note.severity}</span>
          <span style="font-size:10px;color:#555">${new Date(note.timestamp).toLocaleTimeString()}</span>
        </div>
        <div style="color:#e0e0e0;font-size:12px;line-height:1.4">${escapeHtml2(note.text)}</div>
        ${note.expected ? `<div style="margin-top:4px;font-size:11px"><span style="color:#22c55e;font-weight:600">Expected:</span> <span style="color:#aaa">${escapeHtml2(note.expected)}</span></div>` : ""}
        ${note.actual ? `<div style="margin-top:2px;font-size:11px"><span style="color:#ef4444;font-weight:600">Actual:</span> <span style="color:#aaa">${escapeHtml2(note.actual)}</span></div>` : ""}
      </div>`;
      }
      html += `</div>`;
    }
    const screenshots2 = getScreenshots();
    if (screenshots2.length > 0) {
      html += `<div style="border:1px solid #2a2a3e;background:#12121f;border-radius:10px;padding:14px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;color:#22d3ee;margin-bottom:10px;font-family:system-ui,sans-serif">\u{1F4F8} Screenshots (${screenshots2.length})</div>`;
      for (const ss of screenshots2) {
        html += `<div style="margin-bottom:10px">
        <div style="font-size:10px;color:#888;margin-bottom:4px">${escapeHtml2(ss.filename)} \u2014 ${escapeHtml2(ss.page)}</div>
        <img src="${ss.dataUrl}" style="max-width:100%;border:1px solid #2a2a3e;border-radius:6px" />
      </div>`;
      }
      html += `</div>`;
    }
    const envInfo = s.environment;
    if (envInfo) {
      html += `<div style="background:#12121f;border:1px solid #2a2a3e;border-radius:10px;padding:14px;margin-bottom:14px">
      <div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:10px;font-family:system-ui,sans-serif">\u{1F5A5} Environment</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
        <div style="background:#0f0f1a;border-radius:6px;padding:6px 8px"><span style="font-size:9px;color:#555">Browser</span><div style="font-size:12px;color:#e0e0e0">${escapeHtml2(envInfo.browser)} ${escapeHtml2(envInfo.browserVersion)}</div></div>
        <div style="background:#0f0f1a;border-radius:6px;padding:6px 8px"><span style="font-size:9px;color:#555">OS</span><div style="font-size:12px;color:#e0e0e0">${escapeHtml2(envInfo.os)}</div></div>
        <div style="background:#0f0f1a;border-radius:6px;padding:6px 8px"><span style="font-size:9px;color:#555">Viewport</span><div style="font-size:12px;color:#e0e0e0">${escapeHtml2(envInfo.viewport)}</div></div>
        <div style="background:#0f0f1a;border-radius:6px;padding:6px 8px"><span style="font-size:9px;color:#555">Device</span><div style="font-size:12px;color:#e0e0e0">${envInfo.deviceType}</div></div>
      </div>
    </div>`;
    }
    html += `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
    <div style="font-size:13px;font-weight:700;color:#fff;font-family:system-ui,sans-serif">Event Timeline (${s.events.length})</div>
    <span style="font-size:10px;color:#555">${new Date(firstTs).toLocaleTimeString()} \u2014 ${new Date(lastTs).toLocaleTimeString()}</span>
  </div>
  <div style="position:relative;padding-left:24px">
    <div style="position:absolute;left:7px;top:0;bottom:0;width:2px;background:linear-gradient(to bottom, #2a2a3e, #1e1e32)"></div>`;
    for (let i = 0; i < s.events.length; i++) {
      const ev = s.events[i];
      const c = eventConfig[ev.type] || { label: ev.type, icon: "\u{1F4CC}", color: "#666", bg: "#1a1a2e" };
      const isErr = ["error", "unhandled_rejection", "console_error"].includes(ev.type);
      const isApiErr = ev.type === "api_request" && (((_f = ev.data.request) == null ? void 0 : _f.statusCode) >= 400 || ((_g = ev.data.request) == null ? void 0 : _g.statusCode) === 0);
      const isSlowApi = ev.type === "api_request" && ((_h = ev.data.request) == null ? void 0 : _h.durationMs) > 3e3;
      const hasProblem = isErr || isApiErr;
      const dotColor = hasProblem ? "#ef4444" : isSlowApi ? "#f97316" : c.color;
      const timeSincePrev = i > 0 ? ev.timestamp - s.events[i - 1].timestamp : 0;
      if (timeSincePrev > 2e3 && i > 0) {
        html += `<div style="position:relative;margin-bottom:4px;margin-top:4px">
        <div style="position:absolute;left:-21px;top:4px;width:6px;height:6px;border-radius:50%;background:#2a2a3e;border:1px solid #333"></div>
        <div style="font-size:9px;color:#444;font-style:italic;padding:2px 0">\u23F1 ${formatDuration(timeSincePrev)} later</div>
      </div>`;
      }
      html += `<div style="position:relative;margin-bottom:6px">
      <div style="position:absolute;left:-21px;top:6px;width:10px;height:10px;border-radius:50%;background:${dotColor};border:2px solid ${dotColor}44;box-shadow:0 0 ${hasProblem ? "6" : "0"}px ${dotColor}44"></div>
      <div style="border:1px solid ${hasProblem ? "#7f1d1d" : isSlowApi ? "#78350f44" : "#1e1e32"};background:${hasProblem ? "#1a0505" : isSlowApi ? "#1a0f05" : "#12121f"};border-radius:8px;padding:10px 12px;transition:border-color 0.2s">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;flex-wrap:wrap">
          <span style="font-size:12px">${c.icon}</span>
          <span style="font-size:10px;padding:1px 6px;border-radius:3px;background:${c.bg};color:${c.color};font-weight:600">${c.label}</span>
          <span style="font-size:10px;color:#555">${new Date(ev.timestamp).toLocaleTimeString()}</span>
          <span style="font-size:9px;color:#333;margin-left:auto">${ev.page}</span>
        </div>`;
      if (ev.type === "api_request") {
        const r = ev.data.request;
        const code = (r == null ? void 0 : r.statusCode) || 0;
        const dur = (r == null ? void 0 : r.durationMs) || 0;
        const speed = getSpeedLabel(dur);
        const urlPath = ((r == null ? void 0 : r.url) || "").replace(/https?:\/\/[^/]+/, "");
        html += `<div style="margin-top:4px">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
            <span style="font-size:10px;font-weight:700;color:#e0e0e0;background:#1e293b;padding:1px 5px;border-radius:3px">${(r == null ? void 0 : r.method) || "GET"}</span>
            <span style="font-size:11px;color:#aaa;word-break:break-all">${escapeHtml2((urlPath == null ? void 0 : urlPath.slice(0, 80)) || "")}</span>
          </div>
          <div style="display:flex;align-items:center;gap:8px;margin-top:6px">
            <div style="display:flex;align-items:center;gap:4px">
              <span style="font-size:11px;font-weight:700;color:${getStatusColor(code)}">${code}</span>
              <span style="font-size:10px;color:${getStatusColor(code)}88">${getStatusLabel(code)}</span>
            </div>
            <span style="color:#333">\xB7</span>
            <div style="display:flex;align-items:center;gap:4px">
              <span style="font-size:10px;color:${speed.color}">${formatDuration(dur)}</span>
              ${dur > 3e3 ? `<span style="font-size:8px;padding:1px 4px;border-radius:2px;background:${speed.color}22;color:${speed.color};border:1px solid ${speed.color}33">${speed.label}</span>` : ""}
            </div>
          </div>
          <div style="height:3px;background:#1e1e32;border-radius:2px;overflow:hidden;margin-top:6px">
            <div style="height:100%;width:${Math.min(100, dur / Math.max(maxApiTime, 1) * 100)}%;background:${speed.color};border-radius:2px;transition:width 0.3s"></div>
          </div>
        </div>`;
      } else if (ev.type === "click") {
        const el = ev.data.element;
        const target = (el == null ? void 0 : el.ariaLabel) || ((_i = el == null ? void 0 : el.text) == null ? void 0 : _i.trim()) || (el == null ? void 0 : el.id) || (el == null ? void 0 : el.tag) || "element";
        html += `<div style="color:#aaa;font-size:11px;line-height:1.4">Clicked "<span style="color:#60a5fa">${escapeHtml2(target.slice(0, 60))}</span>"</div>`;
        const details = [];
        if (el == null ? void 0 : el.tag) details.push(`&lt;${el.tag}&gt;`);
        if (el == null ? void 0 : el.id) details.push(`#${el.id}`);
        if (el == null ? void 0 : el.className) details.push(`.${escapeHtml2(el.className.split(" ")[0])}`);
        if (el == null ? void 0 : el.href) details.push(`\u2192 ${escapeHtml2(el.href.slice(0, 60))}`);
        if (el == null ? void 0 : el.role) details.push(`role="${el.role}"`);
        if (el == null ? void 0 : el.testId) details.push(`data-testid="${el.testId}"`);
        if (details.length > 0) {
          html += `<div style="font-size:9px;color:#444;margin-top:3px">${details.join(" ")}</div>`;
        }
      } else if (ev.type === "input") {
        const inp = ev.data.element;
        const fieldName = (inp == null ? void 0 : inp.name) || (inp == null ? void 0 : inp.id) || "field";
        const inputType = (inp == null ? void 0 : inp.type) || "text";
        if (inputType === "checkbox" || inputType === "radio") {
          html += `<div style="color:#aaa;font-size:11px;line-height:1.4">${(inp == null ? void 0 : inp.checked) ? "Checked" : "Unchecked"} "<span style="color:#c084fc">${escapeHtml2(fieldName)}</span>" <span style="font-size:9px;color:#555">(${inputType})</span></div>`;
        } else {
          const val = inp == null ? void 0 : inp.value;
          if (val && val !== "[REDACTED]") {
            html += `<div style="color:#aaa;font-size:11px;line-height:1.4">Typed in "<span style="color:#c084fc">${escapeHtml2(fieldName)}</span>" <span style="font-size:9px;color:#555">(${inputType})</span></div>`;
            html += `<div style="font-size:10px;color:#a78bfa;margin-top:3px;background:#1e153344;padding:3px 8px;border-radius:4px;border:1px solid #1e1533;word-break:break-word">"${escapeHtml2(val.slice(0, 150))}"</div>`;
          } else {
            html += `<div style="color:#aaa;font-size:11px;line-height:1.4">Typed in "<span style="color:#c084fc">${escapeHtml2(fieldName)}</span>" <span style="font-size:9px;color:#555">(${inputType})</span></div>
            <div style="font-size:9px;color:#444;margin-top:2px">${(inp == null ? void 0 : inp.valueLength) || 0} characters ${val === "[REDACTED]" ? '<span style="color:#f87171">\u{1F512} redacted</span>' : ""}</div>`;
          }
        }
        if (inp == null ? void 0 : inp.placeholder) {
          html += `<div style="font-size:9px;color:#333;margin-top:2px">placeholder: "${escapeHtml2(inp.placeholder)}"</div>`;
        }
      } else if (ev.type === "select_change") {
        const sel = ev.data.element;
        const fieldName = (sel == null ? void 0 : sel.name) || (sel == null ? void 0 : sel.id) || "dropdown";
        html += `<div style="color:#aaa;font-size:11px;line-height:1.4">Changed "<span style="color:#34d399">${escapeHtml2(fieldName)}</span>" dropdown</div>`;
        html += `<div style="font-size:11px;color:#34d399;margin-top:3px;background:#05201544;padding:4px 8px;border-radius:4px;border:1px solid #14532d">Selected: "<strong>${escapeHtml2((sel == null ? void 0 : sel.selectedText) || (sel == null ? void 0 : sel.value) || "")}</strong>"</div>`;
        if ((sel == null ? void 0 : sel.allOptions) && sel.allOptions.length > 0) {
          html += `<div style="font-size:9px;color:#444;margin-top:3px">Options: ${sel.allOptions.map((o) => escapeHtml2(o)).join(", ")}</div>`;
        }
      } else if (ev.type === "form_submit") {
        const f2 = ev.data.form;
        html += `<div style="color:#aaa;font-size:11px;line-height:1.4">Submitted form ${(f2 == null ? void 0 : f2.id) ? `"<span style="color:#fb923c">${escapeHtml2(f2.id)}</span>"` : ""}</div>`;
        if ((f2 == null ? void 0 : f2.fields) && Object.keys(f2.fields).length > 0) {
          html += `<div style="margin-top:4px;background:#1a150544;padding:6px 8px;border-radius:4px;border:1px solid #2a2a3e">`;
          for (const [key, val] of Object.entries(f2.fields)) {
            html += `<div style="font-size:10px;margin-bottom:2px"><span style="color:#888">${escapeHtml2(key)}:</span> <span style="color:#fbbf24">${escapeHtml2(String(val).slice(0, 80))}</span></div>`;
          }
          html += `</div>`;
        }
        if (f2 == null ? void 0 : f2.method) {
          html += `<div style="font-size:9px;color:#444;margin-top:2px">${f2.method.toUpperCase()} ${f2.action ? `\u2192 ${escapeHtml2(f2.action.slice(0, 60))}` : ""}</div>`;
        }
      } else if (ev.type === "route_change") {
        html += `<div style="display:flex;align-items:center;gap:6px;font-size:11px;margin-top:2px">
          <span style="color:#888;background:#0f0f1a;padding:2px 6px;border-radius:3px">${escapeHtml2(ev.data.from || "/")}</span>
          <span style="color:#22d3ee">\u2192</span>
          <span style="color:#22d3ee;background:#0c2e3344;padding:2px 6px;border-radius:3px;font-weight:600">${escapeHtml2(ev.data.to || "/")}</span>
        </div>`;
      } else if (ev.type === "error" || ev.type === "unhandled_rejection") {
        const errType = getErrorType(((_j = ev.data.error) == null ? void 0 : _j.message) || "");
        html += `<div style="margin-top:2px">
          <div style="display:flex;align-items:center;gap:4px;margin-bottom:3px">
            <span style="font-size:9px;padding:1px 5px;border-radius:3px;background:${errType.color}22;color:${errType.color};border:1px solid ${errType.color}33">${errType.type}</span>
          </div>
          <div style="color:#fca5a5;font-size:11px;line-height:1.4;word-break:break-word">${escapeHtml2(((_k = ev.data.error) == null ? void 0 : _k.message) || "Unknown error")}</div>
          ${((_l = ev.data.error) == null ? void 0 : _l.source) ? `<div style="font-size:9px;color:#555;margin-top:3px">at ${escapeHtml2(ev.data.error.source)}${ev.data.error.line ? `:${ev.data.error.line}` : ""}${ev.data.error.column ? `:${ev.data.error.column}` : ""}</div>` : ""}
        </div>`;
      } else if (ev.type === "console_error") {
        html += `<div style="color:#fb923c;font-size:11px;line-height:1.4;word-break:break-word">${escapeHtml2((((_m = ev.data.error) == null ? void 0 : _m.message) || "").slice(0, 200))}</div>`;
      } else {
        html += `<div style="color:#aaa;font-size:11px;line-height:1.3">${escapeHtml2(describeEvent(ev))}</div>`;
      }
      html += `</div></div>`;
    }
    html += `</div>`;
    html += `<div style="margin-top:16px;padding:12px 0;border-top:1px solid #1e1e32;display:flex;gap:8px">
    <button id="bt-copy-report" style="${smallBtnStyle("#3b82f6")}font-size:11px;flex:1">\u{1F4CB} Copy Full Report</button>
    <button id="bt-delete" style="${smallBtnStyle("#ef4444")}font-size:11px">\u{1F5D1} Delete</button>
  </div>`;
    content2.innerHTML = html;
    content2.querySelector("#bt-back").addEventListener("click", () => renderPanel(panel));
    const copyBtn = content2.querySelector("#bt-copy");
    if (copyBtn) {
      copyBtn.addEventListener("click", () => {
        const text = `Reproduction Steps:
${s.reproSteps}

Error: ${s.errorMessage}

${s.errorSummary || ""}`;
        navigator.clipboard.writeText(text).then(() => {
          copyBtn.textContent = "\u2713 Copied!";
          setTimeout(() => copyBtn.textContent = "Copy", 2e3);
        });
      });
    }
    content2.querySelector("#bt-download-json").addEventListener("click", () => {
      downloadFile(
        `tracebug-${s.sessionId.slice(0, 8)}.json`,
        JSON.stringify(s, null, 2),
        "application/json"
      );
    });
    content2.querySelector("#bt-download-txt").addEventListener("click", () => {
      const report = buildTextReport(s, problems, apiEvents, sessionDur);
      downloadFile(
        `tracebug-report-${s.sessionId.slice(0, 8)}.txt`,
        report,
        "text/plain"
      );
    });
    content2.querySelector("#bt-download-html").addEventListener("click", () => {
      const htmlReport = buildHtmlReport(s, problems, apiEvents, sessionDur);
      downloadFile(
        `tracebug-report-${s.sessionId.slice(0, 8)}.html`,
        htmlReport,
        "text/html"
      );
    });
    const copyReportBtn = content2.querySelector("#bt-copy-report");
    if (copyReportBtn) {
      copyReportBtn.addEventListener("click", () => {
        const report = buildTextReport(s, problems, apiEvents, sessionDur);
        navigator.clipboard.writeText(report).then(() => {
          copyReportBtn.textContent = "\u2713 Copied!";
          setTimeout(() => copyReportBtn.textContent = "\u{1F4CB} Copy Full Report", 2e3);
        });
      });
    }
    content2.querySelector("#bt-delete").addEventListener("click", () => {
      if (confirm("Delete this session?")) {
        deleteSession(session.sessionId);
        renderPanel(panel);
      }
    });
    const ssBtn = content2.querySelector("#bt-screenshot");
    if (ssBtn) {
      ssBtn.addEventListener("click", async () => {
        ssBtn.textContent = "\u{1F4F8} Capturing...";
        try {
          const lastEvent = s.events[s.events.length - 1] || null;
          const ss = await captureScreenshot(lastEvent);
          ssBtn.textContent = `\u2713 ${ss.filename}`;
          setTimeout(() => {
            ssBtn.textContent = "\u{1F4F8} Screenshot";
          }, 3e3);
          const root = document.getElementById("tracebug-root");
          if (root) showAnnotationEditor(ss, root);
        } catch (e2) {
          ssBtn.textContent = "\u2717 Failed";
          setTimeout(() => {
            ssBtn.textContent = "\u{1F4F8} Screenshot";
          }, 2e3);
        }
      });
    }
    const noteBtn = content2.querySelector("#bt-add-note");
    if (noteBtn) {
      noteBtn.addEventListener("click", () => {
        showNoteDialog(s.sessionId, panel, session);
      });
    }
    const ghBtn = content2.querySelector("#bt-github-issue");
    if (ghBtn) {
      ghBtn.addEventListener("click", () => {
        const report = buildReport(session);
        const md = generateGitHubIssue(report);
        navigator.clipboard.writeText(md).then(() => {
          ghBtn.textContent = "\u2713 Copied!";
          setTimeout(() => {
            ghBtn.textContent = "\u{1F419} GitHub Issue";
          }, 2e3);
          if (report.screenshots.length > 0) {
            downloadAllScreenshots();
          }
        });
      });
    }
    const jiraBtn = content2.querySelector("#bt-jira-ticket");
    if (jiraBtn) {
      jiraBtn.addEventListener("click", () => {
        const report = buildReport(session);
        const ticket = generateJiraTicket(report);
        const text = `Summary: ${ticket.summary}
Priority: ${ticket.priority}
Labels: ${ticket.labels.join(", ")}

${ticket.description}`;
        navigator.clipboard.writeText(text).then(() => {
          jiraBtn.textContent = "\u2713 Copied!";
          setTimeout(() => {
            jiraBtn.textContent = "\u{1F3AB} Jira Ticket";
          }, 2e3);
          if (report.screenshots.length > 0) {
            downloadAllScreenshots();
          }
        });
      });
    }
    const pdfBtn = content2.querySelector("#bt-download-pdf");
    if (pdfBtn) {
      pdfBtn.addEventListener("click", () => {
        const report = buildReport(session);
        generatePdfReport(report);
      });
    }
    const voiceBtn = content2.querySelector("#bt-voice-note");
    if (voiceBtn) {
      voiceBtn.addEventListener("click", () => {
        showVoiceDialog(s.sessionId, panel, session);
      });
    }
  }
  function showNoteDialog(sessionId, panel, session) {
    const overlay = document.createElement("div");
    overlay.style.cssText = "position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.7);z-index:10;display:flex;align-items:center;justify-content:center;padding:20px";
    overlay.innerHTML = `
    <div style="background:#12121f;border:1px solid #2a2a3e;border-radius:12px;padding:20px;width:100%;max-width:420px">
      <div style="font-size:14px;font-weight:700;color:#fff;margin-bottom:12px;font-family:system-ui,sans-serif">\u{1F4DD} Add Tester Note</div>
      <div style="margin-bottom:10px">
        <label style="font-size:10px;color:#888;display:block;margin-bottom:4px;font-family:system-ui,sans-serif">What did you observe?</label>
        <textarea id="bt-note-text" style="width:100%;height:60px;background:#0f0f1a;border:1px solid #2a2a3e;border-radius:6px;color:#e0e0e0;padding:8px;font-size:12px;font-family:inherit;resize:vertical" placeholder="Describe the issue..."></textarea>
      </div>
      <div style="margin-bottom:10px">
        <label style="font-size:10px;color:#888;display:block;margin-bottom:4px;font-family:system-ui,sans-serif">Expected behavior</label>
        <input id="bt-note-expected" style="width:100%;background:#0f0f1a;border:1px solid #2a2a3e;border-radius:6px;color:#e0e0e0;padding:8px;font-size:12px;font-family:inherit" placeholder="What should happen?" />
      </div>
      <div style="margin-bottom:10px">
        <label style="font-size:10px;color:#888;display:block;margin-bottom:4px;font-family:system-ui,sans-serif">Actual behavior</label>
        <input id="bt-note-actual" style="width:100%;background:#0f0f1a;border:1px solid #2a2a3e;border-radius:6px;color:#e0e0e0;padding:8px;font-size:12px;font-family:inherit" placeholder="What actually happened?" />
      </div>
      <div style="margin-bottom:14px">
        <label style="font-size:10px;color:#888;display:block;margin-bottom:4px;font-family:system-ui,sans-serif">Severity</label>
        <select id="bt-note-severity" style="width:100%;background:#0f0f1a;border:1px solid #2a2a3e;border-radius:6px;color:#e0e0e0;padding:8px;font-size:12px;font-family:inherit">
          <option value="critical">Critical \u2014 App broken/unusable</option>
          <option value="major">Major \u2014 Feature not working</option>
          <option value="minor" selected>Minor \u2014 Cosmetic/UX issue</option>
          <option value="info">Info \u2014 Observation/Note</option>
        </select>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button id="bt-note-cancel" style="${smallBtnStyle("#666")}font-size:11px">Cancel</button>
        <button id="bt-note-save" style="background:#3b82f6;color:white;border:none;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:12px;font-family:inherit">Save Note</button>
      </div>
    </div>
  `;
    const panelEl = panel.querySelector("#bt-content") || panel;
    panelEl.appendChild(overlay);
    overlay.querySelector("#bt-note-cancel").addEventListener("click", () => overlay.remove());
    overlay.querySelector("#bt-note-save").addEventListener("click", () => {
      const text = overlay.querySelector("#bt-note-text").value.trim();
      if (!text) return;
      const annotation = {
        id: `note_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        timestamp: Date.now(),
        text,
        expected: overlay.querySelector("#bt-note-expected").value.trim() || void 0,
        actual: overlay.querySelector("#bt-note-actual").value.trim() || void 0,
        severity: overlay.querySelector("#bt-note-severity").value
      };
      addAnnotation(sessionId, annotation);
      overlay.remove();
      const updatedSessions = getAllSessions();
      const updatedSession = updatedSessions.find((s) => s.sessionId === sessionId);
      if (updatedSession) {
        renderSessionDetail(panel, updatedSession);
      }
    });
  }
  function showVoiceDialog(sessionId, panel, session) {
    const overlay = document.createElement("div");
    overlay.id = "bt-voice-overlay";
    overlay.dataset.tracebug = "voice-dialog";
    overlay.style.cssText = "position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.7);z-index:10;display:flex;align-items:center;justify-content:center;padding:20px";
    overlay.innerHTML = `
    <div style="background:#12121f;border:1px solid #2a2a3e;border-radius:12px;padding:20px;width:100%;max-width:420px">
      <div style="font-size:14px;font-weight:700;color:#fff;margin-bottom:4px;font-family:system-ui,sans-serif">\u{1F3A4} Voice Bug Description</div>
      <div style="font-size:11px;color:#666;margin-bottom:14px">Speak to describe the bug. Your words appear below in real-time.</div>
      <div id="bt-voice-status" style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
        <div id="bt-voice-dot" style="width:10px;height:10px;border-radius:50%;background:#666"></div>
        <span id="bt-voice-status-text" style="font-size:11px;color:#888">Click Start to begin recording</span>
      </div>
      <textarea id="bt-voice-transcript" style="width:100%;height:100px;background:#0f0f1a;border:1px solid #2a2a3e;border-radius:6px;color:#e0e0e0;padding:8px;font-size:12px;font-family:inherit;resize:vertical" placeholder="Your speech will appear here...&#10;&#10;You can also type or edit the text manually."></textarea>
      <div id="bt-voice-interim" style="font-size:11px;color:#f59e0b88;min-height:20px;margin-top:4px;font-style:italic"></div>
      <div style="display:flex;gap:8px;margin-top:14px">
        <button id="bt-voice-start" style="background:#22c55e;color:white;border:none;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:12px;font-family:inherit;flex:1">\u{1F3A4} Start Recording</button>
        <button id="bt-voice-stop" style="background:#ef444422;color:#ef4444;border:1px solid #ef444444;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:12px;font-family:inherit;flex:1;display:none">\u23F9 Stop</button>
      </div>
      <div style="display:flex;gap:8px;margin-top:10px;justify-content:flex-end">
        <button id="bt-voice-cancel" style="${smallBtnStyle("#666")}font-size:11px">Cancel</button>
        <button id="bt-voice-save" style="background:#3b82f6;color:white;border:none;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:12px;font-family:inherit">Save as Note</button>
      </div>
    </div>
  `;
    const panelEl = panel.querySelector("#bt-content") || panel;
    panelEl.appendChild(overlay);
    const transcriptEl = overlay.querySelector("#bt-voice-transcript");
    const interimEl = overlay.querySelector("#bt-voice-interim");
    const startBtn = overlay.querySelector("#bt-voice-start");
    const stopBtn = overlay.querySelector("#bt-voice-stop");
    const dot = overlay.querySelector("#bt-voice-dot");
    const statusText = overlay.querySelector("#bt-voice-status-text");
    let pulseInterval = null;
    startBtn.addEventListener("click", () => {
      const started = startVoiceRecording({
        onUpdate: (text, interim) => {
          transcriptEl.value = text;
          interimEl.textContent = interim ? `...${interim}` : "";
          transcriptEl.scrollTop = transcriptEl.scrollHeight;
        },
        onStatus: (status, message) => {
          if (status === "recording") {
            dot.style.background = "#22c55e";
            statusText.textContent = "Listening... speak now";
            statusText.style.color = "#22c55e";
            startBtn.style.display = "none";
            stopBtn.style.display = "block";
            pulseInterval = setInterval(() => {
              dot.style.opacity = dot.style.opacity === "0.4" ? "1" : "0.4";
            }, 500);
          } else if (status === "stopped") {
            dot.style.background = "#666";
            statusText.textContent = "Recording stopped";
            statusText.style.color = "#888";
            startBtn.style.display = "block";
            startBtn.textContent = "\u{1F3A4} Record More";
            stopBtn.style.display = "none";
            interimEl.textContent = "";
            if (pulseInterval) {
              clearInterval(pulseInterval);
              pulseInterval = null;
            }
            dot.style.opacity = "1";
          } else if (status === "error") {
            dot.style.background = "#ef4444";
            statusText.textContent = message || "Error occurred";
            statusText.style.color = "#ef4444";
            startBtn.style.display = "block";
            startBtn.textContent = "\u{1F3A4} Try Again";
            stopBtn.style.display = "none";
            if (pulseInterval) {
              clearInterval(pulseInterval);
              pulseInterval = null;
            }
            dot.style.opacity = "1";
          }
        }
      });
      if (!started && !isVoiceSupported()) {
        statusText.textContent = "Speech recognition not supported in this browser.";
        statusText.style.color = "#ef4444";
      }
    });
    stopBtn.addEventListener("click", () => {
      stopVoiceRecording();
    });
    overlay.querySelector("#bt-voice-cancel").addEventListener("click", () => {
      if (isVoiceRecording()) stopVoiceRecording();
      if (pulseInterval) clearInterval(pulseInterval);
      overlay.remove();
    });
    overlay.querySelector("#bt-voice-save").addEventListener("click", () => {
      if (isVoiceRecording()) stopVoiceRecording();
      if (pulseInterval) clearInterval(pulseInterval);
      const text = transcriptEl.value.trim();
      if (!text) {
        statusText.textContent = "No text to save. Record or type something first.";
        statusText.style.color = "#ef4444";
        return;
      }
      const annotation = {
        id: `voice_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        timestamp: Date.now(),
        text: `\u{1F3A4} ${text}`,
        severity: "major"
      };
      addAnnotation(sessionId, annotation);
      overlay.remove();
      const updatedSessions = getAllSessions();
      const updatedSession = updatedSessions.find((s) => s.sessionId === sessionId);
      if (updatedSession) {
        renderSessionDetail(panel, updatedSession);
      }
    });
  }
  function buildTextReport(s, problems, apiEvents, sessionDur) {
    let report = `TraceBug Session Report
${"=".repeat(50)}

`;
    report += `Session ID: ${s.sessionId}
`;
    report += `Date: ${new Date(s.createdAt).toLocaleString()}
`;
    report += `Duration: ${formatDuration(sessionDur)}
`;
    report += `Events: ${s.events.length}

`;
    if (problems.length > 0) {
      report += `Problems Detected (${problems.length})
${"-".repeat(40)}
`;
      for (const p of problems) {
        report += `[${p.severity.toUpperCase()}] ${p.title}
  ${p.detail}

`;
      }
    }
    if (s.errorMessage) {
      report += `Error Details
${"-".repeat(40)}
`;
      report += `Message: ${s.errorMessage}
`;
      if (s.errorStack) report += `Stack:
${s.errorStack}
`;
      report += `
`;
    }
    if (s.reproSteps) {
      report += `Reproduction Steps
${"-".repeat(40)}
${s.reproSteps}

`;
    }
    if (s.errorSummary) {
      report += `Summary
${"-".repeat(40)}
${s.errorSummary}

`;
    }
    report += `Event Timeline
${"-".repeat(40)}
`;
    for (const ev of s.events) {
      const time2 = new Date(ev.timestamp).toLocaleTimeString();
      report += `[${time2}] ${ev.type.toUpperCase()} on ${ev.page}
`;
      report += `  ${describeEventForReport(ev)}
`;
    }
    if (apiEvents.length > 0) {
      report += `
API Calls
${"-".repeat(40)}
`;
      for (const ev of apiEvents) {
        const r = ev.data.request;
        report += `${r == null ? void 0 : r.method} ${r == null ? void 0 : r.url} \u2192 ${r == null ? void 0 : r.statusCode} (${r == null ? void 0 : r.durationMs}ms)
`;
      }
    }
    return report;
  }
  function buildHtmlReport(s, problems, apiEvents, sessionDur) {
    const hasError = !!s.errorMessage;
    let html = `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TraceBug Report \u2014 ${s.sessionId.slice(0, 8)}</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'SF Mono',Consolas,monospace,system-ui,sans-serif;background:#0f0f1a;color:#e0e0e0;padding:32px;max-width:800px;margin:0 auto}
  h1{font-size:20px;color:#fff;margin-bottom:4px;font-family:system-ui,sans-serif}
  h2{font-size:15px;color:#fff;margin:24px 0 12px;font-family:system-ui,sans-serif}
  .meta{font-size:12px;color:#666;margin-bottom:24px}
  .card{background:#12121f;border:1px solid #2a2a3e;border-radius:10px;padding:16px;margin-bottom:16px}
  .stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin-top:12px}
  .stat{background:#0f0f1a;border-radius:6px;padding:10px;text-align:center}
  .stat-label{font-size:10px;color:#555;text-transform:uppercase;letter-spacing:0.5px;font-family:system-ui,sans-serif}
  .stat-value{font-size:16px;margin-top:4px}
  .problem{border:1px solid #7f1d1d;background:#1a0505;border-radius:6px;padding:10px;margin-bottom:8px}
  .problem.warning{border-color:#78350f;background:#1a1005}
  .problem.info{border-color:#2a2a3e;background:#12121f}
  .timeline-event{border:1px solid #1e1e32;background:#12121f;border-radius:8px;padding:12px;margin-bottom:8px;position:relative;margin-left:20px}
  .timeline-event.error{border-color:#7f1d1d;background:#1a0505}
  .timeline-dot{position:absolute;left:-26px;top:14px;width:10px;height:10px;border-radius:50%;border:2px solid}
  .badge{font-size:10px;padding:2px 8px;border-radius:4px;font-weight:600}
  .tag{font-size:10px;padding:1px 6px;border-radius:3px;font-weight:600}
  pre{white-space:pre-wrap;font-size:12px;line-height:1.5}
  .value-box{background:#1e153344;padding:4px 8px;border-radius:4px;border:1px solid #1e1533;margin-top:4px;font-size:11px;color:#a78bfa;word-break:break-word}
  .select-box{background:#05201544;padding:4px 8px;border-radius:4px;border:1px solid #14532d;margin-top:4px;font-size:11px;color:#34d399}
</style></head><body>
<h1>\u{1F41B} TraceBug Session Report</h1>
<div class="meta">Session: ${s.sessionId} \xB7 ${new Date(s.createdAt).toLocaleString()} \xB7 Duration: ${formatDuration(sessionDur)}</div>`;
    html += `<div class="card">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
      <span style="font-size:14px;font-weight:700;font-family:system-ui,sans-serif">Session Overview</span>
      <span class="badge" style="background:${hasError ? "#7f1d1d" : "#14532d"};color:${hasError ? "#fca5a5" : "#4ade80"}">${hasError ? "Has Errors" : "Healthy"}</span>
    </div>
    <div class="stat-grid">
      <div class="stat"><div class="stat-label">Duration</div><div class="stat-value">${formatDuration(sessionDur)}</div></div>
      <div class="stat"><div class="stat-label">Events</div><div class="stat-value">${s.events.length}</div></div>
      <div class="stat"><div class="stat-label">Pages</div><div class="stat-value">${new Set(s.events.map((e2) => e2.page)).size}</div></div>
      <div class="stat"><div class="stat-label">API Calls</div><div class="stat-value">${apiEvents.length}</div></div>
    </div>
  </div>`;
    if (problems.length > 0) {
      html += `<h2>\u{1F50D} Problems Detected (${problems.length})</h2>`;
      for (const p of problems) {
        const cls = p.severity === "critical" ? "" : p.severity === "warning" ? " warning" : " info";
        html += `<div class="problem${cls}">
        <div style="margin-bottom:4px"><span style="font-size:14px">${p.icon}</span> <strong style="color:${p.color}">${escapeHtml2(p.title)}</strong></div>
        <div style="color:#888;font-size:12px;padding-left:24px">${escapeHtml2(p.detail)}</div>
      </div>`;
      }
    }
    if (s.errorMessage) {
      html += `<h2>\u{1F4A5} Error Details</h2><div class="card" style="border-color:#7f1d1d;background:#1a0505">
      <div style="color:#fca5a5;font-size:13px;line-height:1.5;margin-bottom:8px">${escapeHtml2(s.errorMessage)}</div>
      ${s.errorStack ? `<pre style="color:#dc262690;font-size:11px;background:#0a0a0a;padding:10px;border-radius:6px;max-height:200px;overflow:auto">${escapeHtml2(s.errorStack)}</pre>` : ""}
    </div>`;
    }
    if (s.reproSteps) {
      html += `<h2>\u{1F4CB} Reproduction Steps</h2><div class="card" style="border-color:#14532d;background:#031a09">
      <pre style="color:#bbf7d0;line-height:1.8">${escapeHtml2(s.reproSteps)}</pre>
      ${s.errorSummary ? `<div style="border-top:1px solid #14532d;margin-top:12px;padding-top:10px"><pre style="color:#86efac;font-size:11px">${escapeHtml2(s.errorSummary)}</pre></div>` : ""}
    </div>`;
    }
    html += `<h2>\u{1F4CA} Event Timeline (${s.events.length})</h2>
    <div style="position:relative;padding-left:28px">
    <div style="position:absolute;left:9px;top:0;bottom:0;width:2px;background:linear-gradient(to bottom, #2a2a3e, #1e1e32)"></div>`;
    for (let i = 0; i < s.events.length; i++) {
      const ev = s.events[i];
      const c = eventConfig[ev.type] || { label: ev.type, icon: "\u{1F4CC}", color: "#666", bg: "#1a1a2e" };
      const isErr = ["error", "unhandled_rejection", "console_error"].includes(ev.type);
      const errCls = isErr ? " error" : "";
      const dotColor = isErr ? "#ef4444" : c.color;
      html += `<div class="timeline-event${errCls}">
      <div class="timeline-dot" style="background:${dotColor};border-color:${dotColor}44"></div>
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
        <span style="font-size:13px">${c.icon}</span>
        <span class="tag" style="background:${c.bg};color:${c.color}">${c.label}</span>
        <span style="font-size:10px;color:#555">${new Date(ev.timestamp).toLocaleTimeString()}</span>
        <span style="font-size:10px;color:#333;margin-left:auto">${ev.page}</span>
      </div>
      <div style="font-size:12px;color:#aaa">${describeEventHtml(ev)}</div>
    </div>`;
    }
    html += `</div>
<div style="text-align:center;color:#333;font-size:11px;margin-top:32px;padding:16px;border-top:1px solid #1e1e32">Generated by TraceBug AI \xB7 ${(/* @__PURE__ */ new Date()).toLocaleString()}</div>
</body></html>`;
    return html;
  }
  function describeEventHtml(ev) {
    var _a, _b, _c;
    switch (ev.type) {
      case "click": {
        const el = ev.data.element;
        const target = (el == null ? void 0 : el.ariaLabel) || ((_a = el == null ? void 0 : el.text) == null ? void 0 : _a.trim()) || (el == null ? void 0 : el.id) || (el == null ? void 0 : el.tag) || "element";
        let s = `Clicked "<span style="color:#60a5fa">${escapeHtml2(target.slice(0, 60))}</span>"`;
        if (el == null ? void 0 : el.href) s += ` <span style="font-size:10px;color:#444">\u2192 ${escapeHtml2(el.href.slice(0, 60))}</span>`;
        return s;
      }
      case "input": {
        const inp = ev.data.element;
        const val = inp == null ? void 0 : inp.value;
        let s = `Typed in "<span style="color:#c084fc">${escapeHtml2((inp == null ? void 0 : inp.name) || "field")}</span>"`;
        if (val && val !== "[REDACTED]") s += `<div class="value-box">"${escapeHtml2(val.slice(0, 150))}"</div>`;
        else if (val === "[REDACTED]") s += ` <span style="color:#f87171;font-size:10px">\u{1F512} redacted</span>`;
        return s;
      }
      case "select_change": {
        const sel = ev.data.element;
        let s = `Changed "<span style="color:#34d399">${escapeHtml2((sel == null ? void 0 : sel.name) || "dropdown")}</span>"`;
        s += `<div class="select-box">Selected: "<strong>${escapeHtml2((sel == null ? void 0 : sel.selectedText) || (sel == null ? void 0 : sel.value) || "")}</strong>"</div>`;
        return s;
      }
      case "form_submit": {
        const f2 = ev.data.form;
        let s = `Submitted form ${(f2 == null ? void 0 : f2.id) ? `"${escapeHtml2(f2.id)}"` : ""}`;
        if (f2 == null ? void 0 : f2.fields) {
          s += `<div style="margin-top:4px">`;
          for (const [key, val] of Object.entries(f2.fields)) {
            s += `<div style="font-size:10px"><span style="color:#888">${escapeHtml2(key)}:</span> ${escapeHtml2(String(val).slice(0, 80))}</div>`;
          }
          s += `</div>`;
        }
        return s;
      }
      case "route_change":
        return `<span style="color:#888">${escapeHtml2(ev.data.from || "/")}</span> <span style="color:#22d3ee">\u2192</span> <span style="color:#22d3ee;font-weight:600">${escapeHtml2(ev.data.to || "/")}</span>`;
      case "api_request": {
        const r = ev.data.request;
        return `<span style="font-weight:600">${r == null ? void 0 : r.method}</span> ${escapeHtml2(((r == null ? void 0 : r.url) || "").slice(0, 80))} \u2192 <span style="color:${getStatusColor((r == null ? void 0 : r.statusCode) || 0)};font-weight:700">${r == null ? void 0 : r.statusCode}</span> <span style="color:#555">(${r == null ? void 0 : r.durationMs}ms)</span>`;
      }
      case "error":
      case "unhandled_rejection":
        return `<span style="color:#fca5a5">${escapeHtml2(((_b = ev.data.error) == null ? void 0 : _b.message) || "Unknown error")}</span>`;
      case "console_error":
        return `<span style="color:#fb923c">${escapeHtml2((((_c = ev.data.error) == null ? void 0 : _c.message) || "").slice(0, 200))}</span>`;
      default:
        return escapeHtml2(JSON.stringify(ev.data).slice(0, 100));
    }
  }
  function describeEventForReport(ev) {
    var _a, _b, _c, _d;
    switch (ev.type) {
      case "click": {
        const el = ev.data.element;
        const target = (el == null ? void 0 : el.ariaLabel) || ((_a = el == null ? void 0 : el.text) == null ? void 0 : _a.trim()) || (el == null ? void 0 : el.id) || (el == null ? void 0 : el.tag) || "element";
        let s = `Clicked "${target}"`;
        if (el == null ? void 0 : el.href) s += ` \u2192 ${el.href}`;
        return s;
      }
      case "input": {
        const inp = ev.data.element;
        const val = inp == null ? void 0 : inp.value;
        if (val && val !== "[REDACTED]") return `Typed "${val}" in "${(inp == null ? void 0 : inp.name) || "field"}" (${(inp == null ? void 0 : inp.type) || "text"})`;
        return `Typed in "${(inp == null ? void 0 : inp.name) || "field"}" (${(inp == null ? void 0 : inp.valueLength) || 0} chars, ${(inp == null ? void 0 : inp.type) || "text"})`;
      }
      case "select_change": {
        const sel = ev.data.element;
        return `Selected "${(sel == null ? void 0 : sel.selectedText) || (sel == null ? void 0 : sel.value)}" from "${(sel == null ? void 0 : sel.name) || "dropdown"}" dropdown`;
      }
      case "form_submit": {
        const f2 = ev.data.form;
        let s = `Submitted form "${(f2 == null ? void 0 : f2.id) || ""}" (${f2 == null ? void 0 : f2.fieldCount} fields)`;
        if (f2 == null ? void 0 : f2.fields) {
          const entries = Object.entries(f2.fields);
          if (entries.length > 0) s += ` \u2014 ` + entries.map(([k, v]) => `${k}="${String(v).slice(0, 40)}"`).join(", ");
        }
        return s;
      }
      case "route_change":
        return `${ev.data.from || "/"} \u2192 ${ev.data.to || "/"}`;
      case "api_request": {
        const r = ev.data.request;
        return `${r == null ? void 0 : r.method} ${(_b = r == null ? void 0 : r.url) == null ? void 0 : _b.slice(0, 80)} \u2192 ${r == null ? void 0 : r.statusCode} (${r == null ? void 0 : r.durationMs}ms)`;
      }
      case "error":
      case "unhandled_rejection":
        return ((_c = ev.data.error) == null ? void 0 : _c.message) || "Unknown error";
      case "console_error":
        return (((_d = ev.data.error) == null ? void 0 : _d.message) || "").slice(0, 120);
      default:
        return JSON.stringify(ev.data).slice(0, 100);
    }
  }
  function downloadFile(filename, content2, mimeType) {
    const blob = new Blob([content2], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a2 = document.createElement("a");
    a2.href = url;
    a2.download = filename;
    document.body.appendChild(a2);
    a2.click();
    document.body.removeChild(a2);
    URL.revokeObjectURL(url);
  }
  var eventConfig = {
    click: { label: "Click", icon: "\u{1F446}", color: "#60a5fa", bg: "#1e293b" },
    input: { label: "Input", icon: "\u2328\uFE0F", color: "#c084fc", bg: "#1e1533" },
    select_change: { label: "Select", icon: "\u{1F4CB}", color: "#34d399", bg: "#052015" },
    form_submit: { label: "Form Submit", icon: "\u{1F4E4}", color: "#fb923c", bg: "#2a1505" },
    route_change: { label: "Navigate", icon: "\u{1F500}", color: "#22d3ee", bg: "#0c2e33" },
    api_request: { label: "API", icon: "\u{1F310}", color: "#fbbf24", bg: "#2a2005" },
    error: { label: "Error", icon: "\u{1F4A5}", color: "#f87171", bg: "#2a0505" },
    console_error: { label: "Console Err", icon: "\u26A0\uFE0F", color: "#fb923c", bg: "#2a1505" },
    unhandled_rejection: { label: "Rejection", icon: "\u{1F4A5}", color: "#f87171", bg: "#2a0505" }
  };
  function getStatusColor(code) {
    if (code === 0) return "#ef4444";
    if (code < 300) return "#22c55e";
    if (code < 400) return "#fbbf24";
    if (code < 500) return "#f97316";
    return "#ef4444";
  }
  function getStatusLabel(code) {
    if (code === 0) return "Network Error";
    const labels = {
      200: "OK",
      201: "Created",
      204: "No Content",
      301: "Moved",
      302: "Found",
      304: "Not Modified",
      400: "Bad Request",
      401: "Unauthorized",
      403: "Forbidden",
      404: "Not Found",
      405: "Method Not Allowed",
      408: "Timeout",
      409: "Conflict",
      413: "Payload Too Large",
      422: "Unprocessable",
      429: "Rate Limited",
      500: "Internal Server Error",
      502: "Bad Gateway",
      503: "Service Unavailable",
      504: "Gateway Timeout"
    };
    return labels[code] || (code < 300 ? "Success" : code < 400 ? "Redirect" : code < 500 ? "Client Error" : "Server Error");
  }
  function getSpeedLabel(ms) {
    if (ms < 200) return { label: "Fast", color: "#22c55e" };
    if (ms < 1e3) return { label: "Normal", color: "#fbbf24" };
    if (ms < 5e3) return { label: "Slow", color: "#f97316" };
    return { label: "Very Slow", color: "#ef4444" };
  }
  function getErrorType(msg) {
    const m = msg.toLowerCase();
    if (m.includes("typeerror") || m.includes("cannot read prop")) return { type: "TypeError", color: "#f87171" };
    if (m.includes("referenceerror")) return { type: "ReferenceError", color: "#fb923c" };
    if (m.includes("syntaxerror")) return { type: "SyntaxError", color: "#f472b6" };
    if (m.includes("rangeerror")) return { type: "RangeError", color: "#c084fc" };
    if (m.includes("networkerror") || m.includes("fetch") || m.includes("network")) return { type: "NetworkError", color: "#fbbf24" };
    if (m.includes("timeout")) return { type: "TimeoutError", color: "#f97316" };
    if (m.includes("chunk") || m.includes("loading")) return { type: "ChunkLoadError", color: "#fb923c" };
    return { type: "RuntimeError", color: "#f87171" };
  }
  function formatDuration(ms) {
    if (ms < 1e3) return `${ms}ms`;
    if (ms < 6e4) return `${(ms / 1e3).toFixed(1)}s`;
    return `${Math.floor(ms / 6e4)}m ${Math.floor(ms % 6e4 / 1e3)}s`;
  }
  function describeEvent(event) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s;
    const d = event.data;
    switch (event.type) {
      case "click":
        return `Clicked "${((_a = d.element) == null ? void 0 : _a.text) || ((_b = d.element) == null ? void 0 : _b.id) || ((_c = d.element) == null ? void 0 : _c.tag) || "element"}"`;
      case "input": {
        const val = (_d = d.element) == null ? void 0 : _d.value;
        if (val && val !== "[REDACTED]") return `Typed "${val.slice(0, 40)}" in "${((_e = d.element) == null ? void 0 : _e.name) || "field"}"`;
        return `Typed in "${((_f = d.element) == null ? void 0 : _f.name) || "field"}" (${((_g = d.element) == null ? void 0 : _g.valueLength) || 0} chars)`;
      }
      case "select_change":
        return `Selected "${((_h = d.element) == null ? void 0 : _h.selectedText) || ((_i = d.element) == null ? void 0 : _i.value)}" from "${((_j = d.element) == null ? void 0 : _j.name) || "dropdown"}"`;
      case "form_submit":
        return `Submitted form "${((_k = d.form) == null ? void 0 : _k.id) || ""}" (${((_l = d.form) == null ? void 0 : _l.fieldCount) || 0} fields)`;
      case "route_change":
        return `${d.from} \u2192 ${d.to}`;
      case "api_request":
        return `${(_m = d.request) == null ? void 0 : _m.method} ${(_o = (_n = d.request) == null ? void 0 : _n.url) == null ? void 0 : _o.slice(0, 60)} \u2192 ${(_p = d.request) == null ? void 0 : _p.statusCode} (${(_q = d.request) == null ? void 0 : _q.durationMs}ms)`;
      case "error":
      case "unhandled_rejection":
        return ((_r = d.error) == null ? void 0 : _r.message) || "Unknown error";
      case "console_error":
        return (((_s = d.error) == null ? void 0 : _s.message) || "").slice(0, 120);
      default:
        return JSON.stringify(d).slice(0, 100);
    }
  }
  function timeAgo(ts) {
    const diff = Math.floor((Date.now() - ts) / 1e3);
    if (diff < 60) return "just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  }
  function escapeHtml2(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function smallBtnStyle(color2) {
    return `background:${color2}22;color:${color2};border:1px solid ${color2}44;border-radius:4px;padding:4px 10px;cursor:pointer;font-size:11px;font-family:inherit;`;
  }
  function showToast(message, root) {
    const existing = root.querySelector(".bt-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.className = "bt-toast";
    toast.style.cssText = `
    position:fixed;top:20px;left:50%;transform:translateX(-50%);
    background:#1a1a2e;color:#e0e0e0;border:1px solid #3b82f6;
    border-radius:8px;padding:10px 20px;font-size:13px;
    font-family:system-ui,sans-serif;z-index:2147483647;
    box-shadow:0 4px 20px rgba(0,0,0,0.5);pointer-events:auto;
    transition:opacity 0.3s;
  `;
    toast.textContent = message;
    root.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }
  function showAnnotationEditor(screenshot, root) {
    const overlay = document.createElement("div");
    overlay.id = "bt-annotation-overlay";
    overlay.style.cssText = `
    position:fixed;top:0;left:0;right:0;bottom:0;
    background:rgba(0,0,0,0.85);z-index:2147483647;
    display:flex;flex-direction:column;align-items:center;
    justify-content:center;pointer-events:auto;
    font-family:system-ui,sans-serif;
  `;
    const maxW = window.innerWidth * 0.85;
    const maxH = window.innerHeight * 0.78;
    const imgRatio = screenshot.width / screenshot.height;
    let displayW = screenshot.width;
    let displayH = screenshot.height;
    if (displayW > maxW) {
      displayW = maxW;
      displayH = displayW / imgRatio;
    }
    if (displayH > maxH) {
      displayH = maxH;
      displayW = displayH * imgRatio;
    }
    displayW = Math.round(displayW);
    displayH = Math.round(displayH);
    const toolbarHtml = `
    <div style="display:flex;gap:8px;margin-bottom:10px;align-items:center">
      <span style="color:#888;font-size:11px;margin-right:8px">ANNOTATE:</span>
      <button class="bt-ann-tool" data-tool="rect" style="${annToolBtnStyle(true)}">\u25AD Highlight</button>
      <button class="bt-ann-tool" data-tool="arrow" style="${annToolBtnStyle(false)}">\u2192 Arrow</button>
      <button class="bt-ann-tool" data-tool="text" style="${annToolBtnStyle(false)}">T Text</button>
      <span style="color:#333;margin:0 4px">|</span>
      <button class="bt-ann-tool" data-tool="color-red" style="background:#ef4444;border:2px solid #ef4444;width:22px;height:22px;border-radius:50%;cursor:pointer;padding:0"></button>
      <button class="bt-ann-tool" data-tool="color-yellow" style="background:#eab308;border:2px solid #eab308;width:22px;height:22px;border-radius:50%;cursor:pointer;padding:0"></button>
      <button class="bt-ann-tool" data-tool="color-green" style="background:#22c55e;border:2px solid #22c55e;width:22px;height:22px;border-radius:50%;cursor:pointer;padding:0"></button>
      <button class="bt-ann-tool" data-tool="color-blue" style="background:#3b82f6;border:2px solid #3b82f6;width:22px;height:22px;border-radius:50%;cursor:pointer;padding:0"></button>
      <span style="color:#333;margin:0 4px">|</span>
      <button id="bt-ann-undo" style="${annActionBtnStyle()}">\u21A9 Undo</button>
      <button id="bt-ann-clear" style="${annActionBtnStyle()}">\u2715 Clear</button>
      <div style="flex:1"></div>
      <span style="color:#555;font-size:10px">Ctrl+Shift+S</span>
    </div>
  `;
    const actionsHtml = `
    <div style="display:flex;gap:10px;margin-top:10px;align-items:center">
      <button id="bt-ann-save" style="background:#3b82f6;color:white;border:none;border-radius:6px;padding:8px 20px;cursor:pointer;font-size:13px;font-family:inherit">\u2713 Save Annotated</button>
      <button id="bt-ann-download" style="background:#22c55e22;color:#22c55e;border:1px solid #22c55e44;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:12px;font-family:inherit">\u2193 Download</button>
      <button id="bt-ann-cancel" style="background:#66666622;color:#888;border:1px solid #66666644;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:12px;font-family:inherit">Cancel</button>
      <div style="flex:1"></div>
      <span style="color:#555;font-size:10px">${screenshot.filename}</span>
    </div>
  `;
    overlay.innerHTML = `${toolbarHtml}<div id="bt-ann-canvas-wrap" style="position:relative;cursor:crosshair"></div>${actionsHtml}`;
    root.appendChild(overlay);
    const canvasWrap = overlay.querySelector("#bt-ann-canvas-wrap");
    const img = new Image();
    img.onload = () => {
      img.style.cssText = `width:${displayW}px;height:${displayH}px;border-radius:6px;display:block;user-select:none;pointer-events:none`;
      canvasWrap.appendChild(img);
      const canvas = document.createElement("canvas");
      canvas.width = displayW;
      canvas.height = displayH;
      canvas.dataset.tracebug = "annotation-canvas";
      canvas.style.cssText = `position:absolute;top:0;left:0;width:${displayW}px;height:${displayH}px;border-radius:6px;`;
      canvasWrap.appendChild(canvas);
      initAnnotationCanvas(canvas, displayW, displayH, overlay, screenshot, root);
    };
    img.src = screenshot.dataUrl;
    overlay.querySelector("#bt-ann-cancel").addEventListener("click", () => overlay.remove());
    const escHandler = (e2) => {
      if (e2.key === "Escape") {
        overlay.remove();
        document.removeEventListener("keydown", escHandler);
      }
    };
    document.addEventListener("keydown", escHandler);
  }
  function initAnnotationCanvas(canvas, width, height, overlay, screenshot, root) {
    const ctx = canvas.getContext("2d");
    const actions = [];
    let currentTool = "rect";
    let currentColor = "#ef4444";
    let isDrawing = false;
    let startX = 0, startY = 0;
    function redraw() {
      ctx.clearRect(0, 0, width, height);
      for (const action of actions) {
        drawAction(ctx, action);
      }
    }
    function drawAction(c, a2) {
      c.strokeStyle = a2.color;
      c.fillStyle = a2.color;
      c.lineWidth = 2.5;
      if (a2.type === "rect") {
        const w = a2.endX - a2.startX;
        const h = a2.endY - a2.startY;
        c.globalAlpha = 0.15;
        c.fillRect(a2.startX, a2.startY, w, h);
        c.globalAlpha = 1;
        c.strokeRect(a2.startX, a2.startY, w, h);
      } else if (a2.type === "arrow") {
        drawArrow(c, a2.startX, a2.startY, a2.endX, a2.endY, a2.color);
      } else if (a2.type === "text" && a2.text) {
        c.font = "bold 14px system-ui, sans-serif";
        const metrics = c.measureText(a2.text);
        const padding = 4;
        c.globalAlpha = 0.85;
        c.fillStyle = "#000";
        c.fillRect(a2.startX - padding, a2.startY - 16, metrics.width + padding * 2, 22);
        c.globalAlpha = 1;
        c.fillStyle = a2.color;
        c.fillText(a2.text, a2.startX, a2.startY);
      }
    }
    function drawArrow(c, x1, y1, x2, y2, color2) {
      const headLen = 12;
      const angle2 = Math.atan2(y2 - y1, x2 - x1);
      c.strokeStyle = color2;
      c.fillStyle = color2;
      c.lineWidth = 2.5;
      c.beginPath();
      c.moveTo(x1, y1);
      c.lineTo(x2, y2);
      c.stroke();
      c.beginPath();
      c.moveTo(x2, y2);
      c.lineTo(x2 - headLen * Math.cos(angle2 - Math.PI / 6), y2 - headLen * Math.sin(angle2 - Math.PI / 6));
      c.lineTo(x2 - headLen * Math.cos(angle2 + Math.PI / 6), y2 - headLen * Math.sin(angle2 + Math.PI / 6));
      c.closePath();
      c.fill();
    }
    overlay.querySelectorAll(".bt-ann-tool").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tool = btn.dataset.tool || "";
        if (tool.startsWith("color-")) {
          currentColor = getComputedStyle(btn).backgroundColor;
          overlay.querySelectorAll("[data-tool^='color-']").forEach((cb) => {
            cb.style.border = `2px solid ${getComputedStyle(cb).backgroundColor}`;
          });
          btn.style.border = `2px solid #fff`;
          return;
        }
        currentTool = tool;
        overlay.querySelectorAll(".bt-ann-tool:not([data-tool^='color-'])").forEach((tb) => {
          tb.style.background = "#22222244";
          tb.style.color = "#888";
          tb.style.borderColor = "#33333344";
        });
        btn.style.background = "#3b82f633";
        btn.style.color = "#3b82f6";
        btn.style.borderColor = "#3b82f6";
      });
    });
    canvas.addEventListener("mousedown", (e2) => {
      const rect = canvas.getBoundingClientRect();
      startX = e2.clientX - rect.left;
      startY = e2.clientY - rect.top;
      if (currentTool === "text") {
        const text = prompt("Enter annotation text:");
        if (text) {
          actions.push({ type: "text", color: currentColor, startX, startY, endX: startX, endY: startY, text });
          redraw();
        }
        return;
      }
      isDrawing = true;
    });
    canvas.addEventListener("mousemove", (e2) => {
      if (!isDrawing) return;
      const rect = canvas.getBoundingClientRect();
      const curX = e2.clientX - rect.left;
      const curY = e2.clientY - rect.top;
      redraw();
      const preview = { type: currentTool, color: currentColor, startX, startY, endX: curX, endY: curY };
      drawAction(ctx, preview);
    });
    canvas.addEventListener("mouseup", (e2) => {
      if (!isDrawing) return;
      isDrawing = false;
      const rect = canvas.getBoundingClientRect();
      const endX = e2.clientX - rect.left;
      const endY = e2.clientY - rect.top;
      if (Math.abs(endX - startX) < 5 && Math.abs(endY - startY) < 5) {
        redraw();
        return;
      }
      actions.push({ type: currentTool, color: currentColor, startX, startY, endX, endY });
      redraw();
    });
    overlay.querySelector("#bt-ann-undo").addEventListener("click", () => {
      actions.pop();
      redraw();
    });
    overlay.querySelector("#bt-ann-clear").addEventListener("click", () => {
      actions.length = 0;
      redraw();
    });
    overlay.querySelector("#bt-ann-save").addEventListener("click", () => {
      const merged = mergeAnnotations(screenshot.dataUrl, canvas, width, height);
      screenshot.dataUrl = merged;
      showToast("\u2713 Annotations saved to screenshot", root);
      overlay.remove();
    });
    overlay.querySelector("#bt-ann-download").addEventListener("click", () => {
      const merged = mergeAnnotations(screenshot.dataUrl, canvas, width, height);
      const a2 = document.createElement("a");
      a2.href = merged;
      a2.download = screenshot.filename;
      document.body.appendChild(a2);
      a2.click();
      document.body.removeChild(a2);
      showToast(`\u2713 Downloaded: ${screenshot.filename}`, root);
    });
  }
  function mergeAnnotations(baseDataUrl, annotationCanvas, w, h) {
    const mergeCanvas = document.createElement("canvas");
    mergeCanvas.width = w;
    mergeCanvas.height = h;
    const mCtx = mergeCanvas.getContext("2d");
    const img = new Image();
    img.src = baseDataUrl;
    mCtx.drawImage(img, 0, 0, w, h);
    mCtx.drawImage(annotationCanvas, 0, 0);
    return mergeCanvas.toDataURL("image/png", 0.9);
  }
  function annToolBtnStyle(active) {
    if (active) {
      return "background:#3b82f633;color:#3b82f6;border:1px solid #3b82f6;border-radius:5px;padding:5px 12px;cursor:pointer;font-size:12px;font-family:inherit;";
    }
    return "background:#22222244;color:#888;border:1px solid #33333344;border-radius:5px;padding:5px 12px;cursor:pointer;font-size:12px;font-family:inherit;";
  }
  function annActionBtnStyle() {
    return "background:#22222244;color:#888;border:1px solid #33333344;border-radius:5px;padding:5px 10px;cursor:pointer;font-size:11px;font-family:inherit;";
  }

  // src/collectors.ts
  var ROOT_ID = "tracebug-root";
  var PANEL_ID3 = "tracebug-dashboard-panel";
  var BTN_ID3 = "tracebug-dashboard-btn";
  var INTERNAL_URL_PATTERNS = [
    /__nextjs_original-stack-frame/,
    /\/_next\/static\/webpack/,
    /\/__webpack_hmr/,
    /\.hot-update\./,
    /\/sockjs-node\//,
    /\/turbopack-hmr\//,
    /\/_next\/webpack-hmr/,
    /\/webpack-dev-server\//,
    /\/__vite_ping/,
    /\/@vite\/client/,
    /\/@react-refresh/
  ];
  function isInternalUrl(url) {
    return INTERNAL_URL_PATTERNS.some((pattern) => pattern.test(url));
  }
  var _rootCache;
  function getRoot() {
    if (_rootCache === void 0) {
      _rootCache = document.getElementById(ROOT_ID);
    }
    if (_rootCache && !_rootCache.isConnected) {
      _rootCache = document.getElementById(ROOT_ID);
    }
    return _rootCache;
  }
  function isTraceBugElement(el) {
    if (!el) return false;
    if (el.id === ROOT_ID || el.id === BTN_ID3 || el.id === PANEL_ID3) return true;
    if (el.dataset && el.dataset.tracebug) return true;
    const root = getRoot();
    if (root && root.contains(el)) return true;
    let node = el;
    while (node) {
      const id = node.id || "";
      if (id.startsWith("tracebug-") || id.startsWith("bt-")) return true;
      const cn = typeof node.className === "string" ? node.className : "";
      if (cn.includes("tracebug-") || cn.includes("bt-ann") || cn.includes("bt-voice")) return true;
      if (node.dataset && node.dataset.tracebug) return true;
      node = node.parentElement;
    }
    return false;
  }
  function collectClicks(emit) {
    const handler = (e2) => {
      const t = e2.target;
      if (!t || isTraceBugElement(t)) return;
      const tag = t.tagName.toLowerCase();
      const data = {
        element: {
          tag,
          text: (t.innerText || "").slice(0, 120),
          id: t.id || "",
          className: typeof t.className === "string" ? t.className : ""
        }
      };
      const el = data.element;
      if (tag === "a") {
        el.href = t.href || "";
      }
      if (tag === "button" || t.type === "submit") {
        el.buttonType = t.type || "button";
        el.disabled = t.disabled;
      }
      if (tag === "label") {
        el.forField = t.htmlFor || "";
      }
      const ariaLabel = t.getAttribute("aria-label");
      if (ariaLabel) el.ariaLabel = ariaLabel;
      const role = t.getAttribute("role");
      if (role) el.role = role;
      const testId = t.getAttribute("data-testid");
      if (testId) el.testId = testId;
      const form = t.closest("form");
      if (form) {
        el.formId = form.id || "";
        el.formAction = form.action || "";
      }
      emit("click", data);
    };
    document.addEventListener("click", handler, { capture: true });
    return () => document.removeEventListener("click", handler, { capture: true });
  }
  function collectInputs(emit) {
    const timers = /* @__PURE__ */ new Map();
    const handler = (e2) => {
      const t = e2.target;
      if (!t || !("value" in t) || isTraceBugElement(t)) return;
      if (t.tagName.toLowerCase() === "select") return;
      const prev = timers.get(t);
      if (prev) clearTimeout(prev);
      timers.set(
        t,
        setTimeout(() => {
          const tag = t.tagName.toLowerCase();
          const inputType = t.type || "";
          const isSensitive = ["password", "credit-card", "ssn"].includes(inputType) || /password|secret|token|ssn|credit/i.test(t.name || t.id || "");
          const data = {
            element: {
              tag,
              name: t.name || t.id || "",
              type: inputType,
              valueLength: (t.value || "").length,
              value: isSensitive ? "[REDACTED]" : (t.value || "").slice(0, 200),
              placeholder: t.placeholder || ""
            }
          };
          if (inputType === "checkbox" || inputType === "radio") {
            data.element.checked = t.checked;
            data.element.value = t.checked ? "checked" : "unchecked";
          }
          if (inputType === "number" || inputType === "range") {
            data.element.value = t.value;
          }
          emit("input", data);
          timers.delete(t);
        }, 300)
      );
    };
    document.addEventListener("input", handler, { capture: true });
    return () => {
      document.removeEventListener("input", handler, { capture: true });
      timers.forEach((t) => clearTimeout(t));
    };
  }
  function collectSelectChanges(emit) {
    const handler = (e2) => {
      const t = e2.target;
      if (!t || t.tagName.toLowerCase() !== "select" || isTraceBugElement(t)) return;
      const selectedOption = t.options[t.selectedIndex];
      emit("select_change", {
        element: {
          tag: "select",
          name: t.name || t.id || "",
          value: t.value,
          selectedText: selectedOption ? selectedOption.text : "",
          selectedIndex: t.selectedIndex,
          optionCount: t.options.length,
          allOptions: Array.from(t.options).map((o) => o.text).slice(0, 20)
        }
      });
    };
    document.addEventListener("change", handler, { capture: true });
    return () => document.removeEventListener("change", handler, { capture: true });
  }
  function collectFormSubmits(emit) {
    const handler = (e2) => {
      const form = e2.target;
      if (!form || form.tagName.toLowerCase() !== "form" || isTraceBugElement(form)) return;
      const formData = {};
      const elements = form.elements;
      for (let i = 0; i < elements.length; i++) {
        const el = elements[i];
        if (!el.name) continue;
        const isSensitive = ["password"].includes(el.type) || /password|secret|token|ssn|credit/i.test(el.name);
        if (el.type === "submit" || el.type === "button") continue;
        formData[el.name] = isSensitive ? "[REDACTED]" : (el.value || "").slice(0, 200);
      }
      emit("form_submit", {
        form: {
          id: form.id || "",
          action: form.action || "",
          method: form.method || "GET",
          fieldCount: elements.length,
          fields: formData
        }
      });
    };
    document.addEventListener("submit", handler, { capture: true });
    return () => document.removeEventListener("submit", handler, { capture: true });
  }
  function collectRouteChanges(emit) {
    let lastPath = window.location.pathname;
    const check = () => {
      const current = window.location.pathname;
      if (current !== lastPath) {
        const from = lastPath;
        lastPath = current;
        emit("route_change", { from, to: current });
      }
    };
    window.addEventListener("popstate", check);
    const origPush = history.pushState.bind(history);
    const origReplace = history.replaceState.bind(history);
    history.pushState = function(...args) {
      origPush(...args);
      check();
    };
    history.replaceState = function(...args) {
      origReplace(...args);
      check();
    };
    return () => {
      window.removeEventListener("popstate", check);
      history.pushState = origPush;
      history.replaceState = origReplace;
    };
  }
  function collectApiRequests(emit) {
    const originalFetch = window.fetch;
    window.fetch = async function(input, init) {
      const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
      const method = (init == null ? void 0 : init.method) || "GET";
      const start = Date.now();
      if (isInternalUrl(url)) {
        return originalFetch.call(window, input, init);
      }
      try {
        const response = await originalFetch.call(window, input, init);
        emit("api_request", {
          request: {
            url: url.slice(0, 500),
            method: method.toUpperCase(),
            statusCode: response.status,
            durationMs: Date.now() - start
          }
        });
        return response;
      } catch (err) {
        emit("api_request", {
          request: {
            url: url.slice(0, 500),
            method: method.toUpperCase(),
            statusCode: 0,
            durationMs: Date.now() - start
          }
        });
        throw err;
      }
    };
    return () => {
      window.fetch = originalFetch;
    };
  }
  function collectXhrRequests(emit) {
    const OrigXHR = window.XMLHttpRequest;
    const origOpen = OrigXHR.prototype.open;
    const origSend = OrigXHR.prototype.send;
    const xhrMeta = /* @__PURE__ */ new WeakMap();
    OrigXHR.prototype.open = function(method, url, ...rest) {
      xhrMeta.set(this, { method, url: typeof url === "string" ? url : url.toString() });
      return origOpen.apply(this, [method, url, ...rest]);
    };
    OrigXHR.prototype.send = function(body) {
      const xhr = this;
      const start = Date.now();
      const meta = xhrMeta.get(xhr);
      const method = (meta == null ? void 0 : meta.method) || "GET";
      const url = (meta == null ? void 0 : meta.url) || "";
      if (isInternalUrl(url)) {
        return origSend.call(this, body);
      }
      xhr.addEventListener("loadend", function() {
        emit("api_request", {
          request: {
            url: url.slice(0, 500),
            method: method.toUpperCase(),
            statusCode: xhr.status,
            durationMs: Date.now() - start
          }
        });
      });
      xhr.addEventListener("error", function() {
        emit("api_request", {
          request: {
            url: url.slice(0, 500),
            method: method.toUpperCase(),
            statusCode: 0,
            durationMs: Date.now() - start
          }
        });
      });
      return origSend.call(this, body);
    };
    return () => {
      OrigXHR.prototype.open = origOpen;
      OrigXHR.prototype.send = origSend;
    };
  }
  function collectErrors(emit) {
    const prevOnError = window.onerror;
    window.onerror = (msg, source, line, col, error) => {
      emit("error", {
        error: {
          message: typeof msg === "string" ? msg : "Unknown error",
          stack: error == null ? void 0 : error.stack,
          source,
          line,
          column: col
        }
      });
      if (prevOnError) prevOnError(msg, source, line, col, error);
    };
    const onRejection = (e2) => {
      var _a, _b;
      emit("unhandled_rejection", {
        error: {
          message: ((_a = e2.reason) == null ? void 0 : _a.message) || String(e2.reason),
          stack: (_b = e2.reason) == null ? void 0 : _b.stack
        }
      });
    };
    window.addEventListener("unhandledrejection", onRejection);
    const origConsoleError = console.error;
    let _insideEmit = false;
    console.error = function(...args) {
      if (_insideEmit) {
        origConsoleError.apply(console, args);
        return;
      }
      _insideEmit = true;
      try {
        emit("console_error", {
          error: {
            message: args.map((a2) => typeof a2 === "string" ? a2 : JSON.stringify(a2)).join(" ")
          }
        });
      } finally {
        _insideEmit = false;
      }
      origConsoleError.apply(console, args);
    };
    return () => {
      window.onerror = prevOnError;
      window.removeEventListener("unhandledrejection", onRejection);
      console.error = origConsoleError;
    };
  }

  // src/index.ts
  var import_meta = {};
  var TraceBugSDK = class {
    constructor() {
      this.config = null;
      this.cleanups = [];
      this.initialized = false;
      this.recording = true;
      this.sessionId = null;
    }
    /**
     * Initialize TraceBug. Call once on app startup.
     *
     *   TraceBug.init({ projectId: "my-app" });
     *
     * Options:
     *  - projectId:       Required. Identifies your app.
     *  - maxEvents:       Max events per session in storage (default 200).
     *  - maxSessions:     Max sessions kept in localStorage (default 50).
     *  - enableDashboard: Show the floating bug button (default true).
     *  - enabled:         Control when SDK is active (default "auto").
     */
    init(config) {
      var _a;
      if (this.initialized) {
        console.warn("[TraceBug] Already initialized.");
        return;
      }
      if (!this.shouldEnable((_a = config.enabled) != null ? _a : "auto")) {
        console.info("[TraceBug] Disabled in this environment.");
        return;
      }
      this.config = {
        maxEvents: 200,
        maxSessions: 50,
        enableDashboard: true,
        ...config
      };
      this.initialized = true;
      this.recording = true;
      this.sessionId = getSessionId();
      const sessionId = this.sessionId;
      const env = captureEnvironment();
      saveEnvironment(sessionId, env);
      const emit = (type, data) => {
        var _a2, _b;
        if (!this.recording) return;
        const event = {
          id: Math.random().toString(36).slice(2, 10),
          sessionId,
          projectId: this.config.projectId,
          type,
          page: window.location.pathname,
          timestamp: Date.now(),
          data
        };
        appendEvent(
          sessionId,
          event,
          this.config.maxEvents,
          this.config.maxSessions
        );
        if (type === "error" || type === "unhandled_rejection") {
          this.processError(sessionId, (_a2 = data.error) == null ? void 0 : _a2.message, (_b = data.error) == null ? void 0 : _b.stack);
        }
      };
      this.cleanups.push(collectClicks(emit));
      this.cleanups.push(collectInputs(emit));
      this.cleanups.push(collectSelectChanges(emit));
      this.cleanups.push(collectFormSubmits(emit));
      this.cleanups.push(collectRouteChanges(emit));
      this.cleanups.push(collectApiRequests(emit));
      this.cleanups.push(collectXhrRequests(emit));
      this.cleanups.push(collectErrors(emit));
      if (this.config.enableDashboard) {
        setRecordingState(this.recording, () => {
          if (this.recording) {
            this.pauseRecording();
          } else {
            this.resumeRecording();
          }
          updateRecordingState(this.recording);
        });
        this.cleanups.push(mountDashboard());
      }
      console.info(
        `[TraceBug] Initialized \u2014 project: ${config.projectId}, session: ${sessionId}`
      );
    }
    /** Pause recording — events will not be captured until resumed */
    pauseRecording() {
      this.recording = false;
      console.info("[TraceBug] Recording paused.");
    }
    /** Resume recording after a pause */
    resumeRecording() {
      this.recording = true;
      console.info("[TraceBug] Recording resumed.");
    }
    /** Check if currently recording */
    isRecording() {
      return this.recording;
    }
    /** Get current session ID */
    getSessionId() {
      return this.sessionId;
    }
    // ── Screenshot ──────────────────────────────────────────────────────
    /** Capture a screenshot of the current page */
    async takeScreenshot() {
      if (!this.sessionId) return null;
      const sessions = getAllSessions();
      const session = sessions.find((s) => s.sessionId === this.sessionId);
      const lastEvent = (session == null ? void 0 : session.events[session.events.length - 1]) || null;
      const screenshot = await captureScreenshot(lastEvent);
      console.info(`[TraceBug] Screenshot captured: ${screenshot.filename}`);
      return screenshot;
    }
    /** Get all screenshots from current session */
    getScreenshots() {
      return getScreenshots();
    }
    // ── Annotations ─────────────────────────────────────────────────────
    /** Add a tester note/annotation to the current session */
    addNote(options) {
      if (!this.sessionId) return;
      const annotation = {
        id: `note_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        timestamp: Date.now(),
        text: options.text,
        expected: options.expected,
        actual: options.actual,
        severity: options.severity || "info",
        screenshotId: options.screenshotId
      };
      addAnnotation(this.sessionId, annotation);
      console.info(`[TraceBug] Note added: "${options.text}"`);
    }
    // ── Voice Recording ─────────────────────────────────────────────────
    /** Check if voice recording is supported */
    isVoiceSupported() {
      return isVoiceSupported();
    }
    /** Start voice recording for bug description */
    startVoiceRecording(options) {
      return startVoiceRecording(options);
    }
    /** Stop voice recording and return transcript */
    stopVoiceRecording() {
      return stopVoiceRecording();
    }
    /** Check if voice is currently recording */
    isVoiceRecording() {
      return isVoiceRecording();
    }
    /** Get all voice transcripts */
    getVoiceTranscripts() {
      return getVoiceTranscripts();
    }
    // ── Report Generation ───────────────────────────────────────────────
    /** Generate a complete bug report for the current session */
    generateReport() {
      if (!this.sessionId) return null;
      const sessions = getAllSessions();
      const session = sessions.find((s) => s.sessionId === this.sessionId);
      if (!session) return null;
      return buildReport(session);
    }
    /** Generate GitHub issue markdown */
    getGitHubIssue() {
      const report = this.generateReport();
      if (!report) return null;
      return generateGitHubIssue(report);
    }
    /** Generate Jira ticket payload */
    getJiraTicket() {
      const report = this.generateReport();
      if (!report) return null;
      return generateJiraTicket(report);
    }
    /** Download a PDF bug report */
    downloadPdf() {
      const report = this.generateReport();
      if (!report) {
        console.warn("[TraceBug] No session data to generate PDF.");
        return;
      }
      generatePdfReport(report);
    }
    /** Get auto-generated bug title */
    getBugTitle() {
      if (!this.sessionId) return null;
      const sessions = getAllSessions();
      const session = sessions.find((s) => s.sessionId === this.sessionId);
      if (!session) return null;
      return generateBugTitle(session);
    }
    /** Get environment info */
    getEnvironment() {
      return captureEnvironment();
    }
    // ── Private methods ─────────────────────────────────────────────────
    /**
     * Determine if TraceBug should be active based on the `enabled` config.
     */
    shouldEnable(mode) {
      if (mode === "off") return false;
      if (mode === "all") return true;
      if (Array.isArray(mode)) {
        const host2 = typeof window !== "undefined" ? window.location.hostname : "";
        return mode.some((h) => host2 === h || host2.endsWith("." + h));
      }
      const env = this.detectEnvironment();
      const host = typeof window !== "undefined" ? window.location.hostname : "";
      const isStaging = /staging|\.stg\.|\.uat\.|\.qa\.|\.dev\./i.test(host);
      if (mode === "development") {
        return env === "development";
      }
      if (mode === "staging") {
        return env === "development" || isStaging;
      }
      if (env === "production" && !isStaging) {
        return false;
      }
      return true;
    }
    /**
     * Detect the current environment from various sources.
     */
    detectEnvironment() {
      var _a;
      try {
        if (typeof (import_meta == null ? void 0 : import_meta.env) !== "undefined") {
          const meta = import_meta.env;
          if (meta.PROD === true) return "production";
          if (meta.DEV === true) return "development";
          if (meta.MODE) return meta.MODE;
        }
      } catch (e2) {
      }
      try {
        const g = globalThis;
        if (typeof g.process !== "undefined" && ((_a = g.process.env) == null ? void 0 : _a.NODE_ENV)) {
          return g.process.env.NODE_ENV;
        }
      } catch (e2) {
      }
      if (typeof window !== "undefined") {
        const host = window.location.hostname;
        if (host === "localhost" || host === "127.0.0.1" || host === "0.0.0.0" || host === "[::1]") {
          return "development";
        }
      }
      return "production";
    }
    /**
     * When an error event is captured, pull the session timeline from
     * localStorage and generate reproduction steps.
     */
    processError(sessionId, errorMessage, errorStack) {
      if (!errorMessage) return;
      setTimeout(() => {
        const sessions = getAllSessions();
        const session = sessions.find((s) => s.sessionId === sessionId);
        if (!session) return;
        const result = generateReproSteps(
          session.events,
          errorMessage,
          errorStack
        );
        updateSessionError(
          sessionId,
          errorMessage,
          errorStack,
          result.reproSteps,
          result.errorSummary
        );
        console.info(
          "[TraceBug] Bug report generated. Click the bug button to view reproduction steps."
        );
      }, 100);
    }
    /**
     * Tear down the SDK — removes all listeners and the dashboard.
     */
    destroy() {
      flushPendingEvents();
      this.cleanups.forEach((fn) => fn());
      this.cleanups = [];
      this.initialized = false;
      this.config = null;
      this.recording = false;
      this.sessionId = null;
      clearScreenshots();
      clearVoiceTranscripts();
    }
  };
  var TraceBug = new TraceBugSDK();
  var src_default = TraceBug;
  return __toCommonJS(src_exports);
})();
/*! Bundled license information:

html2canvas/dist/html2canvas.esm.js:
  (*!
   * html2canvas 1.4.1 <https://html2canvas.hertzen.com>
   * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
   * Released under MIT License
   *)
  (*! *****************************************************************************
  Copyright (c) Microsoft Corporation.
  
  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.
  
  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** *)
*/

        // Expose TraceBug on window for extension use (only once)
        if (typeof window !== 'undefined' && typeof TraceBugModule !== 'undefined' && !window.__TRACEBUG_LOADED__) {
          window.__TRACEBUG_LOADED__ = true;
          window.TraceBug = TraceBugModule.default || TraceBugModule;
          window.TraceBugSDK = TraceBugModule;
        }
      
